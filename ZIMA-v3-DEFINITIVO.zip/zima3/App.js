/**
 * ZIMA v3 · App.js
 * ─────────────────────────────────────────────────────────
 * Sistema completo de optimización metabólica y estilo de vida.
 *
 * SECCIONES:
 *  Dashboard · Entrenamiento · Cocina · Sueño
 *  Cetonas · Hidratación · Suplementos · Historial
 *
 * INSTALACIÓN:
 *   npx create-expo-app zima3 --template blank
 *   cd zima3
 *   npx expo install @react-native-async-storage/async-storage
 *   cp -r [todos los archivos] .
 *   npx expo start
 * ─────────────────────────────────────────────────────────
 */
import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet,
  SafeAreaView, StatusBar, ActivityIndicator,
  ScrollView, Animated,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

import OnboardingScreen  from './screens/OnboardingScreen';
import TrainingScreen    from './screens/TrainingScreen';
import KitchenScreen     from './screens/KitchenScreen';
import SleepScreen       from './screens/SleepScreen';
import KetonesScreen     from './screens/KetonesScreen';
import HydrationScreen   from './screens/HydrationScreen';
import SupplementsScreen from './screens/SupplementsScreen';
import HistoryScreen     from './screens/HistoryScreen';

import { calcBMI, calcTDEE, calcInflammation, analyzeKetones, getStatus, calcAvatarLevel, analyzeAvatar } from './engine/SIMEngine';
import { C, F, S, R } from './theme/index';

const STORAGE_KEY = '@zima_v3';

const INITIAL = {
  onboardingDone:false, gender:null, bodyType:null,
  weight:75, height:175, age:30,
  waistCm:null, armsCm:null, legsCm:null, chestCm:null,
  ketones:0, ketoneMethod:'SANGRE', ketoneHistory:[],
  netCarbsToday:0, meals:[], pantry:{},
  loadVolume:0, adherenceDays:0,
  sleepHours:0, sleepHistory:[], snoringEnabled:false,
  hydrationLog:[],
  supplements:[], supplementSchedules:{},
  weightHistory:[], measureHistory:[],
  createdAt:new Date().toISOString(), version:'3.0.0',
};

// ─── Navegación ──────────────────────────────────────────
const NAV = [
  {id:'dashboard',   icon:'◉',  label:'Inicio',   short:''},
  {id:'training',    icon:'⚔',  label:'Entreno',  short:''},
  {id:'kitchen',     icon:'🍳', label:'Cocina',   short:''},
  {id:'sleep',       icon:'🌙', label:'Sueño',    short:''},
  {id:'ketones',     icon:'⚗',  label:'Cetonas',  short:''},
  {id:'hydration',   icon:'💧', label:'Agua',     short:''},
  {id:'supplements', icon:'💊', label:'Supls.',   short:''},
  {id:'history',     icon:'📊', label:'Historial',short:''},
];

// ─── Dashboard ───────────────────────────────────────────
function DashboardScreen({state}) {
  const {gender,bodyType,weight,height,age,ketones,netCarbsToday,sleepHours,loadVolume,adherenceDays,supplements} = state;
  const bmi    = weight&&height ? calcBMI(weight,height) : null;
  const tdee   = weight&&height ? calcTDEE({w:weight,h:height,age,gender:gender||'M'}) : null;
  const inflamm = calcInflammation({ketones,netCarbs:netCarbsToday,stress:3,sleep:sleepHours||7});
  const status = getStatus({ketones,netCarbs:netCarbsToday,inflamm});
  const avLvl  = calcAvatarLevel(loadVolume,ketones,adherenceDays);
  const av     = analyzeAvatar(avLvl);
  const keto   = analyzeKetones(ketones);
  const BT_EMOJIS = {ECTOMORFO:'⚡',MESOMORFO:'🦁',ENDOMORFO:'🏔️'};

  const [tickIdx, setTick] = useState(0);
  const insights = [
    ketones<0.5?'⚡ Inicia ayuno 16:8 para entrar en cetosis.':'✓ Cetosis activa. Sistema metabólico eficiente.',
    netCarbsToday>25?`↓ ${netCarbsToday-25}g de carbs extra. Objetivo: < 25g.`:'✓ Carbos dentro del límite keto.',
    sleepHours>0&&sleepHours<7?'🌙 Déficit de sueño detectado. Afecta cetonas y recuperación.':'🌙 Sueño óptimo apoya la cetosis y hormona de crecimiento.',
    adherenceDays>=30?'🔥 30+ días keto. Tu cuerpo es una máquina de quemar grasa.':'Cada día de adherencia keto fortalece tu metabolismo.',
  ];
  useEffect(()=>{const t=setInterval(()=>setTick(i=>(i+1)%insights.length),4000);return()=>clearInterval(t);},[]);

  return (
    <ScrollView style={{flex:1}} contentContainerStyle={{padding:S.lg,gap:14,paddingBottom:80}}>
      {/* Header */}
      <View style={d.hdr}>
        <View>
          <Text style={d.logo}><Text style={{color:C.primary}}>Z</Text>IMA</Text>
          <Text style={d.motor}>MOTOR SIM v3.0 · ACTIVO</Text>
        </View>
        <View style={d.avBubble}>
          <Text style={{fontSize:36}}>{av.emoji}</Text>
          <Text style={[d.avLvl,{color:av.color}]}>NV.{avLvl}</Text>
        </View>
      </View>

      {/* Status metabólico */}
      <View style={[d.statusCard,{borderLeftColor:status.color}]}>
        <View style={d.statusRow}>
          <View style={[d.statusDot,{backgroundColor:status.color}]}/>
          <Text style={[d.statusLabel,{color:status.color}]}>{status.status}</Text>
        </View>
        <Text style={d.statusMsg}>{status.msg}</Text>
      </View>

      {/* Grid métricas */}
      <View style={d.grid}>
        {[
          {l:'CETONAS',v:`${ketones.toFixed(1)}`,u:'mmol/L',c:keto.color},
          {l:'INFLAMACIÓN',v:`${Math.round(inflamm*100)}%`,u:'',c:inflamm<.3?C.success:inflamm<.6?C.warning:C.danger},
          {l:'PESO',v:`${weight?.toFixed(1)||'—'}`,u:'kg',c:C.text2},
          {l:'SUEÑO',v:`${sleepHours||'—'}`,u:'h',c:sleepHours>=7?C.success:C.warning},
        ].map(m=>(
          <View key={m.l} style={[d.metric,{borderColor:m.c+'30'}]}>
            <Text style={d.metricL}>{m.l}</Text>
            <Text style={[d.metricV,{color:m.c}]}>{m.v}</Text>
            {m.u?<Text style={d.metricU}>{m.u}</Text>:null}
          </View>
        ))}
      </View>

      {/* IMC */}
      {bmi&&<View style={[d.bmiCard,{borderColor:bmi.color+'40'}]}><Text style={d.bmiL}>IMC</Text><View style={d.bmiRow}><Text style={[d.bmiV,{color:bmi.color}]}>{bmi.value}</Text><Text style={[d.bmiCat,{color:bmi.color}]}>{bmi.cat}</Text></View></View>}

      {/* TDEE */}
      {tdee&&(
        <View style={d.tdeeCard}>
          <Text style={d.tdeeTitle}>PROTOCOLO NUTRICIONAL</Text>
          <View style={d.tdeeRow}>
            {[['TDEE',`${tdee.tdee}kcal`,C.primary],['PROTEÍNA',`${tdee.protein}g`,C.success],['GRASA',`${tdee.fat}g`,C.warning],['CARBS MÁX','25g',C.danger]].map(([l,v,c])=>(
              <View key={l} style={d.tdeeStat}><Text style={[d.tdeeV,{color:c}]}>{v}</Text><Text style={d.tdeeL}>{l}</Text></View>
            ))}
          </View>
        </View>
      )}

      {/* Avatar evolucion */}
      <View style={[d.avCard,{borderColor:av.color+'40'}]}>
        <Text style={d.avCardTitle}>AVATAR · {av.label.toUpperCase()}</Text>
        <Text style={{fontSize:52,textAlign:'center'}}>{av.emoji}</Text>
        <Text style={[d.avDesc,{color:av.color}]}>{av.desc}</Text>
        <View style={d.avProgress}>
          {[0,1,2,3,4].map(i=>(
            <View key={i} style={[d.avDot,{backgroundColor:i<=avLvl?av.color:C.border}]}/>
          ))}
        </View>
        <Text style={d.avVol}>Volumen acumulado: {loadVolume.toLocaleString()} reps</Text>
      </View>

      {/* Ticker */}
      <View style={d.ticker}><View style={d.tickerDot}/><Text style={d.tickerTxt} numberOfLines={2}>{insights[tickIdx]}</Text></View>

      {/* Stack de suplementos */}
      {supplements?.length>0&&(
        <View style={d.stackCard}>
          <Text style={d.stackLbl}>MI STACK HOY · {supplements.length} suplementos activos</Text>
          <Text style={d.stackSub}>Ve a Suplementos para ver tus horarios</Text>
        </View>
      )}
    </ScrollView>
  );
}

// ─── Root App ────────────────────────────────────────────
export default function App() {
  const [tab, setTab]      = useState('dashboard');
  const [st, setSt]        = useState(INITIAL);
  const [loading, setLoad] = useState(true);

  useEffect(()=>{
    AsyncStorage.getItem(STORAGE_KEY).then(raw=>{
      if(raw){try{setSt({...INITIAL,...JSON.parse(raw)});}catch(e){}}
      setLoad(false);
    });
  },[]);

  const update = useCallback((patch)=>{
    setSt(prev=>{
      const next = {...prev,...patch};
      AsyncStorage.setItem(STORAGE_KEY,JSON.stringify(next));
      return next;
    });
  },[]);

  const completeOnboarding = (p)=>{
    update({
      onboardingDone:true,
      gender:p.gender, bodyType:p.bodyType,
      weight:parseFloat(p.weight)||75,
      height:parseFloat(p.height)||175,
      age:parseInt(p.age)||30,
      waistCm:parseFloat(p.waistCm)||null,
      armsCm:parseFloat(p.armsCm)||null,
      legsCm:parseFloat(p.legsCm)||null,
      chestCm:parseFloat(p.chestCm)||null,
    });
  };

  if(loading) return (
    <View style={a.loading}>
      <StatusBar barStyle="light-content" backgroundColor={C.bg}/>
      <ActivityIndicator color={C.primary} size="large"/>
      <Text style={a.loadingTxt}>INICIANDO MOTOR SIM...</Text>
    </View>
  );

  if(!st.onboardingDone) return (
    <>
      <StatusBar barStyle="light-content" backgroundColor={C.bg}/>
      <OnboardingScreen onComplete={completeOnboarding}/>
    </>
  );

  const props = {state:st, onUpdate:update};
  const screens = {
    dashboard:   <DashboardScreen   {...props}/>,
    training:    <TrainingScreen    {...props}/>,
    kitchen:     <KitchenScreen     {...props}/>,
    sleep:       <SleepScreen       {...props}/>,
    ketones:     <KetonesScreen     {...props}/>,
    hydration:   <HydrationScreen   {...props}/>,
    supplements: <SupplementsScreen {...props}/>,
    history:     <HistoryScreen     {...props}/>,
  };

  return (
    <SafeAreaView style={a.root}>
      <StatusBar barStyle="light-content" backgroundColor={C.bg}/>
      <View style={a.screen}>{screens[tab]}</View>
      {/* Navigation - scroll horizontal para 8 tabs */}
      <View style={a.nav}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={a.navScroll}>
          {NAV.map(item=>{
            const active = tab===item.id;
            return (
              <TouchableOpacity key={item.id} style={[a.navItem, active&&a.navItemA]} onPress={()=>setTab(item.id)} activeOpacity={0.7}>
                <Text style={[a.navIcon, active&&a.navIconA]}>{item.icon}</Text>
                <Text style={[a.navLbl, active&&a.navLblA]}>{item.label}</Text>
                {active&&<View style={[a.navDot,{backgroundColor:C.primary}]}/>}
              </TouchableOpacity>
            );
          })}
        </ScrollView>
      </View>
    </SafeAreaView>
  );
}

// Dashboard styles
const d = StyleSheet.create({
  hdr:{flexDirection:'row',justifyContent:'space-between',alignItems:'center'},
  logo:{fontFamily:F.mono,fontWeight:F.bk,fontSize:38,color:C.text,letterSpacing:-1},
  motor:{fontFamily:F.mono,fontSize:F.xs,color:C.primary,letterSpacing:2.5,marginTop:2},
  avBubble:{alignItems:'center',gap:3,backgroundColor:C.bg2,borderWidth:1,borderColor:C.border,borderRadius:R.lg,padding:S.md},
  avLvl:{fontFamily:F.mono,fontWeight:F.bk,fontSize:F.xs,letterSpacing:1},
  statusCard:{backgroundColor:C.bg2,borderWidth:1,borderColor:C.border,borderLeftWidth:3,borderRadius:R.lg,padding:S.md,gap:6},
  statusRow:{flexDirection:'row',alignItems:'center',gap:8},
  statusDot:{width:8,height:8,borderRadius:4},
  statusLabel:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.sm,letterSpacing:2},
  statusMsg:{fontFamily:F.mono,fontSize:F.xs,color:C.text,lineHeight:18},
  grid:{flexDirection:'row',flexWrap:'wrap',gap:10},
  metric:{flex:1,minWidth:'45%',backgroundColor:C.bg2,borderWidth:1,borderRadius:R.lg,padding:S.md,gap:3,alignItems:'center'},
  metricL:{fontFamily:F.mono,fontSize:8,color:C.text3,letterSpacing:2},
  metricV:{fontFamily:F.mono,fontWeight:F.bk,fontSize:F.xxl},
  metricU:{fontFamily:F.mono,fontSize:F.xs,color:C.text2},
  bmiCard:{backgroundColor:C.bg2,borderWidth:1,borderRadius:R.lg,padding:S.md,gap:6},
  bmiL:{fontFamily:F.mono,fontSize:F.xs,color:C.primary,letterSpacing:2},
  bmiRow:{flexDirection:'row',alignItems:'baseline',gap:12},
  bmiV:{fontFamily:F.mono,fontWeight:F.bk,fontSize:F.xxl},
  bmiCat:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.base},
  tdeeCard:{backgroundColor:C.bg2,borderWidth:1,borderColor:C.border,borderRadius:R.lg,padding:S.md,gap:10},
  tdeeTitle:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.xs,color:C.primary,letterSpacing:2},
  tdeeRow:{flexDirection:'row',justifyContent:'space-around'},
  tdeeStat:{alignItems:'center',gap:3},
  tdeeV:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.sm},
  tdeeL:{fontFamily:F.mono,fontSize:F.xs-1,color:C.text3,letterSpacing:1},
  avCard:{backgroundColor:C.bg2,borderWidth:1,borderRadius:R.xl,padding:S.xl,gap:10,alignItems:'center'},
  avCardTitle:{fontFamily:F.mono,fontWeight:F.bk,fontSize:F.xs,color:C.primary,letterSpacing:3,alignSelf:'flex-start'},
  avDesc:{fontFamily:F.mono,fontSize:F.sm,letterSpacing:1},
  avProgress:{flexDirection:'row',gap:10,marginTop:4},
  avDot:{width:10,height:10,borderRadius:5},
  avVol:{fontFamily:F.mono,fontSize:F.xs,color:C.text3},
  ticker:{flexDirection:'row',gap:8,alignItems:'center',backgroundColor:C.bg2,borderWidth:1,borderColor:C.border,borderRadius:R.md,padding:S.md},
  tickerDot:{width:6,height:6,borderRadius:3,backgroundColor:C.primary},
  tickerTxt:{flex:1,fontFamily:F.mono,fontSize:F.xs,color:C.text2,lineHeight:17},
  stackCard:{backgroundColor:C.bg2,borderWidth:1,borderColor:C.primary+'30',borderRadius:R.lg,padding:S.md,gap:4},
  stackLbl:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.xs,color:C.primary,letterSpacing:2},
  stackSub:{fontFamily:F.mono,fontSize:F.xs,color:C.text2},
});

// App styles
const a = StyleSheet.create({
  root:{flex:1,backgroundColor:C.bg},
  screen:{flex:1},
  loading:{flex:1,backgroundColor:C.bg,alignItems:'center',justifyContent:'center',gap:16},
  loadingTxt:{color:C.text2,fontFamily:F.mono,fontSize:F.xs,letterSpacing:3},
  nav:{backgroundColor:C.bg2,borderTopWidth:1,borderTopColor:C.border},
  navScroll:{paddingHorizontal:S.sm,paddingVertical:6,gap:4},
  navItem:{alignItems:'center',gap:2,paddingVertical:6,paddingHorizontal:10,borderRadius:R.md,minWidth:68},
  navItemA:{backgroundColor:C.primaryDim},
  navIcon:{fontSize:15,color:C.text3},
  navIconA:{color:C.primary},
  navLbl:{fontFamily:F.mono,fontSize:8,color:C.text3,letterSpacing:0.5},
  navLblA:{color:C.primary,fontWeight:F.s},
  navDot:{width:3,height:3,borderRadius:1.5,marginTop:1},
});
