/**
 * ZIMA v3 · screens/OnboardingScreen.js
 * Introducción keto + configuración completa de perfil
 */
import React, { useState, useRef } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, ScrollView,
  TextInput, SafeAreaView, Animated,
} from 'react-native';
import { BODY_TYPES } from '../data/index';
import { C, F, S, R } from '../theme/index';

const STEPS = ['INTRO','TIPO_CORPORAL','DATOS','MEDIDAS','AVATAR','LISTO'];

const IntroSlides = [
  {
    icon:'🔥',
    title:'¿Qué es el estilo\ncetogénico?',
    body:'El cuerpo tiene dos fuentes de combustible: glucosa (carbohidratos) y cetonas (grasas). Cuando reduces los carbohidratos a menos de 25g diarios, tu hígado comienza a producir cetonas a partir de la grasa almacenada.\n\nEste estado se llama cetosis.',
  },
  {
    icon:'🧬',
    title:'Miles de años\nde evolución',
    body:'Durante cientos de miles de años, nuestros antepasados no tenían acceso constante a carbohidratos. El cuerpo humano evolucionó para sobrevivir — y rendir al máximo — usando grasa como combustible principal.\n\nLa cetosis no es una dieta moderna. Es nuestro estado metabólico ancestral.',
  },
  {
    icon:'⚡',
    title:'Adaptación\nmetabólica',
    body:'Cuando el cuerpo se adapta a quemar grasa (keto-adaptación), obtienes:\n\n• Energía estable sin bajones\n• Claridad mental elevada\n• Acceso a reservas de grasa 24/7\n• Menor inflamación sistémica\n• Control del hambre mejorado',
  },
  {
    icon:'🌿',
    title:'Un estilo\nde vida',
    body:'ZIMA no impone reglas estrictas.\n\nSu objetivo es educarte, orientarte y acompañarte.\n\nCada persona es diferente. Tu metabolismo es único. ZIMA te ayuda a entender cómo funciona tu cuerpo y a optimizarlo progresivamente.',
  },
];

export default function OnboardingScreen({ onComplete }) {
  const [step, setStep]     = useState(0);
  const [slide, setSlide]   = useState(0);
  const [profile, setP]     = useState({ gender:null, bodyType:null, weight:'', height:'', age:'', armsCm:'', waistCm:'', legsCm:'', chestCm:'' });
  const fadeAnim = useRef(new Animated.Value(1)).current;

  const up = (k,v) => setP(p => ({...p,[k]:v}));

  const canNext = () => {
    if (STEPS[step]==='TIPO_CORPORAL') return !!profile.bodyType;
    if (STEPS[step]==='DATOS') return profile.gender && profile.weight && profile.height && profile.age;
    return true;
  };

  const goNext = () => {
    Animated.sequence([
      Animated.timing(fadeAnim,{toValue:0,duration:150,useNativeDriver:true}),
      Animated.timing(fadeAnim,{toValue:1,duration:250,useNativeDriver:true}),
    ]).start();
    if (STEPS[step]==='INTRO' && slide < IntroSlides.length-1) { setSlide(s=>s+1); return; }
    setStep(s => Math.min(s+1, STEPS.length-1));
  };
  const goBack = () => {
    if (STEPS[step]==='INTRO' && slide>0) { setSlide(s=>s-1); return; }
    setStep(s => Math.max(s-1,0));
  };

  const bt = profile.bodyType ? BODY_TYPES[profile.bodyType] : null;
  const prog = ((step + (STEPS[step]==='INTRO'?slide/IntroSlides.length:0)) / (STEPS.length-1))*100;

  const renderContent = () => {
    switch(STEPS[step]) {

      case 'INTRO': {
        const s = IntroSlides[slide];
        return (
          <View style={sty.introWrap}>
            <Text style={sty.zimaHero}><Text style={{color:C.primary}}>Z</Text>IMA</Text>
            <Text style={sty.zimaSub}>MOTOR SIM v3.0</Text>
            <View style={sty.introDivider}/>
            <View style={sty.slideBox}>
              <Text style={sty.slideIcon}>{s.icon}</Text>
              <Text style={sty.slideTitle}>{s.title}</Text>
              <Text style={sty.slideBody}>{s.body}</Text>
            </View>
            <View style={sty.dotRow}>
              {IntroSlides.map((_,i)=>(
                <View key={i} style={[sty.dot, slide===i&&sty.dotActive]}/>
              ))}
            </View>
          </View>
        );
      }

      case 'TIPO_CORPORAL':
        return (
          <View style={sty.section}>
            <Text style={sty.stepTitle}>Tu tipo{'\n'}corporal</Text>
            <Text style={sty.stepSub}>Define cómo responde tu cuerpo al entreno y la nutrición</Text>
            {Object.values(BODY_TYPES).map(bt=>(
              <TouchableOpacity key={bt.id} style={[sty.btCard, profile.bodyType===bt.id&&{borderColor:bt.color,backgroundColor:bt.color+'15'}]} onPress={()=>up('bodyType',bt.id)} activeOpacity={0.8}>
                <View style={sty.btRow}>
                  <Text style={sty.btEmoji}>{bt.emoji}</Text>
                  <View style={{flex:1}}>
                    <Text style={[sty.btName, profile.bodyType===bt.id&&{color:bt.color}]}>{bt.name}</Text>
                    <Text style={sty.btDesc}>{bt.desc}</Text>
                  </View>
                  {profile.bodyType===bt.id && <View style={[sty.check,{backgroundColor:bt.color}]}><Text style={sty.checkTxt}>✓</Text></View>}
                </View>
                <View style={sty.btTraits}>
                  {bt.traits.slice(0,2).map((t,i)=><Text key={i} style={sty.btTrait}>· {t}</Text>)}
                </View>
              </TouchableOpacity>
            ))}
          </View>
        );

      case 'DATOS':
        return (
          <View style={sty.section}>
            <Text style={sty.stepTitle}>Tus datos{'\n'}personales</Text>
            <Text style={sty.stepSub}>Para calcular tu protocolo metabólico exacto</Text>
            <Text style={sty.label}>SEXO</Text>
            <View style={sty.gRow}>
              {[{id:'M',icon:'♂',l:'Hombre'},{id:'F',icon:'♀',l:'Mujer'}].map(g=>(
                <TouchableOpacity key={g.id} style={[sty.gBtn, profile.gender===g.id&&sty.gBtnA]} onPress={()=>up('gender',g.id)} activeOpacity={0.8}>
                  <Text style={[sty.gIcon, profile.gender===g.id&&{color:C.primary}]}>{g.icon}</Text>
                  <Text style={[sty.gLbl, profile.gender===g.id&&{color:C.primary}]}>{g.l}</Text>
                </TouchableOpacity>
              ))}
            </View>
            <Field label="PESO (kg)" value={profile.weight} onChange={v=>up('weight',v)} placeholder="75" />
            <Field label="ALTURA (cm)" value={profile.height} onChange={v=>up('height',v)} placeholder="175" />
            <Field label="EDAD" value={profile.age} onChange={v=>up('age',v)} placeholder="30" />
          </View>
        );

      case 'MEDIDAS':
        return (
          <View style={sty.section}>
            <Text style={sty.stepTitle}>Medidas{'\n'}corporales</Text>
            <Text style={sty.stepSub}>Para seguir tu composición física mes a mes</Text>
            <Field label="CINTURA (cm) *" value={profile.waistCm} onChange={v=>up('waistCm',v)} placeholder="85" />
            <Field label="BRAZOS (cm)" value={profile.armsCm} onChange={v=>up('armsCm',v)} placeholder="35" />
            <Field label="PIERNAS / MUSLO (cm)" value={profile.legsCm} onChange={v=>up('legsCm',v)} placeholder="55" />
            <Field label="PECHO (cm)" value={profile.chestCm} onChange={v=>up('chestCm',v)} placeholder="95" />
            <Text style={sty.note}>* La cintura es el indicador más importante de salud metabólica. Se pedirá actualizar mensualmente.</Text>
          </View>
        );

      case 'AVATAR': {
        const type = BODY_TYPES[profile.bodyType];
        return (
          <View style={sty.section}>
            <Text style={sty.stepTitle}>Tu avatar{'\n'}ZIMA</Text>
            <Text style={sty.stepSub}>Evoluciona con tu progreso real</Text>
            <View style={[sty.avatarPreview, {borderColor:(type?.color||C.primary)+'50'}]}>
              <Text style={{fontSize:72}}>{type?.emoji||'🌱'}</Text>
              <Text style={sty.avatarLvl}>NIVEL 0 · SEMILLA</Text>
              <Text style={sty.avatarMsg}>Tu avatar evoluciona con entrenamiento, cetonas y consistencia.</Text>
            </View>
            <View style={sty.evolutionRow}>
              {['🌱','🌿','🍃','🔥','💎'].map((e,i)=>(
                <View key={i} style={sty.evoItem}>
                  <Text style={{fontSize:24}}>{e}</Text>
                  <View style={[sty.evoDot,{backgroundColor:i===0?C.primary:C.border}]}/>
                </View>
              ))}
            </View>
            {type && (
              <View style={[sty.tipBox,{borderColor:type.color+'40'}]}>
                <Text style={[sty.tipTitle,{color:type.color}]}>PROTOCOLO {type.name.toUpperCase()}</Text>
                {type.ketoTips.map((t,i)=><Text key={i} style={sty.tipText}>· {t}</Text>)}
              </View>
            )}
          </View>
        );
      }

      case 'LISTO':
        return (
          <View style={[sty.section,{alignItems:'center'}]}>
            <Text style={{fontSize:72}}>🚀</Text>
            <Text style={sty.readyTitle}>¡Perfil creado!</Text>
            <Text style={sty.readySub}>ZIMA está listo para acompañarte</Text>
            <View style={sty.sumCard}>
              {[
                ['Tipo corporal', `${BODY_TYPES[profile.bodyType]?.emoji} ${BODY_TYPES[profile.bodyType]?.name}`],
                ['Sexo', profile.gender==='M'?'♂ Hombre':'♀ Mujer'],
                ['Peso', `${profile.weight} kg`],
                ['Altura', `${profile.height} cm`],
                ['Cintura', `${profile.waistCm||'—'} cm`],
              ].map(([l,v])=>(
                <View key={l} style={sty.sumRow}>
                  <Text style={sty.sumLbl}>{l}</Text>
                  <Text style={sty.sumVal}>{v}</Text>
                </View>
              ))}
            </View>
          </View>
        );
    }
  };

  return (
    <SafeAreaView style={sty.root}>
      <View style={sty.progBar}><View style={[sty.progFill,{width:`${prog}%`}]}/></View>
      <Animated.ScrollView style={{flex:1,opacity:fadeAnim}} contentContainerStyle={{padding:S.lg,paddingBottom:100}} showsVerticalScrollIndicator={false}>
        {renderContent()}
      </Animated.ScrollView>
      <View style={sty.navBtns}>
        {(step>0||(step===0&&slide>0)) && (
          <TouchableOpacity style={sty.backBtn} onPress={goBack}>
            <Text style={sty.backTxt}>← Atrás</Text>
          </TouchableOpacity>
        )}
        <TouchableOpacity
          style={[sty.nextBtn, !canNext()&&sty.nextBtnOff, {flex:step>0||slide>0?1:undefined}]}
          onPress={STEPS[step]==='LISTO'?()=>onComplete(profile):goNext}
          disabled={!canNext()}
          activeOpacity={0.85}
        >
          <Text style={sty.nextTxt}>
            {STEPS[step]==='LISTO'?'🚀 INICIAR ZIMA':STEPS[step]==='INTRO'&&slide<IntroSlides.length-1?'SIGUIENTE →':'CONTINUAR →'}
          </Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const Field = ({label,value,onChange,placeholder}) => (
  <View style={{marginBottom:14}}>
    <Text style={sty.label}>{label}</Text>
    <TextInput style={sty.input} value={value} onChangeText={onChange} placeholder={placeholder} placeholderTextColor={C.text3} keyboardType="numeric"/>
  </View>
);

const sty = StyleSheet.create({
  root:{flex:1,backgroundColor:C.bg},
  progBar:{height:3,backgroundColor:C.border},
  progFill:{height:'100%',backgroundColor:C.primary,borderRadius:2},
  introWrap:{gap:16,paddingTop:10},
  zimaHero:{fontFamily:F.mono,fontWeight:F.bk,fontSize:F.hero+8,color:C.text,textAlign:'center',letterSpacing:-1},
  zimaSub:{fontFamily:F.mono,fontSize:F.xs,color:C.primary,textAlign:'center',letterSpacing:4},
  introDivider:{height:1,backgroundColor:C.primaryDim,marginVertical:4},
  slideBox:{backgroundColor:C.bg2,borderWidth:1,borderColor:C.border,borderRadius:R.xl,padding:S.xl,gap:12},
  slideIcon:{fontSize:48,textAlign:'center'},
  slideTitle:{fontFamily:F.mono,fontWeight:F.bk,fontSize:F.xl,color:C.text,textAlign:'center'},
  slideBody:{fontFamily:F.mono,fontSize:F.sm,color:C.text2,lineHeight:20,textAlign:'center'},
  dotRow:{flexDirection:'row',justifyContent:'center',gap:8,paddingTop:4},
  dot:{width:6,height:6,borderRadius:3,backgroundColor:C.border},
  dotActive:{backgroundColor:C.primary,width:18},
  section:{gap:14},
  stepTitle:{fontFamily:F.mono,fontWeight:F.bk,fontSize:F.xxl,color:C.text},
  stepSub:{fontFamily:F.mono,fontSize:F.sm,color:C.text2},
  btCard:{borderWidth:1.5,borderColor:C.border,borderRadius:R.lg,padding:S.md,gap:8,backgroundColor:C.bg2},
  btRow:{flexDirection:'row',gap:10,alignItems:'center'},
  btEmoji:{fontSize:28},
  btName:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.md,color:C.text},
  btDesc:{fontFamily:F.mono,fontSize:F.xs,color:C.text2,marginTop:2},
  btTraits:{gap:3},
  btTrait:{fontFamily:F.mono,fontSize:F.xs,color:C.text3},
  check:{width:24,height:24,borderRadius:12,alignItems:'center',justifyContent:'center'},
  checkTxt:{color:'#000',fontWeight:F.b,fontSize:12},
  label:{fontFamily:F.mono,fontSize:F.xs,color:C.primary,letterSpacing:2,marginBottom:6},
  input:{backgroundColor:C.bg3,borderWidth:1,borderColor:C.border,borderRadius:R.md,padding:14,color:C.text,fontFamily:F.mono,fontSize:F.base},
  gRow:{flexDirection:'row',gap:12,marginBottom:14},
  gBtn:{flex:1,backgroundColor:C.bg2,borderWidth:1,borderColor:C.border,borderRadius:R.md,padding:16,alignItems:'center',gap:4},
  gBtnA:{borderColor:C.primary,backgroundColor:C.primaryDim},
  gIcon:{fontSize:24,color:C.text2},
  gLbl:{fontFamily:F.mono,fontWeight:F.s,color:C.text2},
  note:{fontFamily:F.mono,fontSize:F.xs,color:C.text3,lineHeight:16},
  avatarPreview:{borderWidth:1,borderRadius:R.xl,padding:S.xl,alignItems:'center',gap:10,backgroundColor:C.bg2},
  avatarLvl:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.sm,color:C.primary,letterSpacing:2},
  avatarMsg:{fontFamily:F.mono,fontSize:F.xs,color:C.text2,textAlign:'center'},
  evolutionRow:{flexDirection:'row',justifyContent:'space-around',paddingVertical:8},
  evoItem:{alignItems:'center',gap:6},
  evoDot:{width:8,height:8,borderRadius:4},
  tipBox:{borderWidth:1,borderRadius:R.lg,padding:S.md,gap:6,backgroundColor:C.bg2},
  tipTitle:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.xs,letterSpacing:2},
  tipText:{fontFamily:F.mono,fontSize:F.xs,color:C.text2,lineHeight:17},
  readyTitle:{fontFamily:F.mono,fontWeight:F.bk,fontSize:F.xxl+4,color:C.text,textAlign:'center'},
  readySub:{fontFamily:F.mono,fontSize:F.base,color:C.text2,textAlign:'center'},
  sumCard:{backgroundColor:C.bg2,borderWidth:1,borderColor:C.border,borderRadius:R.lg,padding:S.lg,gap:12,width:'100%'},
  sumRow:{flexDirection:'row',justifyContent:'space-between'},
  sumLbl:{fontFamily:F.mono,fontSize:F.sm,color:C.text2},
  sumVal:{fontFamily:F.mono,fontWeight:F.s,fontSize:F.sm,color:C.text},
  navBtns:{position:'absolute',bottom:0,left:0,right:0,flexDirection:'row',gap:12,padding:S.lg,backgroundColor:C.bg,borderTopWidth:1,borderTopColor:C.border},
  backBtn:{backgroundColor:C.bg2,borderWidth:1,borderColor:C.border,borderRadius:R.lg,paddingVertical:16,paddingHorizontal:20,alignItems:'center'},
  backTxt:{fontFamily:F.mono,fontWeight:F.s,color:C.text2},
  nextBtn:{backgroundColor:C.primary,borderRadius:R.lg,paddingVertical:16,paddingHorizontal:32,alignItems:'center',minWidth:180},
  nextBtnOff:{backgroundColor:C.text3},
  nextTxt:{fontFamily:F.mono,fontWeight:F.bk,fontSize:F.base,color:'#000',letterSpacing:1},
});
