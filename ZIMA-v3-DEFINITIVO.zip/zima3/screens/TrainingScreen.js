/**
 * ZIMA v3 · screens/TrainingScreen.js
 */
import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import { EXERCISES } from '../data/index';
import { C, F, S, R } from '../theme/index';

const CATS = [
  {id:'CASA',    icon:'🏠', label:'Casa'},
  {id:'PARQUE',  icon:'🌳', label:'Parque'},
  {id:'GIMNASIO',icon:'🏋️', label:'Gimnasio'},
];

const AvatarDemo = ({exercise, env}) => {
  const demos = {
    CASA:   {bg:'🏠', surface:'suelo'},
    PARQUE: {bg:'🌳', surface:'barras'},
    GIMNASIO:{bg:'🏋️', surface:'máquina'},
  };
  const env_ = demos[env]||demos.CASA;
  return (
    <View style={sty.demoBox}>
      <Text style={sty.demoEnv}>{env_.bg}</Text>
      <View style={sty.demoFigure}>
        <Text style={{fontSize:48}}>{exercise.emoji}</Text>
        <View style={sty.demoStick}>
          <View style={[sty.stHead,{borderColor:C.primary}]}/>
          <View style={sty.stBody}/>
          <View style={sty.stLegs}/>
        </View>
      </View>
      <Text style={sty.demoLabel}>{exercise.name} · {env_.surface}</Text>
    </View>
  );
};

export default function TrainingScreen({state, onUpdate}) {
  const [cat,setCat]      = useState('CASA');
  const [sel,setSel]      = useState({});
  const [sets,setSets]    = useState({});
  const [view,setView]    = useState('CATALOG');
  const [demo,setDemo]    = useState(null);

  const catEx = EXERCISES.filter(e=>e.cat===cat);
  const selList = Object.values(sel);
  const totalReps = selList.reduce((a,e)=>(a+(sets[e.id]||e.sets)*e.reps),0);

  const toggle = (ex) => {
    setSel(p=>{const n={...p}; if(n[ex.id])delete n[ex.id]; else n[ex.id]=ex; return n;});
    if(!sets[ex.id]) setSets(p=>({...p,[ex.id]:ex.sets}));
  };
  const updSets = (id,v) => setSets(p=>({...p,[id]:v}));

  const diffColor = {BÁSICO:C.success,INTERMEDIO:C.warning,AVANZADO:C.danger,ÉLITE:C.secondary};

  return (
    <View style={sty.root}>
      <View style={sty.hdr}>
        <Text style={sty.hdrTitle}>ENTRENAMIENTO</Text>
        <View style={sty.toggle}>
          {['CATALOG','RUTINA'].map(v=>(
            <TouchableOpacity key={v} style={[sty.tBtn, view===v&&sty.tBtnA]} onPress={()=>setView(v)}>
              <Text style={[sty.tTxt, view===v&&sty.tTxtA]}>{v==='CATALOG'?'CATÁLOGO':`MI RUTINA${selList.length>0?' ('+selList.length+')':''}`}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {/* Demo modal */}
      {demo && (
        <TouchableOpacity style={sty.demoOverlay} onPress={()=>setDemo(null)} activeOpacity={1}>
          <View style={sty.demoModal}>
            <AvatarDemo exercise={demo} env={cat}/>
            <Text style={sty.demoDesc}>{demo.desc}</Text>
            <Text style={sty.demoClose}>Toca para cerrar</Text>
          </View>
        </TouchableOpacity>
      )}

      {view==='CATALOG'?(
        <>
          <View style={sty.catRow}>
            {CATS.map(c=>(
              <TouchableOpacity key={c.id} style={[sty.catBtn, cat===c.id&&sty.catBtnA]} onPress={()=>setCat(c.id)}>
                <Text style={sty.catIcon}>{c.icon}</Text>
                <Text style={[sty.catLbl, cat===c.id&&{color:C.primary}]}>{c.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
          <ScrollView style={{flex:1}} contentContainerStyle={{padding:S.lg,gap:10,paddingBottom:100}}>
            {catEx.map(ex=>{
              const isOn = !!sel[ex.id];
              return (
                <View key={ex.id} style={[sty.exCard, isOn&&sty.exCardOn]}>
                  <TouchableOpacity style={sty.exRow} onPress={()=>toggle(ex)} activeOpacity={0.85}>
                    <Text style={sty.exEmoji}>{ex.emoji}</Text>
                    <View style={{flex:1}}>
                      <Text style={sty.exName}>{ex.name}</Text>
                      <Text style={sty.exMuscle}>{ex.muscle}</Text>
                    </View>
                    <View style={[sty.diffBadge,{backgroundColor:diffColor[ex.diff]+'20',borderColor:diffColor[ex.diff]+'50'}]}>
                      <Text style={[sty.diffTxt,{color:diffColor[ex.diff]}]}>{ex.diff}</Text>
                    </View>
                  </TouchableOpacity>
                  {isOn&&(
                    <View style={sty.exExpand}>
                      <View style={sty.setsRow}>
                        <Text style={sty.setsLbl}>SERIES</Text>
                        <TouchableOpacity style={sty.stepBtn} onPress={()=>updSets(ex.id,Math.max(1,(sets[ex.id]||ex.sets)-1))}><Text style={sty.stepTxt}>−</Text></TouchableOpacity>
                        <Text style={sty.setsVal}>{sets[ex.id]||ex.sets}</Text>
                        <TouchableOpacity style={sty.stepBtn} onPress={()=>updSets(ex.id,Math.min(8,(sets[ex.id]||ex.sets)+1))}><Text style={sty.stepTxt}>+</Text></TouchableOpacity>
                        <Text style={sty.repsLbl}>× {ex.reps} {ex.repUnit||'reps'}</Text>
                      </View>
                      <TouchableOpacity style={sty.demoBtn} onPress={()=>setDemo(ex)}>
                        <Text style={sty.demoBtnTxt}>▶ Ver cómo se hace</Text>
                      </TouchableOpacity>
                    </View>
                  )}
                </View>
              );
            })}
          </ScrollView>
          {selList.length>0&&(
            <TouchableOpacity style={sty.pill} onPress={()=>setView('RUTINA')}>
              <Text style={sty.pillTxt}>Mi rutina ({selList.length}) →</Text>
            </TouchableOpacity>
          )}
        </>
      ):(
        <ScrollView style={{flex:1}} contentContainerStyle={{padding:S.lg,gap:12,paddingBottom:100}}>
          {selList.length===0?(
            <View style={sty.empty}>
              <Text style={{fontSize:48}}>🏋️</Text>
              <Text style={sty.emptyTxt}>Ve al catálogo y selecciona ejercicios</Text>
            </View>
          ):(
            <>
              <View style={sty.sumCard}>
                <Text style={sty.sumTitle}>RESUMEN DE HOY</Text>
                <View style={sty.sumRow}>
                  {[['EJERCICIOS',selList.length,C.primary],['SERIES TOT.',selList.reduce((a,e)=>a+(sets[e.id]||e.sets),0),C.success],['REPS EST.',totalReps,C.warning]].map(([l,v,cl])=>(
                    <View key={l} style={sty.sumStat}><Text style={[sty.sumStatV,{color:cl}]}>{v}</Text><Text style={sty.sumStatL}>{l}</Text></View>
                  ))}
                </View>
              </View>
              {selList.map((ex,i)=>(
                <View key={ex.id} style={sty.workCard}>
                  <View style={sty.workRow}>
                    <Text style={sty.workNum}>{i+1}</Text>
                    <Text style={{fontSize:22}}>{ex.emoji}</Text>
                    <View style={{flex:1}}>
                      <Text style={sty.workName}>{ex.name}</Text>
                      <Text style={[sty.workDet,{color:C.primary}]}>{sets[ex.id]||ex.sets} series × {ex.reps} {ex.repUnit||'reps'}</Text>
                    </View>
                    <TouchableOpacity onPress={()=>toggle(ex)}><Text style={{color:C.text3,fontSize:16}}>✕</Text></TouchableOpacity>
                  </View>
                  <Text style={sty.workDesc}>{ex.desc}</Text>
                </View>
              ))}
              <TouchableOpacity style={sty.saveBtn} onPress={()=>{onUpdate?.({loadVolume:(state?.loadVolume||0)+totalReps});alert(`✅ Sesión guardada! +${totalReps} volumen acumulado.`)}} activeOpacity={0.85}>
                <Text style={sty.saveTxt}>⚔️ GUARDAR SESIÓN</Text>
              </TouchableOpacity>
            </>
          )}
        </ScrollView>
      )}
    </View>
  );
}

const sty = StyleSheet.create({
  root:{flex:1,backgroundColor:C.bg},
  hdr:{padding:S.lg,gap:12,borderBottomWidth:1,borderBottomColor:C.border},
  hdrTitle:{fontFamily:F.mono,fontWeight:F.bk,fontSize:F.lg,color:C.primary,letterSpacing:3},
  toggle:{flexDirection:'row',backgroundColor:C.bg2,borderRadius:R.md,padding:3,borderWidth:1,borderColor:C.border},
  tBtn:{flex:1,paddingVertical:8,alignItems:'center',borderRadius:R.sm-2},
  tBtnA:{backgroundColor:C.primary},
  tTxt:{fontFamily:F.mono,fontWeight:F.s,fontSize:F.xs,color:C.text3,letterSpacing:1},
  tTxtA:{color:'#000'},
  catRow:{flexDirection:'row',padding:S.md,gap:8,borderBottomWidth:1,borderBottomColor:C.border},
  catBtn:{flex:1,backgroundColor:C.bg2,borderWidth:1,borderColor:C.border,borderRadius:R.md,paddingVertical:10,alignItems:'center',gap:4},
  catBtnA:{backgroundColor:C.primaryDim,borderColor:C.primary},
  catIcon:{fontSize:18},
  catLbl:{fontFamily:F.mono,fontSize:F.xs,color:C.text2},
  exCard:{backgroundColor:C.bg2,borderWidth:1,borderColor:C.border,borderRadius:R.lg,padding:S.md,gap:10},
  exCardOn:{borderColor:C.primary,backgroundColor:C.primaryDim},
  exRow:{flexDirection:'row',gap:10,alignItems:'center'},
  exEmoji:{fontSize:22},
  exName:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.base,color:C.text},
  exMuscle:{fontFamily:F.mono,fontSize:F.xs,color:C.text2},
  diffBadge:{borderWidth:1,borderRadius:R.sm,paddingHorizontal:8,paddingVertical:3},
  diffTxt:{fontFamily:F.mono,fontSize:F.xs,fontWeight:F.b,letterSpacing:1},
  exExpand:{gap:10},
  setsRow:{flexDirection:'row',alignItems:'center',gap:12,backgroundColor:C.bg3,borderRadius:R.md,padding:S.md},
  setsLbl:{fontFamily:F.mono,fontSize:F.xs,color:C.primary,letterSpacing:2,flex:1},
  stepBtn:{width:30,height:30,backgroundColor:C.bg2,borderRadius:R.sm,alignItems:'center',justifyContent:'center',borderWidth:1,borderColor:C.border},
  stepTxt:{color:C.primary,fontSize:18,fontFamily:F.mono},
  setsVal:{fontFamily:F.mono,fontWeight:F.bk,fontSize:F.xl,color:C.primary,minWidth:28,textAlign:'center'},
  repsLbl:{fontFamily:F.mono,fontSize:F.sm,color:C.text2},
  demoBtn:{backgroundColor:C.bg3,borderWidth:1,borderColor:C.borderHi,borderRadius:R.md,paddingVertical:10,alignItems:'center'},
  demoBtnTxt:{fontFamily:F.mono,fontSize:F.sm,color:C.primary,letterSpacing:1},
  // Demo
  demoOverlay:{position:'absolute',top:0,left:0,right:0,bottom:0,backgroundColor:'rgba(0,0,0,0.85)',zIndex:100,justifyContent:'center',alignItems:'center',padding:S.xl},
  demoModal:{backgroundColor:C.bg2,borderWidth:1,borderColor:C.primary+'60',borderRadius:R.xl,padding:S.xl,width:'100%',gap:14,alignItems:'center'},
  demoBox:{alignItems:'center',gap:8},
  demoEnv:{fontSize:40},
  demoFigure:{flexDirection:'row',gap:10,alignItems:'center'},
  demoStick:{alignItems:'center',gap:2},
  stHead:{width:14,height:14,borderRadius:7,borderWidth:2},
  stBody:{width:2,height:20,backgroundColor:C.text2},
  stLegs:{flexDirection:'row',gap:4},
  demoLabel:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.sm,color:C.primary,letterSpacing:1},
  demoDesc:{fontFamily:F.mono,fontSize:F.sm,color:C.text2,textAlign:'center',lineHeight:19},
  demoClose:{fontFamily:F.mono,fontSize:F.xs,color:C.text3},
  // Workout
  sumCard:{backgroundColor:C.bg2,borderWidth:1,borderColor:C.primary+'40',borderRadius:R.lg,padding:S.lg,gap:12},
  sumTitle:{fontFamily:F.mono,fontWeight:F.b,color:C.primary,fontSize:F.xs,letterSpacing:2},
  sumRow:{flexDirection:'row',justifyContent:'space-around'},
  sumStat:{alignItems:'center',gap:4},
  sumStatV:{fontFamily:F.mono,fontWeight:F.bk,fontSize:F.xxl},
  sumStatL:{fontFamily:F.mono,fontSize:F.xs,color:C.text3,letterSpacing:1},
  workCard:{backgroundColor:C.bg2,borderWidth:1,borderColor:C.border,borderRadius:R.lg,padding:S.md,gap:8},
  workRow:{flexDirection:'row',gap:10,alignItems:'center'},
  workNum:{fontFamily:F.mono,fontWeight:F.bk,fontSize:F.lg,color:C.text3,width:24},
  workName:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.base,color:C.text},
  workDet:{fontFamily:F.mono,fontSize:F.xs},
  workDesc:{fontFamily:F.mono,fontSize:F.xs,color:C.text2,lineHeight:17},
  saveBtn:{backgroundColor:C.primary,borderRadius:R.lg,paddingVertical:16,alignItems:'center',marginTop:8},
  saveTxt:{fontFamily:F.mono,fontWeight:F.bk,fontSize:F.base,color:'#000',letterSpacing:2},
  pill:{position:'absolute',bottom:20,alignSelf:'center',backgroundColor:C.primary,borderRadius:R.full,paddingVertical:12,paddingHorizontal:24},
  pillTxt:{fontFamily:F.mono,fontWeight:F.b,color:'#000',fontSize:F.sm,letterSpacing:1},
  empty:{alignItems:'center',paddingTop:60,gap:12},
  emptyTxt:{fontFamily:F.mono,color:C.text2,fontSize:F.base,textAlign:'center'},
});
