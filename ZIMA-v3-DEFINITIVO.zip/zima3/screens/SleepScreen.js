/**
 * ZIMA v3 · screens/SleepScreen.js
 */
import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, Switch } from 'react-native';
import { analyzeSleep } from '../engine/SIMEngine';
import { C, F, S, R } from '../theme/index';

export default function SleepScreen({state, onUpdate}) {
  const gender = state?.gender||'M';
  const [hours, setHours]   = useState(state?.sleepHours||0);
  const [history, setHist]  = useState(state?.sleepHistory||[]);
  const [snoring, setSnoring]= useState(state?.snoringEnabled||false);

  const a = analyzeSleep(hours, gender);
  const opts = [4,4.5,5,5.5,6,6.5,7,7.5,8,8.5,9,9.5,10];

  const save = () => {
    const e = {hours, quality:a.quality, ts:Date.now(), date:new Date().toLocaleDateString('es-ES')};
    const nh = [e,...history].slice(0,30);
    setHist(nh);
    onUpdate?.({sleepHours:hours, sleepHistory:nh});
  };

  const avg = history.length ? (history.reduce((a,b)=>a+b.hours,0)/history.length).toFixed(1) : '—';

  return (
    <View style={sty.root}>
      <View style={sty.hdr}><Text style={sty.hdrTitle}>SUEÑO</Text><Text style={sty.hdrSub}>Recuperación y rendimiento</Text></View>
      <ScrollView style={{flex:1}} contentContainerStyle={{padding:S.lg,gap:16,paddingBottom:80}}>

        {/* Avatar durmiendo */}
        <View style={[sty.avatarCard,{borderColor:a.color+'40'}]}>
          <Text style={sty.stars}>✦ ✧ ✦</Text>
          <Text style={{fontSize:72}}>{hours>=8?'😴':hours>=6?'😪':hours>=4?'😫':'😶'}</Text>
          {hours>=5&&(
            <View style={sty.zRow}>
              <Text style={[sty.zLetter,{fontSize:11,color:a.color+'60'}]}>z</Text>
              <Text style={[sty.zLetter,{fontSize:15,color:a.color+'80'}]}>z</Text>
              <Text style={[sty.zLetter,{fontSize:20,color:a.color}]}>Z</Text>
            </View>
          )}
          <Text style={[sty.sleepQ,{color:a.color}]}>{a.quality}</Text>
          <Text style={sty.sleepMsg}>{a.msg}</Text>
        </View>

        {/* Selector horas */}
        <Text style={sty.sLabel}>¿CUÁNTAS HORAS DORMISTE?</Text>
        <View style={sty.hoursGrid}>
          {opts.map(h=>(
            <TouchableOpacity key={h} style={[sty.hourBtn, hours===h&&{borderColor:a.color,backgroundColor:a.color+'20'}]} onPress={()=>setHours(h)} activeOpacity={0.7}>
              <Text style={[sty.hourTxt, hours===h&&{color:a.color}]}>{h}h</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Nota género */}
        <View style={sty.gNote}>
          <Text style={{fontSize:22}}>{gender==='F'?'👩':'👨'}</Text>
          <Text style={sty.gNoteTxt}>{gender==='F'?'Las mujeres requieren ~8.5h de sueño por fluctuaciones hormonales. El sueño regula cortisol, estrógeno y progesterona.':'Los hombres requieren ~8h. El 70% de la testosterona diaria se produce durante el sueño profundo (fase REM).'}</Text>
        </View>

        {/* Opción ronquidos */}
        <View style={sty.snoringCard}>
          <View style={{flex:1}}>
            <Text style={sty.snoringTitle}>🎙️ Detección de ronquidos</Text>
            <Text style={sty.snoringDesc}>Activa el micrófono para monitorear ronquidos durante el sueño. Se puede desactivar en cualquier momento.</Text>
          </View>
          <Switch
            value={snoring}
            onValueChange={v=>{setSnoring(v);onUpdate?.({snoringEnabled:v});}}
            trackColor={{false:C.border,true:C.primary+'80'}}
            thumbColor={snoring?C.primary:C.text3}
          />
        </View>
        {snoring&&<View style={sty.snoringActive}><Text style={sty.snoringActiveTxt}>🎙️ Monitoreo activo · Se desactivará automáticamente a las 8am</Text></View>}

        {/* Tips */}
        <View style={sty.tipsCard}>
          <Text style={sty.tipsTitle}>SUEÑO + KETO</Text>
          {['🧲 Magnesio (400mg) mejora sueño profundo en cetosis.','☕ Evita cafeína después de las 2pm.','🌙 Oscuridad total aumenta hormona de crecimiento.','🥑 Las cetonas reducen inflamación cerebral y mejoran el REM.','❄️ Ambiente fresco (18-20°C) optimiza el sueño profundo.'].map((t,i)=><Text key={i} style={sty.tip}>{t}</Text>)}
        </View>

        {hours>0&&(
          <TouchableOpacity style={sty.saveBtn} onPress={save} activeOpacity={0.85}>
            <Text style={sty.saveTxt}>🌙 GUARDAR REGISTRO</Text>
          </TouchableOpacity>
        )}

        {history.length>0&&(
          <View>
            <Text style={sty.sLabel}>ÚLTIMAS {Math.min(history.length,7)} NOCHES</Text>
            <View style={sty.histCard}>
              <View style={sty.histStats}>
                {[['PROMEDIO',`${avg}h`],['BUENAS',`${history.filter(h=>h.quality==='ÓPTIMO'||h.quality==='BUENO').length}`],['TOTAL',`${history.length}`]].map(([l,v])=>(
                  <View key={l} style={{alignItems:'center',gap:3}}><Text style={sty.histStatV}>{v}</Text><Text style={sty.histStatL}>{l}</Text></View>
                ))}
              </View>
              {history.slice(0,7).map((e,i)=>{
                const ea = analyzeSleep(e.hours,gender);
                return (
                  <View key={i} style={sty.histRow}>
                    <Text style={sty.histDate}>{e.date}</Text>
                    <View style={sty.histBar}><View style={[sty.histFill,{width:`${(e.hours/10)*100}%`,backgroundColor:ea.color}]}/></View>
                    <Text style={[sty.histH,{color:ea.color}]}>{e.hours}h</Text>
                    <Text style={[sty.histQ,{color:ea.color}]}>{e.quality}</Text>
                  </View>
                );
              })}
            </View>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const sty = StyleSheet.create({
  root:{flex:1,backgroundColor:C.bg},
  hdr:{padding:S.lg,borderBottomWidth:1,borderBottomColor:C.border,gap:4},
  hdrTitle:{fontFamily:F.mono,fontWeight:F.bk,fontSize:F.lg,color:C.primary,letterSpacing:3},
  hdrSub:{fontFamily:F.mono,fontSize:F.xs,color:C.text2},
  sLabel:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.xs,color:C.primary,letterSpacing:2},
  avatarCard:{backgroundColor:C.bg2,borderWidth:1,borderRadius:R.xl,padding:S.xl,alignItems:'center',gap:8},
  stars:{fontFamily:F.mono,fontSize:F.xs,color:C.text3,letterSpacing:8},
  zRow:{flexDirection:'row',gap:4,alignItems:'flex-end'},
  zLetter:{fontFamily:F.mono,fontWeight:F.bk,letterSpacing:2},
  sleepQ:{fontFamily:F.mono,fontWeight:F.bk,fontSize:F.xl,letterSpacing:2},
  sleepMsg:{fontFamily:F.mono,fontSize:F.xs,color:C.text2,textAlign:'center'},
  hoursGrid:{flexDirection:'row',flexWrap:'wrap',gap:8},
  hourBtn:{paddingHorizontal:14,paddingVertical:10,backgroundColor:C.bg2,borderWidth:1,borderColor:C.border,borderRadius:R.md},
  hourTxt:{fontFamily:F.mono,fontWeight:F.s,fontSize:F.sm,color:C.text2},
  gNote:{flexDirection:'row',gap:10,backgroundColor:C.bg2,borderWidth:1,borderColor:C.border,borderRadius:R.lg,padding:S.md,alignItems:'flex-start'},
  gNoteTxt:{flex:1,fontFamily:F.mono,fontSize:F.xs,color:C.text2,lineHeight:18},
  snoringCard:{flexDirection:'row',gap:10,backgroundColor:C.bg2,borderWidth:1,borderColor:C.border,borderRadius:R.lg,padding:S.md,alignItems:'center'},
  snoringTitle:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.base,color:C.text},
  snoringDesc:{fontFamily:F.mono,fontSize:F.xs,color:C.text2,lineHeight:16,marginTop:2},
  snoringActive:{backgroundColor:C.primaryDim,borderWidth:1,borderColor:C.primary+'40',borderRadius:R.md,padding:S.md},
  snoringActiveTxt:{fontFamily:F.mono,fontSize:F.xs,color:C.primary,textAlign:'center'},
  tipsCard:{backgroundColor:C.bg2,borderWidth:1,borderColor:C.border,borderRadius:R.lg,padding:S.md,gap:8},
  tipsTitle:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.xs,color:C.primary,letterSpacing:2},
  tip:{fontFamily:F.mono,fontSize:F.xs,color:C.text2,lineHeight:18},
  saveBtn:{backgroundColor:C.primary,borderRadius:R.lg,paddingVertical:16,alignItems:'center'},
  saveTxt:{fontFamily:F.mono,fontWeight:F.bk,color:'#000',fontSize:F.base,letterSpacing:2},
  histCard:{backgroundColor:C.bg2,borderWidth:1,borderColor:C.border,borderRadius:R.lg,padding:S.md,gap:10},
  histStats:{flexDirection:'row',justifyContent:'space-around',paddingBottom:10,borderBottomWidth:1,borderBottomColor:C.border},
  histStatV:{fontFamily:F.mono,fontWeight:F.bk,fontSize:F.xl,color:C.text},
  histStatL:{fontFamily:F.mono,fontSize:F.xs,color:C.text3,letterSpacing:1},
  histRow:{flexDirection:'row',alignItems:'center',gap:8},
  histDate:{fontFamily:F.mono,fontSize:F.xs,color:C.text3,width:70},
  histBar:{flex:1,height:4,backgroundColor:C.border,borderRadius:2,overflow:'hidden'},
  histFill:{height:'100%',borderRadius:2},
  histH:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.xs,width:28},
  histQ:{fontFamily:F.mono,fontSize:F.xs,width:70},
});
