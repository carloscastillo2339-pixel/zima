/**
 * ZIMA v3 · screens/KitchenScreen.js
 * Cocina, recetas automáticas + despensa con inventario
 */
import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, TextInput, Alert } from 'react-native';
import { generateRecipes, evaluateFood, KETO_FOODS } from '../data/index';
import { C, F, S, R } from '../theme/index';

export default function KitchenScreen({state, onUpdate}) {
  const [pantry, setPantry]   = useState(state?.pantry || {});  // {nombre: {qty, unit}}
  const [text, setText]       = useState('');
  const [qty, setQty]         = useState('');
  const [unit, setUnit]       = useState('unidades');
  const [view, setView]       = useState('DESPENSA');
  const [expRecipe, setExpR]  = useState(null);

  const pantryList = Object.entries(pantry);
  const recipes    = generateRecipes(Object.keys(pantry));

  const addItem = () => {
    const key = text.trim().toLowerCase();
    if (!key) return;
    const eval_ = evaluateFood(key);
    const newPantry = { ...pantry, [key]: { qty: parseFloat(qty)||1, unit, eval: eval_ } };
    setPantry(newPantry);
    onUpdate?.({ pantry: newPantry });
    setText(''); setQty('');
  };

  const removeItem = (key) => {
    const np = {...pantry}; delete np[key];
    setPantry(np); onUpdate?.({ pantry: np });
  };

  const useInRecipe = (recipe) => {
    const np = {...pantry};
    recipe.matches.forEach(ing => {
      const key = Object.keys(np).find(k => k.includes(ing) || ing.includes(k));
      if (key && np[key]) {
        np[key] = { ...np[key], qty: Math.max(0, (np[key].qty||1) - 1) };
        if (np[key].qty <= 0) delete np[key];
      }
    });
    setPantry(np); onUpdate?.({ pantry: np });
    Alert.alert('✅ Receta usada','Ingredientes descontados de tu despensa.');
  };

  const levelColor = { ÓPTIMO: C.success, PRECAUCIÓN: C.warning, EVITAR: C.danger };

  return (
    <View style={sty.root}>
      <View style={sty.hdr}>
        <Text style={sty.hdrTitle}>COCINA KETO</Text>
        <View style={sty.toggle}>
          {['DESPENSA','RECETAS','ALIMENTOS'].map(v=>(
            <TouchableOpacity key={v} style={[sty.tBtn,view===v&&sty.tBtnA]} onPress={()=>setView(v)}>
              <Text style={[sty.tTxt,view===v&&sty.tTxtA]}>{v==='RECETAS'&&recipes.length>0?`RECETAS(${recipes.length})`:v}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      <ScrollView style={{flex:1}} contentContainerStyle={{padding:S.lg,gap:14,paddingBottom:80}} showsVerticalScrollIndicator={false}>

        {view==='DESPENSA'&&(
          <>
            {/* Agregar ingrediente */}
            <View style={sty.addBox}>
              <Text style={sty.sLabel}>AGREGAR A LA DESPENSA</Text>
              <TextInput style={sty.inp} value={text} onChangeText={setText} placeholder="ej: huevos, carne, queso..." placeholderTextColor={C.text3} onSubmitEditing={addItem} returnKeyType="done"/>
              <View style={sty.addRow}>
                <TextInput style={[sty.inp,{flex:1}]} value={qty} onChangeText={setQty} placeholder="Cantidad" placeholderTextColor={C.text3} keyboardType="numeric"/>
                <View style={sty.unitRow}>
                  {['unidades','g','kg','ml','L'].map(u=>(
                    <TouchableOpacity key={u} style={[sty.unitBtn,unit===u&&sty.unitBtnA]} onPress={()=>setUnit(u)}>
                      <Text style={[sty.unitTxt,unit===u&&{color:C.primary}]}>{u}</Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>
              <TouchableOpacity style={sty.addBtn} onPress={addItem} activeOpacity={0.8}>
                <Text style={sty.addBtnTxt}>+ AGREGAR</Text>
              </TouchableOpacity>
            </View>

            {/* Lista de despensa */}
            {pantryList.length===0?(
              <View style={sty.empty}><Text style={{fontSize:36}}>🥗</Text><Text style={sty.emptyTxt}>Tu despensa está vacía</Text></View>
            ):(
              <>
                <Text style={sty.sLabel}>MI DESPENSA ({pantryList.length} ingredientes)</Text>
                {pantryList.map(([key,item])=>{
                  const low = item.qty <= 2;
                  return (
                    <View key={key} style={[sty.pantryItem, low&&sty.pantryItemLow]}>
                      <View style={{flex:1}}>
                        <Text style={sty.pantryName}>{key}</Text>
                        {item.eval&&<View style={[sty.evalBadge,{backgroundColor:levelColor[item.eval.level]+'20',borderColor:levelColor[item.eval.level]+'40'}]}><Text style={[sty.evalTxt,{color:levelColor[item.eval.level]}]}>{item.eval.level}</Text></View>}
                      </View>
                      <Text style={[sty.pantryQty,low&&{color:C.danger}]}>{item.qty} {item.unit}</Text>
                      {low&&<Text style={sty.lowAlert}>⚠ Poco</Text>}
                      <TouchableOpacity onPress={()=>removeItem(key)} style={{padding:4}}>
                        <Text style={{color:C.text3,fontSize:14}}>✕</Text>
                      </TouchableOpacity>
                    </View>
                  );
                })}
                <TouchableOpacity style={sty.genBtn} onPress={()=>setView('RECETAS')} activeOpacity={0.85}>
                  <Text style={sty.genBtnTxt}>🍳 VER RECETAS CON MI DESPENSA ({recipes.length})</Text>
                </TouchableOpacity>
              </>
            )}
          </>
        )}

        {view==='RECETAS'&&(
          <>
            {recipes.length===0?(
              <View style={sty.empty}><Text style={{fontSize:36}}>👨‍🍳</Text><Text style={sty.emptyTxt}>Agrega ingredientes para generar recetas</Text></View>
            ):(
              <>
                <Text style={sty.sLabel}>{recipes.filter(r=>r.hasAll).length} RECETAS COMPLETAS · {recipes.length} ENCONTRADAS</Text>
                {recipes.map(r=>(
                  <View key={r.id} style={[sty.recCard, expRecipe===r.id&&sty.recCardOn]}>
                    <TouchableOpacity onPress={()=>setExpR(expRecipe===r.id?null:r.id)} activeOpacity={0.85}>
                      <View style={sty.recHdr}>
                        <Text style={{fontSize:28}}>{r.emoji}</Text>
                        <View style={{flex:1}}>
                          <Text style={sty.recName}>{r.name}</Text>
                          <Text style={sty.recTime}>⏱ {r.time}</Text>
                        </View>
                        <View style={[sty.matchBadge,{backgroundColor:(r.hasAll?C.success:C.warning)+'20',borderColor:(r.hasAll?C.success:C.warning)+'50'}]}>
                          <Text style={[sty.matchPct,{color:r.hasAll?C.success:C.warning}]}>{Math.round(r.matchScore)}%</Text>
                        </View>
                      </View>
                      <View style={sty.macRow}>
                        {[['CARBS',r.carbs+'g',r.carbs<=5?C.success:C.warning],['PROT',r.protein+'g',C.primary],['GRASA',r.fat+'g',C.warning]].map(([l,v,cl])=>(
                          <View key={l} style={[sty.mac,{borderColor:cl+'30'}]}><Text style={sty.macLbl}>{l}</Text><Text style={[sty.macVal,{color:cl}]}>{v}</Text></View>
                        ))}
                      </View>
                      {r.missing.length>0&&<Text style={sty.missing}>Falta: {r.missing.join(', ')}</Text>}
                    </TouchableOpacity>
                    {expRecipe===r.id&&(
                      <View style={sty.steps}>
                        <Text style={sty.stepsTitle}>PREPARACIÓN</Text>
                        {r.steps.map((s,i)=>(
                          <View key={i} style={sty.stepRow}>
                            <View style={sty.stepCircle}><Text style={sty.stepN}>{i+1}</Text></View>
                            <Text style={sty.stepTxt}>{s}</Text>
                          </View>
                        ))}
                        {r.hasAll&&(
                          <TouchableOpacity style={sty.useBtn} onPress={()=>useInRecipe(r)} activeOpacity={0.85}>
                            <Text style={sty.useBtnTxt}>✓ Usar receta (descontar ingredientes)</Text>
                          </TouchableOpacity>
                        )}
                      </View>
                    )}
                  </View>
                ))}
              </>
            )}
          </>
        )}

        {view==='ALIMENTOS'&&(
          <>
            <Text style={sty.sLabel}>GUÍA KETO DE ALIMENTOS</Text>
            {[['ÓPTIMO','✓ Totalmente compatibles'],['PRECAUCIÓN','⚠ Con moderación'],['EVITAR','✕ No compatibles']].map(([lvl,title])=>(
              <View key={lvl} style={sty.foodGroup}>
                <Text style={[sty.foodGroupTitle,{color:levelColor[lvl]}]}>{title}</Text>
                {Object.entries(KETO_FOODS).filter(([,f])=>f.level===lvl).map(([name,f])=>(
                  <View key={name} style={sty.foodRow}>
                    <View style={{flex:1}}>
                      <Text style={sty.foodName}>{name}</Text>
                      <Text style={sty.foodDesc}>{f.desc}</Text>
                    </View>
                    <Text style={[sty.foodCarbs,{color:f.keto?C.success:C.danger}]}>{f.carbs}g/100g</Text>
                  </View>
                ))}
              </View>
            ))}
          </>
        )}
      </ScrollView>
    </View>
  );
}

const sty = StyleSheet.create({
  root:{flex:1,backgroundColor:C.bg},
  hdr:{padding:S.lg,gap:12,borderBottomWidth:1,borderBottomColor:C.border},
  hdrTitle:{fontFamily:F.mono,fontWeight:F.bk,fontSize:F.lg,color:C.primary,letterSpacing:3},
  toggle:{flexDirection:'row',backgroundColor:C.bg2,borderRadius:R.md,padding:3,borderWidth:1,borderColor:C.border},
  tBtn:{flex:1,paddingVertical:7,alignItems:'center',borderRadius:R.sm-2},
  tBtnA:{backgroundColor:C.primary},
  tTxt:{fontFamily:F.mono,fontWeight:F.s,fontSize:9,color:C.text3,letterSpacing:1},
  tTxtA:{color:'#000'},
  sLabel:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.xs,color:C.primary,letterSpacing:2},
  addBox:{backgroundColor:C.bg2,borderWidth:1,borderColor:C.border,borderRadius:R.lg,padding:S.md,gap:10},
  inp:{backgroundColor:C.bg3,borderWidth:1,borderColor:C.border,borderRadius:R.md,paddingHorizontal:14,paddingVertical:12,color:C.text,fontFamily:F.mono,fontSize:F.base},
  addRow:{flexDirection:'row',gap:10,alignItems:'center'},
  unitRow:{flexDirection:'row',flexWrap:'wrap',gap:4},
  unitBtn:{paddingHorizontal:8,paddingVertical:5,borderWidth:1,borderColor:C.border,borderRadius:R.full,backgroundColor:C.bg3},
  unitBtnA:{borderColor:C.primary,backgroundColor:C.primaryDim},
  unitTxt:{fontFamily:F.mono,fontSize:F.xs,color:C.text3},
  addBtn:{backgroundColor:C.primary,borderRadius:R.md,paddingVertical:12,alignItems:'center'},
  addBtnTxt:{fontFamily:F.mono,fontWeight:F.b,color:'#000',letterSpacing:1},
  pantryItem:{flexDirection:'row',gap:10,alignItems:'center',backgroundColor:C.bg2,borderWidth:1,borderColor:C.border,borderRadius:R.md,padding:S.md},
  pantryItemLow:{borderColor:C.danger+'50'},
  pantryName:{fontFamily:F.mono,fontWeight:F.s,fontSize:F.base,color:C.text},
  pantryQty:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.base,color:C.text2},
  lowAlert:{fontFamily:F.mono,fontSize:F.xs,color:C.danger,fontWeight:F.b},
  evalBadge:{borderWidth:1,borderRadius:R.sm,paddingHorizontal:6,paddingVertical:2,marginTop:3,alignSelf:'flex-start'},
  evalTxt:{fontFamily:F.mono,fontSize:9,fontWeight:F.b,letterSpacing:1},
  genBtn:{backgroundColor:C.primary,borderRadius:R.lg,paddingVertical:14,alignItems:'center'},
  genBtnTxt:{fontFamily:F.mono,fontWeight:F.b,color:'#000',fontSize:F.sm,letterSpacing:1},
  recCard:{backgroundColor:C.bg2,borderWidth:1,borderColor:C.border,borderRadius:R.lg,padding:S.md,gap:10},
  recCardOn:{borderColor:C.primary+'60'},
  recHdr:{flexDirection:'row',gap:10,alignItems:'center'},
  recName:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.base,color:C.text},
  recTime:{fontFamily:F.mono,fontSize:F.xs,color:C.text2,marginTop:2},
  matchBadge:{borderWidth:1,borderRadius:R.sm,paddingHorizontal:8,paddingVertical:3},
  matchPct:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.xs},
  macRow:{flexDirection:'row',gap:8},
  mac:{flex:1,backgroundColor:C.bg3,borderWidth:1,borderRadius:R.sm,padding:8,alignItems:'center',gap:2},
  macLbl:{fontFamily:F.mono,fontSize:9,color:C.text3,letterSpacing:1},
  macVal:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.sm},
  missing:{fontFamily:F.mono,fontSize:F.xs,color:C.warning},
  steps:{gap:10,borderTopWidth:1,borderTopColor:C.border,paddingTop:8},
  stepsTitle:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.xs,color:C.primary,letterSpacing:2},
  stepRow:{flexDirection:'row',gap:10,alignItems:'flex-start'},
  stepCircle:{width:22,height:22,borderRadius:11,backgroundColor:C.primaryDim,borderWidth:1,borderColor:C.primary,alignItems:'center',justifyContent:'center'},
  stepN:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.xs,color:C.primary},
  stepTxt:{flex:1,fontFamily:F.mono,fontSize:F.sm,color:C.text2,lineHeight:18},
  useBtn:{backgroundColor:C.successDim,borderWidth:1,borderColor:C.success+'50',borderRadius:R.md,paddingVertical:10,alignItems:'center'},
  useBtnTxt:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.sm,color:C.success},
  foodGroup:{gap:8},
  foodGroupTitle:{fontFamily:F.mono,fontWeight:F.bk,fontSize:F.base,letterSpacing:1},
  foodRow:{flexDirection:'row',gap:10,alignItems:'center',backgroundColor:C.bg2,borderWidth:1,borderColor:C.border,borderRadius:R.md,padding:S.md},
  foodName:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.sm,color:C.text},
  foodDesc:{fontFamily:F.mono,fontSize:F.xs,color:C.text2,lineHeight:16},
  foodCarbs:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.xs},
  empty:{alignItems:'center',paddingTop:60,gap:12},
  emptyTxt:{fontFamily:F.mono,color:C.text2,fontSize:F.base,textAlign:'center'},
});
