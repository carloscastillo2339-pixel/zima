/**
 * ZIMA v3 · screens/HydrationScreen.js
 * Sistema completo de hidratación con registro por bebida
 */
import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import { BEVERAGES } from '../data/index';
import { C, F, S, R } from '../theme/index';

const DAILY_GOAL = 2500; // ml

export default function HydrationScreen({state, onUpdate}) {
  const [log, setLog]   = useState(state?.hydrationLog || []);
  const [sel, setSel]   = useState(null);

  const today = new Date().toDateString();
  const todayLog = log.filter(e => new Date(e.ts).toDateString()===today);
  const totalToday = todayLog.reduce((a,b)=>a+b.ml,0);
  const pct = Math.min((totalToday/DAILY_GOAL)*100,100);

  const add = (bev, ml) => {
    const entry = { id: bev.id, name: bev.name, emoji: bev.emoji, ml, ts: Date.now() };
    const newLog = [entry, ...log];
    setLog(newLog);
    onUpdate?.({ hydrationLog: newLog });
    setSel(null);
  };

  const presets = [150, 250, 350, 500];
  const goalColor = pct>=100?C.success:pct>=60?C.primary:pct>=30?C.warning:C.danger;

  return (
    <View style={sty.root}>
      <View style={sty.hdr}><Text style={sty.hdrTitle}>HIDRATACIÓN</Text><Text style={sty.hdrSub}>Registro diario de líquidos</Text></View>

      <ScrollView style={{flex:1}} contentContainerStyle={{padding:S.lg,gap:16,paddingBottom:80}}>

        {/* Indicador principal */}
        <View style={[sty.mainCard,{borderColor:goalColor+'50'}]}>
          <Text style={sty.mainLabel}>HOY</Text>
          <Text style={[sty.mainValue,{color:goalColor}]}>{(totalToday/1000).toFixed(2)}L</Text>
          <Text style={sty.mainGoal}>de {DAILY_GOAL/1000}L objetivo</Text>
          <View style={sty.barTrack}>
            <View style={[sty.barFill,{width:`${pct}%`,backgroundColor:goalColor}]}/>
          </View>
          <Text style={[sty.pctTxt,{color:goalColor}]}>{Math.round(pct)}% completado</Text>
          {totalToday < DAILY_GOAL && (
            <Text style={sty.remaining}>Faltan {((DAILY_GOAL-totalToday)/1000).toFixed(2)}L más</Text>
          )}
        </View>

        {/* Selector de bebida */}
        <Text style={sty.sLabel}>¿QUÉ BEBISTE?</Text>
        <View style={sty.bevGrid}>
          {BEVERAGES.map(bev=>(
            <TouchableOpacity key={bev.id} style={[sty.bevBtn,sel?.id===bev.id&&sty.bevBtnA]} onPress={()=>setSel(bev)} activeOpacity={0.8}>
              <Text style={sty.bevEmoji}>{bev.emoji}</Text>
              <Text style={sty.bevName}>{bev.name}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Si hay bebida seleccionada, mostrar cantidad */}
        {sel&&(
          <View style={sty.qtyCard}>
            <Text style={sty.qtyTitle}>{sel.emoji} {sel.name}</Text>
            <Text style={sty.qtyDesc}>{sel.desc}</Text>
            <Text style={sty.sLabel}>¿CUÁNTO TOMASTE?</Text>
            <View style={sty.presetRow}>
              {presets.map(ml=>(
                <TouchableOpacity key={ml} style={sty.presetBtn} onPress={()=>add(sel,ml)} activeOpacity={0.8}>
                  <Text style={sty.presetTxt}>{ml}ml</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        )}

        {/* Registro de hoy */}
        {todayLog.length>0&&(
          <View>
            <Text style={sty.sLabel}>REGISTRO DE HOY ({todayLog.length} entradas)</Text>
            <View style={sty.logCard}>
              {todayLog.map((e,i)=>(
                <View key={i} style={sty.logRow}>
                  <Text style={{fontSize:20}}>{e.emoji}</Text>
                  <Text style={sty.logName}>{e.name}</Text>
                  <Text style={[sty.logMl,{color:C.primary}]}>{e.ml}ml</Text>
                  <Text style={sty.logTime}>{new Date(e.ts).toLocaleTimeString('es-ES',{hour:'2-digit',minute:'2-digit'})}</Text>
                </View>
              ))}
            </View>
          </View>
        )}

        {/* Tips de hidratación keto */}
        <View style={sty.tipsCard}>
          <Text style={sty.tipsTitle}>HIDRATACIÓN EN KETO</Text>
          {[
            '🧂 Añade sal al agua. En cetosis, los riñones excretan más sodio.',
            '💧 Aumenta consumo en los primeros 14 días de cetosis.',
            '☕ El café y té sin azúcar cuentan como hidratación válida.',
            '🦴 El caldo de huesos repone electrolitos durante el ayuno.',
            '⚡ Los calambres nocturnos = señal de hidratación insuficiente.',
          ].map((t,i)=><Text key={i} style={sty.tip}>{t}</Text>)}
        </View>
      </ScrollView>
    </View>
  );
}

const sty = StyleSheet.create({
  root:{flex:1,backgroundColor:C.bg},
  hdr:{padding:S.lg,borderBottomWidth:1,borderBottomColor:C.border,gap:4},
  hdrTitle:{fontFamily:F.mono,fontWeight:F.bk,fontSize:F.lg,color:C.primary,letterSpacing:3},
  hdrSub:{fontFamily:F.mono,fontSize:F.xs,color:C.text2},
  sLabel:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.xs,color:C.primary,letterSpacing:2},
  mainCard:{backgroundColor:C.bg2,borderWidth:1.5,borderRadius:R.xl,padding:S.xl,alignItems:'center',gap:6},
  mainLabel:{fontFamily:F.mono,fontSize:F.xs,color:C.text3,letterSpacing:3},
  mainValue:{fontFamily:F.mono,fontWeight:F.bk,fontSize:72,lineHeight:80},
  mainGoal:{fontFamily:F.mono,fontSize:F.sm,color:C.text2},
  barTrack:{width:'100%',height:12,backgroundColor:C.border,borderRadius:6,overflow:'hidden',marginTop:4},
  barFill:{height:'100%',borderRadius:6},
  pctTxt:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.base},
  remaining:{fontFamily:F.mono,fontSize:F.xs,color:C.text3},
  bevGrid:{flexDirection:'row',flexWrap:'wrap',gap:8},
  bevBtn:{backgroundColor:C.bg2,borderWidth:1,borderColor:C.border,borderRadius:R.lg,padding:S.md,alignItems:'center',gap:4,minWidth:'28%',flex:1},
  bevBtnA:{borderColor:C.primary,backgroundColor:C.primaryDim},
  bevEmoji:{fontSize:24},
  bevName:{fontFamily:F.mono,fontSize:9,color:C.text2,textAlign:'center'},
  qtyCard:{backgroundColor:C.bg2,borderWidth:1,borderColor:C.primary+'40',borderRadius:R.lg,padding:S.lg,gap:12},
  qtyTitle:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.lg,color:C.text},
  qtyDesc:{fontFamily:F.mono,fontSize:F.xs,color:C.text2,lineHeight:17},
  presetRow:{flexDirection:'row',gap:10},
  presetBtn:{flex:1,backgroundColor:C.primary,borderRadius:R.md,paddingVertical:14,alignItems:'center'},
  presetTxt:{fontFamily:F.mono,fontWeight:F.bk,color:'#000',fontSize:F.base},
  logCard:{backgroundColor:C.bg2,borderWidth:1,borderColor:C.border,borderRadius:R.lg,padding:S.md,gap:10},
  logRow:{flexDirection:'row',gap:10,alignItems:'center'},
  logName:{flex:1,fontFamily:F.mono,fontSize:F.sm,color:C.text},
  logMl:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.sm},
  logTime:{fontFamily:F.mono,fontSize:F.xs,color:C.text3},
  tipsCard:{backgroundColor:C.bg2,borderWidth:1,borderColor:C.border,borderRadius:R.lg,padding:S.md,gap:8},
  tipsTitle:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.xs,color:C.primary,letterSpacing:2},
  tip:{fontFamily:F.mono,fontSize:F.xs,color:C.text2,lineHeight:18},
});
