/**
 * ZIMA v3 · screens/HistoryScreen.js
 * Historial metabólico con gráficos de evolución
 */
import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import { C, F, S, R } from '../theme/index';

const MiniChart = ({data, color, height=60, label, unit}) => {
  if (!data || data.length < 2) return (
    <View style={{height,justifyContent:'center',alignItems:'center'}}>
      <Text style={{fontFamily:F.mono,fontSize:F.xs,color:C.text3}}>Sin datos suficientes</Text>
    </View>
  );
  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min || 1;
  return (
    <View style={{gap:6}}>
      <View style={[sty.chartArea,{height}]}>
        {data.map((v,i)=>{
          const barH = Math.max(((v-min)/range)*height*0.85, 4);
          return (
            <View key={i} style={{flex:1,justifyContent:'flex-end',alignItems:'center',gap:2}}>
              <View style={[sty.bar,{height:barH,backgroundColor:color,opacity:i===data.length-1?1:0.5+((i/data.length)*0.5)}]}/>
            </View>
          );
        })}
      </View>
      <View style={sty.chartLabels}>
        <Text style={sty.chartMin}>{min.toFixed(1)}{unit}</Text>
        <Text style={sty.chartCurrent}>HOY: <Text style={{color}}>{data[data.length-1]?.toFixed(1)}{unit}</Text></Text>
        <Text style={sty.chartMax}>{max.toFixed(1)}{unit}</Text>
      </View>
    </View>
  );
};

export default function HistoryScreen({state}) {
  const [tab,setTab] = useState('PESO');

  const weightH = (state?.weightHistory || []).map(e=>e.value);
  const ketoH   = (state?.ketoneHistory || []).map(e=>e.value).slice(0,14).reverse();
  const sleepH  = (state?.sleepHistory || []).map(e=>e.hours).slice(0,14).reverse();
  const trainH  = [...Array(7)].map((_,i)=> state?.loadVolume ? Math.round(state.loadVolume/7*(i+1)) : 0);

  const tabs = [
    {id:'PESO',  label:'Peso',      data:weightH,  unit:'kg',   color:C.primary,  icon:'⚖️'},
    {id:'KETO',  label:'Cetonas',   data:ketoH,    unit:'mmol', color:C.success,  icon:'⚗️'},
    {id:'SUEÑO', label:'Sueño',     data:sleepH,   unit:'h',    color:C.secondary,icon:'🌙'},
    {id:'ENTRENO',label:'Entrenos', data:trainH,   unit:'',     color:C.warning,  icon:'⚔️'},
  ];

  const cur = tabs.find(t=>t.id===tab)||tabs[0];
  const avg = cur.data.length ? (cur.data.reduce((a,b)=>a+b,0)/cur.data.length).toFixed(1) : '—';
  const last7 = cur.data.slice(-7);

  // Calcular streaks
  const ketoStreak = (state?.ketoneHistory||[]).filter(e=>e.value>=0.5).length;
  const sleepStreak = (state?.sleepHistory||[]).filter(e=>e.hours>=7).length;
  const trainDays = state?.adherenceDays || 0;

  return (
    <View style={sty.root}>
      <View style={sty.hdr}><Text style={sty.hdrTitle}>HISTORIAL</Text><Text style={sty.hdrSub}>Tu evolución metabólica</Text></View>

      <ScrollView style={{flex:1}} contentContainerStyle={{padding:S.lg,gap:16,paddingBottom:80}}>

        {/* Badges de racha */}
        <View style={sty.badgeRow}>
          <Badge icon="⚗️" label="Días en cetosis"   value={ketoStreak}  color={C.primary}/>
          <Badge icon="🌙" label="Noches ≥7h"         value={sleepStreak}  color={C.secondary}/>
          <Badge icon="⚔️" label="Días consistencia" value={trainDays}    color={C.warning}/>
        </View>

        {/* Selector de métrica */}
        <View style={sty.tabRow}>
          {tabs.map(t=>(
            <TouchableOpacity key={t.id} style={[sty.tabBtn,tab===t.id&&{backgroundColor:t.color,borderColor:t.color}]} onPress={()=>setTab(t.id)} activeOpacity={0.8}>
              <Text style={sty.tabIcon}>{t.icon}</Text>
              <Text style={[sty.tabLbl,tab===t.id&&{color:'#000',fontWeight:F.b}]}>{t.label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Gráfico */}
        <View style={sty.chartCard}>
          <View style={sty.chartHdr}>
            <Text style={sty.chartTitle}>{cur.label.toUpperCase()}</Text>
            <View style={sty.chartStats}>
              <Text style={[sty.chartAvg,{color:cur.color}]}>PROM: {avg}{cur.unit}</Text>
              <Text style={sty.chartCount}>{cur.data.length} registros</Text>
            </View>
          </View>
          <MiniChart data={last7.length?last7:cur.data} color={cur.color} height={80} unit={cur.unit}/>
        </View>

        {/* Actualización mensual de medidas */}
        <View style={sty.updateCard}>
          <Text style={sty.updateTitle}>📅 ACTUALIZACIÓN MENSUAL</Text>
          <Text style={sty.updateDesc}>
            ZIMA te pide actualizar tu peso y medidas mensualmente para recalibrar tu protocolo y mostrar tu evolución real.
          </Text>
          <View style={sty.updateStats}>
            {[['Peso actual', `${state?.weight||'—'} kg`],['Cintura', `${state?.waistCm||'—'} cm`],['Brazos', `${state?.armsCm||'—'} cm`]].map(([l,v])=>(
              <View key={l} style={sty.updateStat}>
                <Text style={sty.updateStatL}>{l}</Text>
                <Text style={sty.updateStatV}>{v}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Logros */}
        <Text style={sty.sLabel}>LOGROS</Text>
        {[
          {icon:'🌱', label:'Primer día keto',     done: (state?.adherenceDays||0) >= 1,   color:C.success},
          {icon:'🌿', label:'7 días de cetosis',    done: ketoStreak >= 7,                  color:C.primary},
          {icon:'🔥', label:'30 días de adherencia',done: (state?.adherenceDays||0) >= 30,  color:C.warning},
          {icon:'💪', label:'10 sesiones guardadas',done: (state?.loadVolume||0) > 500,     color:C.success},
          {icon:'🌙', label:'7 noches de buen sueño',done: sleepStreak >= 7,                color:C.secondary},
          {icon:'💧', label:'Hidratación completa', done: false,                             color:C.primary},
          {icon:'💎', label:'Avatar nivel Cristal', done: (state?.loadVolume||0) >= 10000, color:C.secondary},
        ].map((a,i)=>(
          <View key={i} style={[sty.achievement,a.done&&{borderColor:a.color+'60',backgroundColor:a.color+'08'}]}>
            <Text style={[sty.achieveIcon,!a.done&&{opacity:0.3}]}>{a.icon}</Text>
            <Text style={[sty.achieveLbl,!a.done&&{color:C.text3}]}>{a.label}</Text>
            <Text style={a.done?[sty.achieveDone,{color:a.color}]:sty.achieveUndone}>{a.done?'✓ LOGRADO':'Pendiente'}</Text>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

const Badge = ({icon,label,value,color}) => (
  <View style={[sty.badge,{borderColor:color+'40'}]}>
    <Text style={{fontSize:20}}>{icon}</Text>
    <Text style={[sty.badgeVal,{color}]}>{value}</Text>
    <Text style={sty.badgeLbl}>{label}</Text>
  </View>
);

const sty = StyleSheet.create({
  root:{flex:1,backgroundColor:C.bg},
  hdr:{padding:S.lg,borderBottomWidth:1,borderBottomColor:C.border,gap:4},
  hdrTitle:{fontFamily:F.mono,fontWeight:F.bk,fontSize:F.lg,color:C.primary,letterSpacing:3},
  hdrSub:{fontFamily:F.mono,fontSize:F.xs,color:C.text2},
  sLabel:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.xs,color:C.primary,letterSpacing:2},
  badgeRow:{flexDirection:'row',gap:10},
  badge:{flex:1,backgroundColor:C.bg2,borderWidth:1,borderRadius:R.lg,padding:S.md,alignItems:'center',gap:4},
  badgeVal:{fontFamily:F.mono,fontWeight:F.bk,fontSize:F.xl},
  badgeLbl:{fontFamily:F.mono,fontSize:9,color:C.text3,textAlign:'center',letterSpacing:0.5},
  tabRow:{flexDirection:'row',gap:8},
  tabBtn:{flex:1,backgroundColor:C.bg2,borderWidth:1,borderColor:C.border,borderRadius:R.md,paddingVertical:10,alignItems:'center',gap:3},
  tabIcon:{fontSize:16},
  tabLbl:{fontFamily:F.mono,fontSize:F.xs,color:C.text2},
  chartCard:{backgroundColor:C.bg2,borderWidth:1,borderColor:C.border,borderRadius:R.lg,padding:S.lg,gap:14},
  chartHdr:{flexDirection:'row',justifyContent:'space-between',alignItems:'center'},
  chartTitle:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.sm,color:C.primary,letterSpacing:2},
  chartStats:{alignItems:'flex-end',gap:2},
  chartAvg:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.sm},
  chartCount:{fontFamily:F.mono,fontSize:F.xs,color:C.text3},
  chartArea:{flexDirection:'row',gap:4,alignItems:'flex-end'},
  bar:{flex:1,borderRadius:2,minWidth:4},
  chartLabels:{flexDirection:'row',justifyContent:'space-between'},
  chartMin:{fontFamily:F.mono,fontSize:9,color:C.text3},
  chartCurrent:{fontFamily:F.mono,fontSize:9,color:C.text2,fontWeight:F.b},
  chartMax:{fontFamily:F.mono,fontSize:9,color:C.text3},
  updateCard:{backgroundColor:C.bg2,borderWidth:1,borderColor:C.primary+'30',borderRadius:R.lg,padding:S.lg,gap:12},
  updateTitle:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.xs,color:C.primary,letterSpacing:2},
  updateDesc:{fontFamily:F.mono,fontSize:F.xs,color:C.text2,lineHeight:17},
  updateStats:{flexDirection:'row',justifyContent:'space-around'},
  updateStat:{alignItems:'center',gap:4},
  updateStatL:{fontFamily:F.mono,fontSize:F.xs,color:C.text3},
  updateStatV:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.base,color:C.text},
  achievement:{flexDirection:'row',gap:12,alignItems:'center',backgroundColor:C.bg2,borderWidth:1,borderColor:C.border,borderRadius:R.md,padding:S.md},
  achieveIcon:{fontSize:22},
  achieveLbl:{flex:1,fontFamily:F.mono,fontSize:F.sm,color:C.text},
  achieveDone:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.xs,letterSpacing:1},
  achieveUndone:{fontFamily:F.mono,fontSize:F.xs,color:C.text3},
});
