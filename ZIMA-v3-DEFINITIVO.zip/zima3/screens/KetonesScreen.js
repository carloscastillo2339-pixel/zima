/**
 * ZIMA v3 · screens/KetonesScreen.js
 */
import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, TextInput } from 'react-native';
import { analyzeKetones } from '../engine/SIMEngine';
import { C, F, S, R } from '../theme/index';

export default function KetonesScreen({state, onUpdate}) {
  const [method, setMethod]  = useState(state?.ketoneMethod||'SANGRE');
  const [input, setInput]    = useState('');
  const [history, setHist]   = useState(state?.ketoneHistory||[]);
  const cur = state?.ketones||0;
  const a = analyzeKetones(cur, method);
  const zones = [{min:0,max:0.5,label:'Sin cetosis',color:'#6B7F8E'},{min:0.5,max:1.5,label:'Nutricional',color:C.warning},{min:1.5,max:3.0,label:'Óptima ✓',color:C.primary},{min:3.0,max:5.0,label:'Ayuno profundo',color:C.warning},{min:5.0,max:99,label:'Nivel médico',color:C.danger}];
  const trend = history.length>=2 ? history[0].value - history[1].value : null;

  const log = () => {
    const v = parseFloat(input);
    if(isNaN(v)||v<0) return;
    const e = {value:v, method, ts:Date.now(), date:new Date().toLocaleDateString('es-ES')};
    const nh = [e,...history].slice(0,60);
    setHist(nh); onUpdate?.({ketones:v, ketoneMethod:method, ketoneHistory:nh}); setInput('');
  };

  return (
    <View style={sty.root}>
      <View style={sty.hdr}><Text style={sty.hdrTitle}>CETONAS</Text><Text style={sty.hdrSub}>Monitor metabólico</Text></View>
      <ScrollView style={{flex:1}} contentContainerStyle={{padding:S.lg,gap:16,paddingBottom:80}}>
        <View style={[sty.main,{borderColor:a.color+'50'}]}>
          <Text style={sty.mainLbl}>NIVEL ACTUAL</Text>
          <Text style={[sty.mainVal,{color:a.color}]}>{cur.toFixed(1)}</Text>
          <Text style={sty.mainUnit}>mmol/L</Text>
          <View style={[sty.zonePill,{backgroundColor:a.color+'20',borderColor:a.color+'50'}]}><Text style={[sty.zoneLabel,{color:a.color}]}>{a.label}</Text></View>
          {trend!==null&&<Text style={[sty.trend,{color:trend>0?C.success:trend<0?C.danger:C.text2}]}>{trend>0?'↑':trend<0?'↓':'→'} {Math.abs(trend).toFixed(2)} mmol/L vs medición anterior</Text>}
        </View>
        <View style={sty.zonesCard}>
          <Text style={sty.sLabel}>ZONAS DE CETOSIS</Text>
          {zones.map((z,i)=>{const prev=i===0?0:zones[i-1].max; const active=cur>=prev&&cur<z.max; return (
            <View key={z.label} style={[sty.zRow, active&&{backgroundColor:C.bg3,borderRadius:R.sm,paddingHorizontal:6}]}>
              <View style={[sty.zDot,{backgroundColor:active?z.color:C.border}]}/>
              <Text style={[sty.zName,active&&{color:z.color,fontWeight:F.b}]}>{z.label}</Text>
              <Text style={[sty.zRange,active&&{color:z.color}]}>{prev===0?'< ':prev+'–'}{z.max} mmol/L</Text>
              {active&&<Text style={[sty.zActive,{color:z.color}]}>← TÚ</Text>}
            </View>
          );})}
        </View>
        <View style={[sty.recCard,{borderColor:a.color+'30'}]}><Text style={[sty.recTitle,{color:a.color}]}>RECOMENDACIÓN SIM</Text><Text style={sty.recTxt}>{a.rec}</Text>{method==='ORINA'&&<Text style={sty.urineNote}>⚠ La orina detecta acetoacetato. Puede variar respecto a sangre.</Text>}</View>
        <View>
          <Text style={sty.sLabel}>MÉTODO DE MEDICIÓN</Text>
          <View style={sty.methods}>
            {[{id:'SANGRE',icon:'🩸',desc:'Beta-hidroxibutirato (más preciso)'},{id:'ORINA',icon:'💧',desc:'Acetoacetato (referencial)'}].map(m=>(
              <TouchableOpacity key={m.id} style={[sty.mBtn, method===m.id&&sty.mBtnA]} onPress={()=>setMethod(m.id)} activeOpacity={0.8}>
                <Text style={sty.mIcon}>{m.icon}</Text>
                <Text style={[sty.mName,method===m.id&&{color:C.primary}]}>{m.id}</Text>
                <Text style={sty.mDesc}>{m.desc}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
        <View>
          <Text style={sty.sLabel}>REGISTRAR MEDICIÓN</Text>
          <View style={sty.inputRow}>
            <TextInput style={sty.inp} value={input} onChangeText={setInput} placeholder="ej: 1.8" placeholderTextColor={C.text3} keyboardType="decimal-pad"/>
            <Text style={sty.inpUnit}>mmol/L</Text>
            <TouchableOpacity style={[sty.logBtn,!input&&{backgroundColor:C.text3}]} onPress={log} disabled={!input} activeOpacity={0.85}>
              <Text style={sty.logBtnTxt}>REGISTRAR</Text>
            </TouchableOpacity>
          </View>
        </View>
        {history.length>0&&(
          <View>
            <Text style={sty.sLabel}>HISTORIAL</Text>
            <View style={sty.histCard}>
              {history.slice(0,10).map((e,i)=>{const ea=analyzeKetones(e.value); return (
                <View key={i} style={sty.histRow}>
                  <Text style={sty.histDate}>{e.date}</Text>
                  <Text style={{fontSize:14}}>{e.method==='SANGRE'?'🩸':'💧'}</Text>
                  <View style={sty.histBar}><View style={[sty.histFill,{width:`${Math.min((e.value/5)*100,100)}%`,backgroundColor:ea.color}]}/></View>
                  <Text style={[sty.histVal,{color:ea.color}]}>{e.value.toFixed(1)}</Text>
                  <Text style={[sty.histLbl,{color:ea.color}]}>{ea.label}</Text>
                </View>
              );})}
            </View>
          </View>
        )}
        <View style={sty.reminderCard}><Text style={{fontSize:22}}>📅</Text><View style={{flex:1}}><Text style={sty.reminderTitle}>RECORDATORIO MENSUAL</Text><Text style={sty.reminderTxt}>ZIMA te recordará actualizar tus cetonas mensualmente para recalibrar tu protocolo.</Text></View></View>
      </ScrollView>
    </View>
  );
}

const sty = StyleSheet.create({
  root:{flex:1,backgroundColor:C.bg},
  hdr:{padding:S.lg,borderBottomWidth:1,borderBottomColor:C.border,gap:4},
  hdrTitle:{fontFamily:F.mono,fontWeight:F.bk,fontSize:F.lg,color:C.primary,letterSpacing:3},
  hdrSub:{fontFamily:F.mono,fontSize:F.xs,color:C.text2},
  sLabel:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.xs,color:C.primary,letterSpacing:2,marginBottom:8},
  main:{backgroundColor:C.bg2,borderWidth:1.5,borderRadius:R.xl,padding:S.xl,alignItems:'center',gap:6},
  mainLbl:{fontFamily:F.mono,fontSize:F.xs,color:C.text3,letterSpacing:3},
  mainVal:{fontFamily:F.mono,fontWeight:F.bk,fontSize:72,lineHeight:80},
  mainUnit:{fontFamily:F.mono,fontSize:F.base,color:C.text2},
  zonePill:{borderWidth:1,borderRadius:R.full,paddingHorizontal:20,paddingVertical:6},
  zoneLabel:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.sm,letterSpacing:1},
  trend:{fontFamily:F.mono,fontSize:F.xs,marginTop:4},
  zonesCard:{backgroundColor:C.bg2,borderWidth:1,borderColor:C.border,borderRadius:R.lg,padding:S.md,gap:8},
  zRow:{flexDirection:'row',gap:10,alignItems:'center',paddingVertical:4},
  zDot:{width:8,height:8,borderRadius:4},
  zName:{flex:1,fontFamily:F.mono,fontSize:F.sm,color:C.text2},
  zRange:{fontFamily:F.mono,fontSize:F.xs,color:C.text3},
  zActive:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.xs},
  recCard:{borderWidth:1,borderRadius:R.lg,padding:S.md,gap:8,backgroundColor:C.bg2},
  recTitle:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.xs,letterSpacing:2},
  recTxt:{fontFamily:F.mono,fontSize:F.sm,color:C.text2,lineHeight:19},
  urineNote:{fontFamily:F.mono,fontSize:F.xs,color:C.warning},
  methods:{flexDirection:'row',gap:10},
  mBtn:{flex:1,backgroundColor:C.bg2,borderWidth:1,borderColor:C.border,borderRadius:R.lg,padding:S.md,gap:4},
  mBtnA:{borderColor:C.primary,backgroundColor:C.primaryDim},
  mIcon:{fontSize:22},
  mName:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.base,color:C.text2},
  mDesc:{fontFamily:F.mono,fontSize:F.xs,color:C.text3,lineHeight:16},
  inputRow:{flexDirection:'row',gap:8,alignItems:'center'},
  inp:{flex:1,backgroundColor:C.bg3,borderWidth:1,borderColor:C.border,borderRadius:R.md,padding:14,color:C.text,fontFamily:F.mono,fontSize:F.lg},
  inpUnit:{fontFamily:F.mono,color:C.text3,fontSize:F.xs},
  logBtn:{backgroundColor:C.primary,borderRadius:R.md,paddingVertical:14,paddingHorizontal:16},
  logBtnTxt:{fontFamily:F.mono,fontWeight:F.b,color:'#000',fontSize:F.xs,letterSpacing:1},
  histCard:{backgroundColor:C.bg2,borderWidth:1,borderColor:C.border,borderRadius:R.lg,padding:S.md,gap:10},
  histRow:{flexDirection:'row',alignItems:'center',gap:8},
  histDate:{fontFamily:F.mono,fontSize:F.xs,color:C.text3,width:70},
  histBar:{flex:1,height:4,backgroundColor:C.border,borderRadius:2,overflow:'hidden'},
  histFill:{height:'100%',borderRadius:2},
  histVal:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.xs,width:28},
  histLbl:{fontFamily:F.mono,fontSize:F.xs,width:70},
  reminderCard:{flexDirection:'row',gap:12,backgroundColor:C.bg2,borderWidth:1,borderColor:C.border,borderRadius:R.lg,padding:S.md,alignItems:'center'},
  reminderTitle:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.xs,color:C.primary,letterSpacing:2,marginBottom:4},
  reminderTxt:{fontFamily:F.mono,fontSize:F.xs,color:C.text2,lineHeight:17},
});
