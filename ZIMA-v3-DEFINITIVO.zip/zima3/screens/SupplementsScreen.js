/**
 * ZIMA v3 · screens/SupplementsScreen.js
 */
import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import { SUPPLEMENTS } from '../data/index';
import { C, F, S, R } from '../theme/index';

const SLOTS = ['En ayunas','Pre-entreno','Con desayuno','Con comida','Post-entreno','Tarde','Antes de dormir'];
const rcColor = s => s>=4?C.success:s>=3?C.warning:C.danger;
const rcLabel = s => s>=4?'RECOMENDADO':s>=3?'ACEPTABLE':'PRECAUCIÓN';

export default function SupplementsScreen({state,onUpdate}) {
  const [myStack, setStack]  = useState(state?.supplements||[]);
  const [scheds, setScheds]  = useState(state?.supplementSchedules||{});
  const [filter, setFilter]  = useState('ALL');
  const [view, setView]      = useState('CATALOG');
  const [exp, setExp]        = useState(null);

  const toggle = id => { const n=myStack.includes(id)?myStack.filter(s=>s!==id):[...myStack,id]; setStack(n); onUpdate?.({supplements:n}); };
  const toggleSlot = (id,slot) => { const cur=scheds[id]||[]; const ns=cur.includes(slot)?cur.filter(s=>s!==slot):[...cur,slot]; const n={...scheds,[id]:ns}; setScheds(n); onUpdate?.({supplementSchedules:n}); };

  const filtered = filter==='ALL'?SUPPLEMENTS:filter==='KETO'?SUPPLEMENTS.filter(s=>s.score>=4):SUPPLEMENTS.filter(s=>myStack.includes(s.id));

  // Vista horario
  const schedule = {};
  myStack.forEach(id=>{const s=SUPPLEMENTS.find(x=>x.id===id); if(!s)return; (scheds[id]||s.timing).forEach(slot=>{if(!schedule[slot])schedule[slot]=[]; schedule[slot].push(s);});});

  return (
    <View style={sty.root}>
      <View style={sty.hdr}>
        <Text style={sty.hdrTitle}>SUPLEMENTOS</Text>
        <View style={sty.toggle}>
          {['CATALOG','MI STACK','HORARIO'].map(v=>(
            <TouchableOpacity key={v} style={[sty.tBtn,view===v&&sty.tBtnA]} onPress={()=>setView(v)}>
              <Text style={[sty.tTxt,view===v&&sty.tTxtA]}>{v}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      <ScrollView style={{flex:1}} contentContainerStyle={{padding:S.lg,gap:12,paddingBottom:80}}>

        {view==='CATALOG'&&(
          <>
            <View style={sty.filterRow}>
              {[['ALL','Todos'],['KETO','Solo Keto ✓'],['MY','Mi stack']].map(([id,l])=>(
                <TouchableOpacity key={id} style={[sty.fBtn,filter===id&&sty.fBtnA]} onPress={()=>setFilter(id)}>
                  <Text style={[sty.fTxt,filter===id&&sty.fTxtA]}>{l}</Text>
                </TouchableOpacity>
              ))}
            </View>
            {filtered.map(s=>(
              <View key={s.id} style={[sty.card,myStack.includes(s.id)&&{borderColor:rcColor(s.score)+'50',backgroundColor:rcColor(s.score)+'05'}]}>
                <TouchableOpacity onPress={()=>setExp(exp===s.id?null:s.id)} activeOpacity={0.85}>
                  <View style={sty.cardHdr}>
                    <Text style={{fontSize:26}}>{s.emoji}</Text>
                    <View style={{flex:1}}>
                      <Text style={sty.cardName}>{s.name}</Text>
                      <Text style={sty.cardDose}>{s.dose}</Text>
                    </View>
                    <View style={[sty.rcBadge,{backgroundColor:rcColor(s.score)+'20',borderColor:rcColor(s.score)+'40'}]}>
                      <Text style={[sty.rcTxt,{color:rcColor(s.score)}]}>{rcLabel(s.score)}</Text>
                    </View>
                  </View>
                </TouchableOpacity>
                {exp===s.id&&(
                  <View style={sty.detail}>
                    <View style={sty.starsRow}>
                      <Text style={sty.starsLbl}>KETO</Text>
                      {[1,2,3,4,5].map(n=><Text key={n} style={{color:n<=s.score?rcColor(s.score):C.border,fontSize:14}}>★</Text>)}
                    </View>
                    <Text style={sty.benefit}>{s.benefit}</Text>
                    {!s.keto&&<View style={sty.warn}><Text style={sty.warnTxt}>⚠ Puede afectar la cetosis. Usar con precaución.</Text></View>}
                    <Text style={sty.sLabel}>HORARIOS SUGERIDOS</Text>
                    <View style={sty.timRow}>{s.timing.map(t=><View key={t} style={sty.timChip}><Text style={sty.timTxt}>{t}</Text></View>)}</View>
                    {myStack.includes(s.id)&&(
                      <>
                        <Text style={sty.sLabel}>MIS HORARIOS</Text>
                        <View style={sty.slotGrid}>
                          {SLOTS.map(slot=>(
                            <TouchableOpacity key={slot} style={[sty.slotBtn,(scheds[s.id]||[]).includes(slot)&&sty.slotBtnA]} onPress={()=>toggleSlot(s.id,slot)}>
                              <Text style={[sty.slotTxt,(scheds[s.id]||[]).includes(slot)&&{color:C.primary,fontWeight:F.b}]}>{slot}</Text>
                            </TouchableOpacity>
                          ))}
                        </View>
                      </>
                    )}
                    <TouchableOpacity style={[sty.toggleBtn,myStack.includes(s.id)?sty.toggleBtnRem:sty.toggleBtnAdd]} onPress={()=>toggle(s.id)} activeOpacity={0.85}>
                      <Text style={[sty.toggleTxt,myStack.includes(s.id)&&{color:C.danger}]}>{myStack.includes(s.id)?'✕ Quitar de mi stack':'+ Agregar a mi stack'}</Text>
                    </TouchableOpacity>
                  </View>
                )}
                {!exp&&myStack.includes(s.id)&&(
                  <View style={sty.addedRow}>
                    <Text style={sty.addedTxt}>✓ En mi stack</Text>
                    {(scheds[s.id]||[]).length>0&&<Text style={sty.addedSched}>{(scheds[s.id]||[]).join(' · ')}</Text>}
                  </View>
                )}
              </View>
            ))}
          </>
        )}

        {view==='MI STACK'&&(
          myStack.length===0?(
            <View style={sty.empty}><Text style={{fontSize:40}}>💊</Text><Text style={sty.emptyTxt}>Tu stack está vacío. Ve al catálogo y agrega suplementos.</Text></View>
          ):(
            <>
              <View style={sty.stackSum}><Text style={sty.stackN}>{myStack.length}</Text><Text style={sty.stackSub}>suplementos en tu protocolo</Text></View>
              {SUPPLEMENTS.filter(s=>myStack.includes(s.id)).map(s=>(
                <View key={s.id} style={[sty.card,{borderColor:rcColor(s.score)+'40'}]}>
                  <View style={sty.cardHdr}>
                    <Text style={{fontSize:24}}>{s.emoji}</Text>
                    <View style={{flex:1}}><Text style={sty.cardName}>{s.name}</Text><Text style={sty.cardDose}>{s.dose}</Text></View>
                    <View style={[sty.rcBadge,{backgroundColor:rcColor(s.score)+'20',borderColor:rcColor(s.score)+'40'}]}><Text style={[sty.rcTxt,{color:rcColor(s.score)}]}>{rcLabel(s.score)}</Text></View>
                  </View>
                  {(scheds[s.id]||[]).length>0&&(
                    <View style={sty.schedChips}>{(scheds[s.id]||[]).map(t=><View key={t} style={sty.schedChip}><Text style={sty.schedChipTxt}>{t}</Text></View>)}</View>
                  )}
                </View>
              ))}
            </>
          )
        )}

        {view==='HORARIO'&&(
          Object.keys(schedule).length===0?(
            <View style={sty.empty}><Text style={sty.emptyTxt}>Agrega suplementos y asigna horarios para ver tu protocolo diario</Text></View>
          ):(
            Object.entries(schedule).map(([slot,supps])=>(
              <View key={slot} style={sty.slotSection}>
                <View style={sty.slotHdr}><Text style={sty.slotHdrTxt}>{slot}</Text><View style={sty.slotLine}/></View>
                {supps.map(s=>(
                  <View key={s.id} style={sty.slotItem}>
                    <Text style={{fontSize:18}}>{s.emoji}</Text>
                    <Text style={sty.slotItemName}>{s.name}</Text>
                    <Text style={sty.slotItemDose}>{s.dose}</Text>
                  </View>
                ))}
              </View>
            ))
          )
        )}
      </ScrollView>
    </View>
  );
}

const sty = StyleSheet.create({
  root:{flex:1,backgroundColor:C.bg},
  hdr:{padding:S.lg,gap:12,borderBottomWidth:1,borderBottomColor:C.border},
  hdrTitle:{fontFamily:F.mono,fontWeight:F.bk,fontSize:F.lg,color:C.primary,letterSpacing:3},
  toggle:{flexDirection:'row',backgroundColor:C.bg2,borderRadius:R.md,padding:3,borderWidth:1,borderColor:C.border},
  tBtn:{flex:1,paddingVertical:7,alignItems:'center',borderRadius:R.sm-2},
  tBtnA:{backgroundColor:C.primary},
  tTxt:{fontFamily:F.mono,fontWeight:F.s,fontSize:9,color:C.text3,letterSpacing:1},
  tTxtA:{color:'#000'},
  sLabel:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.xs,color:C.primary,letterSpacing:2,marginBottom:6},
  filterRow:{flexDirection:'row',gap:8},
  fBtn:{flex:1,backgroundColor:C.bg2,borderWidth:1,borderColor:C.border,borderRadius:R.md,paddingVertical:8,alignItems:'center'},
  fBtnA:{backgroundColor:C.primaryDim,borderColor:C.primary},
  fTxt:{fontFamily:F.mono,fontSize:F.xs,color:C.text2},
  fTxtA:{color:C.primary,fontWeight:F.b},
  card:{backgroundColor:C.bg2,borderWidth:1,borderColor:C.border,borderRadius:R.lg,padding:S.md,gap:10},
  cardHdr:{flexDirection:'row',gap:10,alignItems:'center'},
  cardName:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.base,color:C.text},
  cardDose:{fontFamily:F.mono,fontSize:F.xs,color:C.text2,marginTop:2},
  rcBadge:{borderWidth:1,borderRadius:R.sm,paddingHorizontal:8,paddingVertical:4},
  rcTxt:{fontFamily:F.mono,fontWeight:F.b,fontSize:9,letterSpacing:1},
  detail:{gap:10,borderTopWidth:1,borderTopColor:C.border,paddingTop:8},
  starsRow:{flexDirection:'row',gap:6,alignItems:'center'},
  starsLbl:{fontFamily:F.mono,fontSize:F.xs,color:C.primary,letterSpacing:1,flex:1},
  benefit:{fontFamily:F.mono,fontSize:F.xs,color:C.text2,lineHeight:18},
  warn:{backgroundColor:C.warningDim,borderWidth:1,borderColor:C.warning+'40',borderRadius:R.sm,padding:8},
  warnTxt:{fontFamily:F.mono,fontSize:F.xs,color:C.warning},
  timRow:{flexDirection:'row',flexWrap:'wrap',gap:6},
  timChip:{backgroundColor:C.bg3,borderRadius:R.full,paddingHorizontal:10,paddingVertical:5},
  timTxt:{fontFamily:F.mono,fontSize:F.xs,color:C.text2},
  slotGrid:{flexDirection:'row',flexWrap:'wrap',gap:6},
  slotBtn:{borderWidth:1,borderColor:C.border,borderRadius:R.full,paddingHorizontal:10,paddingVertical:5,backgroundColor:C.bg3},
  slotBtnA:{borderColor:C.primary,backgroundColor:C.primaryDim},
  slotTxt:{fontFamily:F.mono,fontSize:F.xs,color:C.text3},
  toggleBtn:{borderRadius:R.md,paddingVertical:12,alignItems:'center',borderWidth:1},
  toggleBtnAdd:{backgroundColor:C.primaryDim,borderColor:C.primary+'50'},
  toggleBtnRem:{backgroundColor:C.dangerDim,borderColor:C.danger+'30'},
  toggleTxt:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.sm,color:C.primary},
  addedRow:{borderTopWidth:1,borderTopColor:C.border,paddingTop:8,gap:3},
  addedTxt:{fontFamily:F.mono,fontSize:F.xs,color:C.success},
  addedSched:{fontFamily:F.mono,fontSize:F.xs,color:C.text3},
  stackSum:{gap:2},
  stackN:{fontFamily:F.mono,fontWeight:F.bk,fontSize:F.xxl+4,color:C.text},
  stackSub:{fontFamily:F.mono,fontSize:F.xs,color:C.text2},
  schedChips:{flexDirection:'row',flexWrap:'wrap',gap:6},
  schedChip:{backgroundColor:C.bg3,borderRadius:R.full,paddingHorizontal:10,paddingVertical:5},
  schedChipTxt:{fontFamily:F.mono,fontSize:F.xs,color:C.primary},
  slotSection:{gap:8},
  slotHdr:{flexDirection:'row',alignItems:'center',gap:10},
  slotHdrTxt:{fontFamily:F.mono,fontWeight:F.b,fontSize:F.sm,color:C.primary,letterSpacing:1},
  slotLine:{flex:1,height:1,backgroundColor:C.border},
  slotItem:{flexDirection:'row',gap:10,alignItems:'center',backgroundColor:C.bg2,borderWidth:1,borderColor:C.border,borderRadius:R.md,padding:S.md},
  slotItemName:{flex:1,fontFamily:F.mono,fontWeight:F.s,fontSize:F.sm,color:C.text},
  slotItemDose:{fontFamily:F.mono,fontSize:F.xs,color:C.text2},
  empty:{alignItems:'center',paddingTop:60,gap:12},
  emptyTxt:{fontFamily:F.mono,color:C.text2,fontSize:F.base,textAlign:'center'},
});
