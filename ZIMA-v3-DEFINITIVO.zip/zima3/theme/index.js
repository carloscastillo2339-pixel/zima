/**
 * ZIMA v3 · theme/index.js
 */
export const C = {
  bg:          '#07090D',
  bg2:         '#0D1219',
  bg3:         '#111820',
  bg4:         '#141D26',
  border:      '#1C2730',
  borderHi:    '#2A3F50',
  text:        '#E8EDF2',
  text2:       '#8A9EAD',
  text3:       '#3A4F5C',
  primary:     '#5BCFDA',
  primaryDim:  'rgba(91,207,218,0.12)',
  secondary:   '#A06EE8',
  secondaryDim:'rgba(160,110,232,0.12)',
  success:     '#4EBE8A',
  successDim:  'rgba(78,190,138,0.12)',
  warning:     '#E8A838',
  warningDim:  'rgba(232,168,56,0.12)',
  danger:      '#E85C5C',
  dangerDim:   'rgba(232,92,92,0.12)',
  gold:        '#F0C040',
};

export const F = {
  mono: 'monospace',
  xs:9, sm:11, base:13, md:15, lg:18, xl:22, xxl:28, hero:40,
  n:'400', m:'500', s:'600', b:'700', bk:'900',
};

export const S = { xs:4, sm:8, md:12, lg:16, xl:24, xxl:32 };
export const R = { sm:6, md:10, lg:14, xl:20, full:999 };
