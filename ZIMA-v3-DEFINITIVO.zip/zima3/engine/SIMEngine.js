/**
 * ZIMA v3 · engine/SIMEngine.js
 */

export const calcBMI = (w, h) => {
  const v = w / ((h/100)**2);
  return { value:+v.toFixed(1), cat: v<18.5?'Bajo peso':v<25?'Normal':v<30?'Sobrepeso':'Obesidad', color: v<18.5?'#5BCFDA':v<25?'#4EBE8A':v<30?'#E8A838':'#E85C5C' };
};

export const calcTDEE = ({w,h,age=30,gender='M',activity='MODERATE'}) => {
  const bmr = gender==='M' ? 10*w+6.25*h-5*age+5 : 10*w+6.25*h-5*age-161;
  const mult = {SEDENTARY:1.2,LIGHT:1.375,MODERATE:1.55,ACTIVE:1.725,VERY_ACTIVE:1.9}[activity]||1.55;
  const tdee = bmr*mult;
  return { bmr:Math.round(bmr), tdee:Math.round(tdee), protein:Math.round(w*2), fat:Math.round(tdee*0.70/9), carbs:25 };
};

export const calcInflammation = ({ketones=1,netCarbs=25,stress=3,sleep=7}) => {
  const kf = ketones>=3?0.05:ketones>=1.5?0.15:ketones>=0.5?0.40:0.70;
  const cf = Math.min(netCarbs/50,1);
  const sf = stress/10;
  const lf = sleep>=8?0.1:sleep>=6?0.3:0.8;
  return Math.min(Math.max(kf*.40+cf*.35+sf*.15+lf*.10,0),1);
};

export const analyzeKetones = (v, method='SANGRE') => {
  const zones = [{min:0,max:0.5,label:'Sin cetosis',color:'#6B7F8E'},{min:0.5,max:1.5,label:'Nutricional',color:'#E8A838'},{min:1.5,max:3.0,label:'Óptima ✓',color:'#5BCFDA'},{min:3.0,max:5.0,label:'Ayuno profundo',color:'#E8A838'},{min:5.0,max:99,label:'Nivel médico',color:'#E85C5C'}];
  const z = zones.find(z=>v>=z.min&&v<z.max)||zones[0];
  return { ...z, v, method, isOptimal:v>=1.5&&v<3.0, pct:Math.min((v/5)*100,100), rec: v<0.5?'Reduce carbos < 20g. Ayuno 16:8.':v<1.5?'Cetosis iniciando. Mantén proteína moderada.':v<3?'Cetosis óptima. Mantén protocolo.':v<5?'Cetosis de ayuno. Hidratación y electrolitos.':'⚠ Nivel elevado. Consulta médico si eres diabético.' };
};

export const analyzeAvatar = (level) => {
  const states = [
    {id:'SEED',    label:'Semilla',   emoji:'🌱', color:'#6B7F8E', desc:'Inicio del viaje.',         minLoad:0    },
    {id:'SPROUT',  label:'Brote',     emoji:'🌿', color:'#4EBE8A', desc:'Adaptación cetogénica.',     minLoad:500  },
    {id:'LEAF',    label:'Hoja',      emoji:'🍃', color:'#5BCFDA', desc:'Cetosis establecida.',        minLoad:2000 },
    {id:'FLAME',   label:'Llama',     emoji:'🔥', color:'#E8A838', desc:'Atleta metabólico.',          minLoad:5000 },
    {id:'CRYSTAL', label:'Cristal',   emoji:'💎', color:'#A06EE8', desc:'Optimización máxima.',        minLoad:10000},
  ];
  return states[Math.min(level,4)];
};

export const getStatus = ({ketones,netCarbs,inflamm}) => {
  if (inflamm>.7) return {status:'ALERTA',   msg:'Inflamación crítica. Activa protocolo botánico.', color:'#E85C5C'};
  if (ketones>=1.5&&netCarbs<=25&&inflamm<.3) return {status:'ÓPTIMO',  msg:'Sistema cetogénico en peak. Mantén curso.',  color:'#4EBE8A'};
  if (ketones>=.5&&netCarbs<=50) return {status:'ESTABLE', msg:'Cetosis activa. Optimiza carbos y descanso.', color:'#5BCFDA'};
  if (ketones<.5)  return {status:'INACTIVO', msg:'Sin cetosis. Reduce carbohidratos < 20g hoy.',  color:'#E8A838'};
  return {status:'TRANSICIÓN',msg:'En adaptación metabólica. Persiste 48-72h.',     color:'#E8A838'};
};

export const calcAvatarLevel = (loadVol, ketones, adherence) => {
  const thresholds = [0,500,2000,5000,10000];
  let base = 0;
  for(let i=thresholds.length-1;i>=0;i--) if(loadVol>=thresholds[i]){base=i;break;}
  const bonus = (ketones>=1.5&&ketones<5?1:0)+(adherence>=30?1:0);
  return Math.min(base+Math.floor(bonus/2),4);
};

export const analyzeSleep = (h, gender='M') => {
  const opt = gender==='F'?8.5:8;
  const score = Math.min(h/opt,1);
  const deficit = Math.max(0,opt-h);
  return {
    hours:h, score, deficit,
    quality: h>=opt?'ÓPTIMO':h>=opt-1?'BUENO':h>=6?'INSUFICIENTE':'CRÍTICO',
    color:   h>=opt?'#4EBE8A':h>=opt-1?'#5BCFDA':h>=6?'#E8A838':'#E85C5C',
    msg:     h>=opt?'Recuperación completa. Hormonas anabólicas optimizadas.':`Déficit de ${deficit.toFixed(1)}h. ${gender==='F'?'Las mujeres requieren +30min extra.':'Sueño profundo = testosterona optimal.'}`,
  };
};
