/**
 * ZIMA v3 · data/index.js
 * Base de datos completa: ejercicios, suplementos, tipos corporales, alimentos, bebidas
 */

// ─── Tipos corporales ─────────────────────────────────────
export const BODY_TYPES = {
  ECTOMORFO: {
    id:'ECTOMORFO', name:'Ectomorfo', emoji:'⚡', color:'#5BE8B4',
    desc:'Cuerpo delgado y ligero, dificultad para ganar masa. Metabolismo muy rápido.',
    traits:['Estructura ósea fina','Dificultad para ganar músculo','Bajo % de grasa natural','Metabolismo acelerado'],
    ketoTips:['Carbs netos hasta 30g/día (más flexibles)','Proteína alta: 2.2g por kg','MCT Oil 3x/día para energía','Menos cardio, más volumen muscular'],
    carbLimit:30, protein:2.2, fat:65,
  },
  MESOMORFO: {
    id:'MESOMORFO', name:'Mesomorfo', emoji:'🦁', color:'#5B8AE8',
    desc:'Cuerpo atlético y proporcional. Gana músculo y pierde grasa fácilmente.',
    traits:['Estructura atlética natural','Responde rápido al entreno','Composición corporal favorable','El tipo más adaptable'],
    ketoTips:['Carbs netos estándar: 20-25g/día','Protocolo keto clásico funciona perfecto','Excelente para keto cíclico','Ayuno intermitente 16:8'],
    carbLimit:25, protein:2.0, fat:70,
  },
  ENDOMORFO: {
    id:'ENDOMORFO', name:'Endomorfo', emoji:'🏔️', color:'#E88A5B',
    desc:'Cuerpo ancho y fuerte, tendencia a acumular grasa. Metabolismo lento.',
    traits:['Estructura ósea grande','Alta capacidad muscular','Acumula grasa con facilidad','Metabolismo más lento'],
    ketoTips:['Carbs netos máx 15g/día (más estricto)','Ayuno 16:8 o 18:6 prioritario','Cardio en ayunas 3-4x semana','Medir cetonas diariamente primeras 4 semanas'],
    carbLimit:15, protein:1.8, fat:75,
  },
};

// ─── Ejercicios ───────────────────────────────────────────
export const EXERCISES = [
  // Casa
  { id:'pushup',    name:'Flexiones',          cat:'CASA',     muscle:'Pecho, Tríceps', emoji:'💪', sets:3, reps:15, diff:'BÁSICO',    desc:'Posición plancha, baja el pecho al suelo y empuja. Cuerpo recto como tabla.' },
  { id:'squat_bw',  name:'Sentadillas',         cat:'CASA',     muscle:'Cuádriceps, Glúteos', emoji:'🦵', sets:3, reps:20, diff:'BÁSICO', desc:'Pies al ancho de hombros, baja como sentarte en silla invisible.' },
  { id:'plank',     name:'Plancha',             cat:'CASA',     muscle:'Core',           emoji:'⚡', sets:3, reps:1, repUnit:'×45seg', diff:'BÁSICO', desc:'Antebrazos y puntillas. Cuerpo recto, activa el abdomen.' },
  { id:'lunge',     name:'Zancadas',            cat:'CASA',     muscle:'Cuádriceps, Glúteos', emoji:'🦶', sets:3, reps:12, diff:'BÁSICO', desc:'Paso al frente, baja la rodilla trasera casi al suelo. Alterna piernas.' },
  { id:'bridge',    name:'Puente de Glúteos',   cat:'CASA',     muscle:'Glúteos, Core',  emoji:'🍑', sets:3, reps:20, diff:'BÁSICO',    desc:'Boca arriba, pies en suelo. Eleva caderas apretando glúteos.' },
  { id:'burpee',    name:'Burpees',             cat:'CASA',     muscle:'Cuerpo Completo',emoji:'🔥', sets:3, reps:10, diff:'AVANZADO',  desc:'De pie, baja al suelo, flexión, salta. Máxima intensidad metabólica.' },
  { id:'climber',   name:'Escalador',           cat:'CASA',     muscle:'Core, Cardio',   emoji:'🧗', sets:3, reps:30, diff:'INTERMEDIO', desc:'Plancha alta, rodillas al pecho alternadas. Ritmo explosivo.' },
  { id:'superman',  name:'Superman',            cat:'CASA',     muscle:'Espalda Baja',   emoji:'🦸', sets:3, reps:15, diff:'BÁSICO',    desc:'Boca abajo, eleva brazos y piernas simultáneas. Sostén 2 seg.' },
  // Parque
  { id:'pullup',    name:'Dominadas',           cat:'PARQUE',   muscle:'Espalda, Bíceps',emoji:'🔝', sets:3, reps:8,  diff:'AVANZADO',  desc:'Palmas hacia afuera, sube hasta que el mentón pase la barra.' },
  { id:'chinup',    name:'Jalones Supinos',     cat:'PARQUE',   muscle:'Bíceps, Espalda',emoji:'💪', sets:3, reps:10, diff:'INTERMEDIO', desc:'Palmas hacia ti. Más activación de bíceps que las dominadas.' },
  { id:'bar_dip',   name:'Fondos en Barras',    cat:'PARQUE',   muscle:'Tríceps, Pecho', emoji:'⬇️', sets:3, reps:12, diff:'INTERMEDIO', desc:'Barras paralelas, baja doblando codos a 90°. Empuja hacia arriba.' },
  { id:'leg_raise', name:'Elevación de Piernas',cat:'PARQUE',   muscle:'Abdomen',        emoji:'🦿', sets:3, reps:12, diff:'AVANZADO',  desc:'Colgado de barra, sube las piernas rectas hasta la horizontal.' },
  { id:'aus_row',   name:'Remo Australiano',    cat:'PARQUE',   muscle:'Espalda Media',  emoji:'🏊', sets:3, reps:15, diff:'BÁSICO',    desc:'Bajo una barra baja, jala el pecho hacia la barra.' },
  { id:'muscle_up', name:'Muscle Up',           cat:'PARQUE',   muscle:'Cuerpo Completo',emoji:'🔱', sets:3, reps:5,  diff:'ÉLITE',     desc:'Combinación de jalón y fondo en una sola ejecución continua.' },
  // Gimnasio
  { id:'bench',     name:'Press de Banca',      cat:'GIMNASIO', muscle:'Pecho, Tríceps', emoji:'🏋️', sets:4, reps:10, diff:'INTERMEDIO', desc:'Barra al pecho controladamente. Empuje explosivo hacia arriba.' },
  { id:'deadlift',  name:'Peso Muerto',         cat:'GIMNASIO', muscle:'Espalda, Glúteos',emoji:'⚔️',sets:4, reps:6,  diff:'AVANZADO',  desc:'Levanta la barra del suelo. Espalda neutra. El rey de la fuerza.' },
  { id:'squat_bb',  name:'Sentadilla con Barra',cat:'GIMNASIO', muscle:'Cuádriceps, Glúteos',emoji:'🦁',sets:4, reps:8, diff:'AVANZADO', desc:'Barra en trapecio, muslos paralelos al suelo. Máximo estímulo.' },
  { id:'press_mil', name:'Press Militar',       cat:'GIMNASIO', muscle:'Hombros, Tríceps',emoji:'🎯', sets:3, reps:10, diff:'INTERMEDIO', desc:'Empuja la barra sobre la cabeza. Extensión completa de brazos.' },
  { id:'lat_pull',  name:'Jalón al Pecho',      cat:'GIMNASIO', muscle:'Espalda, Bíceps', emoji:'🔽', sets:3, reps:12, diff:'BÁSICO',   desc:'Polea alta, jala hasta el pecho manteniendo pecho erguido.' },
  { id:'leg_press', name:'Prensa de Piernas',   cat:'GIMNASIO', muscle:'Cuádriceps',      emoji:'🦵', sets:3, reps:15, diff:'BÁSICO',   desc:'Empuja la plataforma hasta extensión casi completa.' },
  { id:'curl',      name:'Curl de Bíceps',      cat:'GIMNASIO', muscle:'Bíceps',          emoji:'💪', sets:3, reps:12, diff:'BÁSICO',   desc:'Curl supino completo. Aprieta en la cima del movimiento.' },
  { id:'tricep_pd', name:'Extensión Tríceps',   cat:'GIMNASIO', muscle:'Tríceps',         emoji:'🔻', sets:3, reps:15, diff:'BÁSICO',   desc:'Polea alta, empuja hacia abajo. Codos fijos a los lados.' },
];

// ─── Suplementos ──────────────────────────────────────────
export const SUPPLEMENTS = [
  { id:'creatine', name:'Creatina',        emoji:'⚡', keto:true,  score:5, dose:'5g/día',         timing:['Post-entreno'],           benefit:'Aumenta fuerza y potencia. No interfiere con cetosis.' },
  { id:'mag',      name:'Magnesio',        emoji:'🧲', keto:true,  score:5, dose:'400mg/noche',    timing:['Antes de dormir'],        benefit:'Esencial en keto. Previene calambres. Mejora sueño.' },
  { id:'omega3',   name:'Omega-3',         emoji:'🐟', keto:true,  score:5, dose:'2-4g/día',       timing:['Con desayuno'],           benefit:'Antiinflamatorio potente. Apoya función cerebral.' },
  { id:'vitd3',    name:'Vitamina D3+K2',  emoji:'☀️', keto:true,  score:5, dose:'5000UI D3',      timing:['Con desayuno'],           benefit:'Regula calcio, inmunidad y hormonas.' },
  { id:'electro',  name:'Electrolitos',    emoji:'💧', keto:true,  score:5, dose:'Según marca',    timing:['Mañana','Pre-entreno'],   benefit:'Crítico en keto. Previene keto-gripe y calambres.' },
  { id:'mct',      name:'Aceite MCT',      emoji:'🫒', keto:true,  score:5, dose:'1-3 cdas/día',   timing:['Ayunas','Con café'],      benefit:'Eleva cetonas rápidamente. Energía cerebral inmediata.' },
  { id:'collagen', name:'Colágeno',        emoji:'🦴', keto:true,  score:4, dose:'10-15g/día',     timing:['Ayunas'],                 benefit:'Salud articular y piel. Proteína sin carbos.' },
  { id:'ashwa',    name:'Ashwagandha',     emoji:'🌿', keto:true,  score:4, dose:'300-600mg/día',  timing:['Antes de dormir'],        benefit:'Reduce cortisol. Mejora sueño y recuperación.' },
  { id:'zinc',     name:'Zinc',            emoji:'🔬', keto:true,  score:4, dose:'15-30mg/día',    timing:['Con comida'],             benefit:'Testosterona, inmunidad y síntesis proteica.' },
  { id:'curcuma',  name:'Cúrcuma+Pimienta',emoji:'🌾', keto:true,  score:5, dose:'500mg+5mg',      timing:['Con comida grasa'],       benefit:'Antiinflamatorio natural. Sinergia perfecta con keto.' },
  { id:'melatonin',name:'Melatonina',      emoji:'🌙', keto:true,  score:5, dose:'0.5-3mg',        timing:['30min antes dormir'],     benefit:'Regula sueño. Antioxidante. Mejora calidad del descanso.' },
  { id:'bcaa',     name:'BCAAs',           emoji:'🧬', keto:false, score:2, dose:'5-10g',          timing:['Pre-entreno'],            benefit:'Reduce catabolismo. Precaución: puede elevar insulina.' },
  { id:'whey',     name:'Proteína Whey',   emoji:'🥛', keto:false, score:2, dose:'25-50g',         timing:['Post-entreno'],           benefit:'Proteína de alto valor. Puede romper cetosis en exceso.' },
  { id:'caffeine', name:'Cafeína',         emoji:'☕', keto:true,  score:4, dose:'100-200mg',      timing:['Pre-entreno','Mañana'],   benefit:'Eleva cetonas levemente. Mejora rendimiento y quema grasa.' },
];

// ─── Alimentos con evaluación keto ───────────────────────
export const KETO_FOODS = {
  // Totalmente compatibles
  huevos:       { keto:true,  level:'ÓPTIMO',   carbs:0.6,  desc:'Proteína perfecta + grasas esenciales. El alimento keto por excelencia.' },
  carne:        { keto:true,  level:'ÓPTIMO',   carbs:0,    desc:'Proteína de alto valor biológico. Sin carbohidratos. Ideal.' },
  pollo:        { keto:true,  level:'ÓPTIMO',   carbs:0,    desc:'Proteína magra. Sin carbohidratos. Versátil y keto-compatible.' },
  salmon:       { keto:true,  level:'ÓPTIMO',   carbs:0,    desc:'Omega-3 + proteína + grasa saludable. Perfecto para cetosis.' },
  atun:         { keto:true,  level:'ÓPTIMO',   carbs:0,    desc:'Alta proteína, bajo en carbos. Excelente opción keto.' },
  tocino:       { keto:true,  level:'ÓPTIMO',   carbs:0.1,  desc:'Grasa animal natural. Alta saciedad. Keto-compatible.' },
  mantequilla:  { keto:true,  level:'ÓPTIMO',   carbs:0.1,  desc:'Grasa pura. Sube cetonas. Básico en dieta keto.' },
  queso:        { keto:true,  level:'ÓPTIMO',   carbs:1.3,  desc:'Grasa + proteína. Pocas carbos. Compatible en cantidades moderadas.' },
  aguacate:     { keto:true,  level:'ÓPTIMO',   carbs:1.8,  desc:'Grasa monoinsaturada + potasio + fibra. Superalimento keto.' },
  aceite:       { keto:true,  level:'ÓPTIMO',   carbs:0,    desc:'Grasa pura (oliva, coco, MCT). Fundamental en keto.' },
  nueces:       { keto:true,  level:'ÓPTIMO',   carbs:3.0,  desc:'Grasas saludables + proteína. Keto-compatible en porciones.' },
  almendras:    { keto:true,  level:'ÓPTIMO',   carbs:2.9,  desc:'Snack keto ideal. Grasas + proteína + fibra.' },
  espinaca:     { keto:true,  level:'ÓPTIMO',   carbs:1.4,  desc:'Vegetales de hoja verde. Muy bajos en carbos. Ideales.' },
  albahaca:     { keto:true,  level:'ÓPTIMO',   carbs:0.4,  desc:'Hierba aromática. Prácticamente sin carbos. Totalmente compatible.' },
  champiñones:  { keto:true,  level:'ÓPTIMO',   carbs:2.3,  desc:'Hongos bajos en carbos. Ricos en nutrientes. Compatibles.' },
  coliflor:     { keto:true,  level:'ÓPTIMO',   carbs:2.9,  desc:'Perfecto sustituto de arroz/papa. Muy bajo en carbos.' },
  apio:         { keto:true,  level:'ÓPTIMO',   carbs:1.4,  desc:'Muy bajo en carbos. Alto en agua y electrolitos.' },
  crema:        { keto:true,  level:'ÓPTIMO',   carbs:3.0,  desc:'Grasa láctea alta. Compatible en cantidades moderadas.' },
  // Compatibles con precaución
  zanahoria:    { keto:false, level:'PRECAUCIÓN',carbs:6.8, desc:'Moderadamente alta en carbos. Usar en pequeñas cantidades (< 50g).' },
  tomate:       { keto:false, level:'PRECAUCIÓN',carbs:3.9, desc:'Carbos moderados. Pequeñas cantidades aceptables en keto.' },
  cebolla:      { keto:false, level:'PRECAUCIÓN',carbs:7.6, desc:'Alta en fructosa. Usar como condimento, no como base.' },
  limon:        { keto:false, level:'PRECAUCIÓN',carbs:6.9, desc:'Usar solo el jugo en pequeñas cantidades para sazón.' },
  fresas:       { keto:false, level:'PRECAUCIÓN',carbs:5.5, desc:'La fruta más keto-amigable. Solo porciones pequeñas (< 100g).' },
  // No compatibles
  azucar:       { keto:false, level:'EVITAR',   carbs:100,  desc:'❌ Rompe la cetosis inmediatamente. Evitar por completo.' },
  pan:          { keto:false, level:'EVITAR',   carbs:49,   desc:'❌ Alto en carbohidratos. No compatible con estilo cetogénico.' },
  pasta:        { keto:false, level:'EVITAR',   carbs:71,   desc:'❌ Carbohidratos puros. No tiene lugar en dieta keto.' },
  arroz:        { keto:false, level:'EVITAR',   carbs:80,   desc:'❌ Muy alto en carbos. Romperá la cetosis rápidamente.' },
  papa:         { keto:false, level:'EVITAR',   carbs:17,   desc:'❌ Almidón concentrado. No compatible con cetosis.' },
  maiz:         { keto:false, level:'EVITAR',   carbs:19,   desc:'❌ Almidón y azúcares. No compatible con keto.' },
};

// ─── Bebidas ──────────────────────────────────────────────
export const BEVERAGES = [
  { id:'water',     name:'Agua',               emoji:'💧', unit:'ml', keto:true,  desc:'Base de la hidratación. 2-3L diarios recomendados en keto.' },
  { id:'salt_water',name:'Agua con Sal',        emoji:'🧂', unit:'ml', keto:true,  desc:'Repone sodio. Esencial para prevenir keto-gripe y calambres.' },
  { id:'green_tea', name:'Té Verde',            emoji:'🍵', unit:'ml', keto:true,  desc:'Antioxidantes + leve termogénico. Apoya cetosis.' },
  { id:'black_tea', name:'Té Negro',            emoji:'🫖', unit:'ml', keto:true,  desc:'Cafeína natural + antioxidantes. Compatible con keto.' },
  { id:'coffee',    name:'Café Negro',          emoji:'☕', unit:'ml', keto:true,  desc:'Eleva cetonas levemente. Mejora rendimiento cognitivo.' },
  { id:'butter_cof',name:'Café Bulletproof',    emoji:'🧈', unit:'ml', keto:true,  desc:'Café + mantequilla + MCT. Combustible keto supremo.' },
  { id:'bone_broth',name:'Caldo de Huesos',     emoji:'🍲', unit:'ml', keto:true,  desc:'Electrolitos naturales + colágeno. Ideal durante el ayuno.' },
  { id:'sparkling', name:'Agua Mineral',        emoji:'💦', unit:'ml', keto:true,  desc:'Hidratación con minerales. Sin carbohidratos.' },
  { id:'herbal_tea',name:'Infusión de Hierbas', emoji:'🌿', unit:'ml', keto:true,  desc:'Relajante y sin carbos. Manzanilla, menta, jengibre.' },
  { id:'lemon_wat', name:'Agua con Limón',      emoji:'🍋', unit:'ml', keto:true,  desc:'Pequeñas cantidades de limón. Refrescante y levemente alcalino.' },
];

// ─── Recetas ──────────────────────────────────────────────
const normalize = s => s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim();

const RECIPES = [
  { id:'r1', name:'Huevos Revueltos con Espinaca', emoji:'🥚', time:'10min', carbs:2, protein:18, fat:22, required:['huevos','espinaca'], steps:['Batir 3 huevos con sal y pimienta.','Saltear espinaca en mantequilla.','Agregar huevos, revolver a fuego bajo.','Retirar húmedos y servir.'] },
  { id:'r2', name:'Omelette de Queso',             emoji:'🍳', time:'8min',  carbs:1, protein:22, fat:28, required:['huevos','queso'],    steps:['Batir 3 huevos.','Calentar mantequilla en sartén.','Verter huevos, no revolver.','Al cuajar, agregar queso y doblar.'] },
  { id:'r3', name:'Pollo al Pesto de Albahaca',    emoji:'🐔', time:'25min', carbs:3, protein:38, fat:25, required:['pollo','albahaca'],  steps:['Licuar albahaca, ajo y aceite.','Marinar pollo 15 min.','Cocinar 6-7 min por lado.','Servir con ensalada.'] },
  { id:'r4', name:'Ensalada de Atún y Aguacate',   emoji:'🥗', time:'5min',  carbs:4, protein:28, fat:30, required:['atun','aguacate'],   steps:['Escurrir y desmenuzar atún.','Cortar aguacate en cubos.','Mezclar con jugo de limón.','Sazonar con sal y pimienta.'] },
  { id:'r5', name:'Carne con Champiñones',         emoji:'🥩', time:'20min', carbs:5, protein:35, fat:32, required:['carne','champiñones'],steps:['Dorar la carne en sartén.','Agregar champiñones y ajo.','Añadir crema y reducir.','Sazonar con tomillo.'] },
  { id:'r6', name:'Salmón con Mantequilla',        emoji:'🐟', time:'15min', carbs:1, protein:40, fat:35, required:['salmon','mantequilla'],steps:['Secar el salmón.','Sellar 4 min por lado con mantequilla.','Agregar ajo y limón.','Terminar con eneldo.'] },
  { id:'r7', name:'Arroz de Coliflor Frito',       emoji:'🥦', time:'20min', carbs:7, protein:15, fat:20, required:['coliflor','huevos'],  steps:['Rallar coliflor fino.','Saltear en wok caliente.','Agregar huevos y revolver.','Sazonar con sal y cebollín.'] },
  { id:'r8', name:'Desayuno Keto Clásico',         emoji:'🥓', time:'12min', carbs:1, protein:25, fat:35, required:['huevos','tocino'],    steps:['Cocinar tocino hasta crujiente.','Freír huevos en la grasa.','Agregar espinaca si hay.','Servir todo junto.'] },
  { id:'r9', name:'Batido de Aguacate Keto',       emoji:'🥑', time:'3min',  carbs:3, protein:8,  fat:25, required:['aguacate'],          steps:['Poner aguacate en licuadora.','Agregar leche de coco.','Licuar con hielo.','Ajustar consistencia.'] },
  { id:'r10',name:'Sopa de Pollo y Apio',          emoji:'🍲', time:'35min', carbs:6, protein:30, fat:18, required:['pollo','apio'],       steps:['Hervir pollo con sal 20 min.','Desmechar y reservar caldo.','Agregar apio y verduras.','Sazonar y servir caliente.'] },
];

export const generateRecipes = (pantryItems = []) => {
  const norm = pantryItems.map(normalize);
  return RECIPES.map(r => {
    const matches = r.required.filter(req => norm.some(n => n.includes(normalize(req)) || normalize(req).includes(n)));
    const score = (matches.length / r.required.length) * 100;
    return { ...r, matchScore: score, hasAll: matches.length === r.required.length, matches, missing: r.required.filter(req => !norm.some(n => n.includes(normalize(req)) || normalize(req).includes(n))) };
  }).filter(r => r.matchScore > 0).sort((a,b) => (b.hasAll - a.hasAll) || (b.matchScore - a.matchScore));
};

export const evaluateFood = (name) => {
  const key = normalize(name);
  return Object.entries(KETO_FOODS).find(([k]) => key.includes(k) || k.includes(key))?.[1] || null;
};
