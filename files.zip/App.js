/**
 * ZIMA · App.js
 * ─────────────────────────────────────────────────
 * Raíz de la aplicación. Gestiona estado global,
 * persistencia con AsyncStorage y navegación.
 *
 * Para ejecutar:
 *   npx create-expo-app zima-app --template blank
 *   cd zima-app
 *   npx expo install @react-native-async-storage/async-storage
 *   cp -r [archivos del proyecto] .
 *   npx expo start
 * ─────────────────────────────────────────────────
 */
import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, TouchableOpacity,
  StyleSheet, SafeAreaView, StatusBar,
  ActivityIndicator,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

// Screens
import DashboardScreen   from './screens/DashboardScreen';
import BiometricsScreen  from './screens/BiometricsScreen';
import NutritionScreen   from './screens/NutritionScreen';
import AvatarScreen      from './screens/AvatarScreen';

// ─── Estado inicial del app ───────────────────
const INITIAL_STATE = {
  // Biométricos
  ketones:        0.0,
  weight:         75.0,
  bioHistory:     [],

  // Nutrición
  netCarbsToday:  0,
  meals:          [],

  // Entrenamiento / Avatar
  loadVolume:     0,
  adherenceDays:  0,
  loadHistory:    [],

  // Meta
  createdAt:      new Date().toISOString(),
  version:        '2.0.0',
};

const STORAGE_KEY = '@zima_state_v2';

// ─── Navegación inferior ──────────────────────
const NAV_ITEMS = [
  { id: 'dashboard',  icon: '◉', label: 'Dashboard' },
  { id: 'biometrics', icon: '⬡', label: 'Biometría' },
  { id: 'nutrition',  icon: '⊡', label: 'Nutrición' },
  { id: 'avatar',     icon: '△', label: 'Avatar'    },
];

// ─── Root App ─────────────────────────────────
export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [appState,  setAppState]  = useState(INITIAL_STATE);
  const [loading,   setLoading]   = useState(true);

  // ── Cargar estado persistido ──────────────
  useEffect(() => {
    const loadState = async () => {
      try {
        const raw = await AsyncStorage.getItem(STORAGE_KEY);
        if (raw) {
          const saved = JSON.parse(raw);
          // Merge con INITIAL_STATE para añadir nuevos campos en futuras versiones
          setAppState({ ...INITIAL_STATE, ...saved });
        }
      } catch (e) {
        console.warn('ZIMA: Error cargando estado', e);
      } finally {
        setLoading(false);
      }
    };
    loadState();
  }, []);

  // ── Actualizar y persistir estado ────────
  const updateState = useCallback(async (newState) => {
    try {
      const merged = { ...appState, ...newState };
      setAppState(merged);
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(merged));
    } catch (e) {
      console.warn('ZIMA: Error guardando estado', e);
    }
  }, [appState]);

  // ── Reset (debug) ─────────────────────────
  const resetState = async () => {
    await AsyncStorage.removeItem(STORAGE_KEY);
    setAppState(INITIAL_STATE);
  };

  // ── Pantalla activa ───────────────────────
  const renderScreen = () => {
    const props = { state: appState, onUpdate: updateState };
    switch (activeTab) {
      case 'dashboard':  return <DashboardScreen  {...props} />;
      case 'biometrics': return <BiometricsScreen {...props} />;
      case 'nutrition':  return <NutritionScreen  {...props} />;
      case 'avatar':     return <AvatarScreen     {...props} />;
      default:           return <DashboardScreen  {...props} />;
    }
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <StatusBar barStyle="light-content" backgroundColor="#080B0F" />
        <ActivityIndicator color="#5BCFDA" size="large" />
        <Text style={styles.loadingText}>INICIANDO MOTOR SIM...</Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.root}>
      <StatusBar barStyle="light-content" backgroundColor="#080B0F" />

      {/* Ambient glow top */}
      <View style={styles.ambientGlow} pointerEvents="none" />

      {/* Contenido principal */}
      <View style={styles.screenContainer}>
        {renderScreen()}
      </View>

      {/* Bottom Navigation */}
      <View style={styles.navBar}>
        {NAV_ITEMS.map((item) => {
          const active = activeTab === item.id;
          return (
            <TouchableOpacity
              key={item.id}
              style={styles.navItem}
              onPress={() => setActiveTab(item.id)}
              activeOpacity={0.7}
            >
              <Text style={[styles.navIcon, active && styles.navIconActive]}>
                {item.icon}
              </Text>
              <Text style={[styles.navLabel, active && styles.navLabelActive]}>
                {item.label}
              </Text>
              {active && <View style={styles.navDot} />}
            </TouchableOpacity>
          );
        })}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: {
    flex:            1,
    backgroundColor: '#080B0F',
  },
  loadingContainer: {
    flex:            1,
    backgroundColor: '#080B0F',
    alignItems:      'center',
    justifyContent:  'center',
    gap:             16,
  },
  loadingText: {
    color:        '#6B7F8E',
    fontFamily:   'monospace',
    fontSize:     12,
    letterSpacing: 3,
  },
  ambientGlow: {
    position:        'absolute',
    top:             -60,
    left:            '25%',
    width:           200,
    height:          200,
    borderRadius:    100,
    backgroundColor: 'rgba(91,207,218,0.06)',
    zIndex:          0,
  },
  screenContainer: {
    flex:    1,
    zIndex:  1,
  },
  navBar: {
    flexDirection:     'row',
    backgroundColor:   '#0D1219',
    borderTopWidth:    1,
    borderTopColor:    '#1C2730',
    paddingBottom:     8,
    paddingTop:        6,
    zIndex:            10,
  },
  navItem: {
    flex:           1,
    alignItems:     'center',
    justifyContent: 'center',
    gap:            3,
    paddingVertical: 4,
  },
  navIcon: {
    fontSize: 18,
    color:    '#3A4F5C',
  },
  navIconActive: {
    color: '#5BCFDA',
    // shadowColor:  '#5BCFDA',
    // shadowOpacity: 0.8,
    // shadowRadius: 6,
  },
  navLabel: {
    fontSize:      9,
    fontFamily:    'monospace',
    color:         '#3A4F5C',
    letterSpacing: 0.5,
  },
  navLabelActive: {
    color:      '#5BCFDA',
    fontWeight: '600',
  },
  navDot: {
    width:           4,
    height:          4,
    borderRadius:    2,
    backgroundColor: '#5BCFDA',
    marginTop:       2,
  },
});
