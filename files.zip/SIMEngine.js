/**
 * ZIMA · Motor SIM v2.0
 * Sistema de Inteligencia Metabólica
 * ─────────────────────────────────────────────
 * Núcleo de cálculo metabólico desacoplado de UI.
 * Escalable hacia IA: cada función puede ser
 * reemplazada por una llamada a modelo ML/LLM.
 */

// ─── Constantes del motor ─────────────────────
export const SIM_CONSTANTS = {
  KETO_THRESHOLDS: {
    NONE:        0.5,   // < 0.5 mmol/L  → fuera de cetosis
    NUTRITIONAL: 1.5,   // 0.5–1.5       → cetosis nutricional
    OPTIMAL:     3.0,   // 1.5–3.0       → cetosis óptima
    HIGH:        5.0,   // 3.0–5.0       → cetosis elevada
  },
  CARB_LIMITS: {
    STRICT:    20,   // g/día modo estricto
    STANDARD:  25,   // g/día estándar
    FLEXIBLE:  50,   // g/día flexible
  },
  AVATAR_THRESHOLDS: [0, 500, 2000, 5000, 10000],
  INFLAMMATION_WEIGHTS: {
    KETO:    0.40,
    CARBS:   0.35,
    STRESS:  0.15,
    SLEEP:   0.10,
  },
};

// ─── Analizador cetogénico ────────────────────
export const analyzeKetosis = (mmolL) => {
  const t = SIM_CONSTANTS.KETO_THRESHOLDS;
  if (mmolL < t.NONE)        return { state: 'none',        label: 'Sin cetosis',     score: 0,    color: '#6B7F8E' };
  if (mmolL < t.NUTRITIONAL) return { state: 'nutritional', label: 'Nutricional',     score: 0.4,  color: '#D4A853' };
  if (mmolL < t.OPTIMAL)     return { state: 'optimal',     label: 'Óptima ✓',        score: 0.85, color: '#5BCFDA' };
  if (mmolL < t.HIGH)        return { state: 'high',        label: 'Elevada',         score: 0.7,  color: '#D4A853' };
  return                              { state: 'danger',     label: 'Riesgo alto',     score: 0.2,  color: '#E05A4E' };
};

// ─── Calculador de inflamación (0–1) ──────────
export const calculateInflammation = ({
  ketones       = 1.0,
  netCarbsToday = 25,
  stressLevel   = 3,    // 0–10
  sleepHours    = 7,    // horas
}) => {
  const { KETO, CARBS, STRESS, SLEEP } = SIM_CONSTANTS.INFLAMMATION_WEIGHTS;

  // Factor cetogénico (más cetonas = menos inflamación)
  const ketoFactor = ketones >= 3.0 ? 0.05
    : ketones >= 1.5 ? 0.15
    : ketones >= 0.5 ? 0.40
    : 0.70;

  // Factor carbohidratos
  const carbFactor = Math.min(netCarbsToday / 50, 1);

  // Factor estrés
  const stressFactor = stressLevel / 10;

  // Factor sueño (< 6h aumenta inflamación)
  const sleepFactor = sleepHours >= 8 ? 0.1
    : sleepHours >= 6 ? 0.3
    : 0.8;

  const score = (
    ketoFactor   * KETO  +
    carbFactor   * CARBS +
    stressFactor * STRESS +
    sleepFactor  * SLEEP
  );

  return Math.min(Math.max(score, 0), 1);
};

// ─── Nivel de avatar ──────────────────────────
export const calculateAvatarLevel = (loadVolume, ketones, adherenceDays) => {
  const thresholds = SIM_CONSTANTS.AVATAR_THRESHOLDS;
  let baseLevel = 0;
  for (let i = thresholds.length - 1; i >= 0; i--) {
    if (loadVolume >= thresholds[i]) { baseLevel = i; break; }
  }

  // Bonus por cetosis óptima y adherencia
  const ketosisBonus  = ketones >= 1.5 && ketones < 5 ? 1 : 0;
  const adherenceBonus = adherenceDays >= 30 ? 1 : 0;

  return Math.min(baseLevel + Math.floor((ketosisBonus + adherenceBonus) / 2), 4);
};

// ─── Estado metabólico global ─────────────────
export const getMetabolicStatus = ({ ketones, netCarbsToday, inflammationScore }) => {
  if (inflammationScore > 0.7)
    return { status: 'ALERTA',    message: 'Inflamación crítica. Activa protocolo botánico.',   color: '#E05A4E' };
  if (ketones >= 1.5 && netCarbsToday <= 25 && inflammationScore < 0.3)
    return { status: 'ÓPTIMO',    message: 'Sistema cetogénico en estado peak. Mantén curso.',  color: '#4EBE8A' };
  if (ketones >= 0.5 && netCarbsToday <= 50)
    return { status: 'ESTABLE',   message: 'Cetosis activa. Optimiza carbohidratos y descanso.', color: '#5BCFDA' };
  if (ketones < 0.5)
    return { status: 'INACTIVO',  message: 'Sin cetosis. Reduce carbohidratos < 20g hoy.',      color: '#D4A853' };
  return   { status: 'TRANSICIÓN', message: 'En adaptación metabólica. Persiste 48–72h.',       color: '#D4A853' };
};

// ─── Recomendación botánica ───────────────────
export const getBotanicalProtocol = (inflammationScore) => {
  if (inflammationScore < 0.30) return null;

  if (inflammationScore < 0.50) return {
    level:    'PREVENTIVO',
    herbs: [
      { name: 'Cúrcuma + Pimienta Negra', dose: '500mg + 5mg', timing: 'Con comida grasa' },
      { name: 'Omega-3 DHA/EPA',          dose: '2g/día',       timing: 'Con desayuno' },
    ],
    protocol: 'Mantén cetonas > 1.5 mmol/L. Reduce carbohidratos netos < 20g.',
    color:    '#D4A853',
    urgency:  1,
  };

  if (inflammationScore < 0.70) return {
    level:    'ACTIVO',
    herbs: [
      { name: 'Boswellia serrata',         dose: '300mg 2×/día', timing: 'En ayunas + noche' },
      { name: 'Cúrcuma Fosfolipídica',     dose: '500mg/día',    timing: 'Con grasa' },
      { name: 'Quercetina + Bromelina',    dose: '500mg/250mg',  timing: 'Entre comidas' },
    ],
    protocol: 'Activa ayuno 16:8. Elimina carbohidratos refinados. Prioriza sueño 8h.',
    color:    '#D4A853',
    urgency:  2,
  };

  return {
    level:    'CRÍTICO',
    herbs: [
      { name: 'Boswellia serrata',         dose: '600mg/día',    timing: 'Mañana y noche' },
      { name: 'Cúrcuma Fosfolipídica',     dose: '1g/día',       timing: 'Con comida' },
      { name: 'Resveratrol',               dose: '250mg/día',    timing: 'Con grasa' },
      { name: 'NAC (N-Acetil Cisteína)',   dose: '600mg/día',    timing: 'En ayunas' },
    ],
    protocol: '⚠ Consultar médico. Ayuno 18:6. Elimina gluten, lácteos, azúcares. Prioriza antiinflamatorios.',
    color:    '#E05A4E',
    urgency:  3,
  };
};

// ─── Generador de insights SIM ────────────────
// ESCALABILIDAD: Reemplazar con llamada a LLM/Claude API
export const generateSIMInsight = (state) => {
  const { ketones, netCarbsToday, weight, loadVolume, inflammationScore } = state;

  const insights = [];

  if (ketones < 0.5)
    insights.push('⚡ Inicia ayuno intermitente 16:8 para entrar en cetosis más rápido.');
  if (ketones >= 1.5 && ketones < 3.0)
    insights.push('✓ Cetosis óptima activa. Tu cerebro opera con combustible limpio.');
  if (netCarbsToday > 25)
    insights.push(`↓ Redujiste ${(netCarbsToday - 25).toFixed(0)}g más de carbohidratos. Objetivo: < 25g.`);
  if (inflammationScore > 0.6)
    insights.push('🌿 Activa protocolo botánico antiinflamatorio hoy.');
  if (loadVolume > 5000)
    insights.push('⚔️ Nivel guerrero alcanzado. El estrés anabólico potencia la cetosis.');

  return insights.length > 0
    ? insights
    : ['Sistema metabólico estable. Mantén protocolo actual.'];
};
