/**
 * ZIMA · NutritionScanner
 * Ingreso de macros y cálculo de carbohidratos netos.
 * Preparado para integrar OCR / escáner de cámara.
 */
import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity,
  ScrollView, StyleSheet, Alert,
} from 'react-native';
import { calculateNetCarbs, isKetoFriendly, POLYOL_FACTORS } from '../utils/netCarbsCalculator';

const POLYOL_OPTIONS = Object.keys(POLYOL_FACTORS);

const MacroField = ({ label, value, onChange, unit = 'g', hint }) => (
  <View style={styles.fieldWrap}>
    <Text style={styles.fieldLabel}>{label}</Text>
    <View style={styles.fieldRow}>
      <TextInput
        style={styles.fieldInput}
        value={value}
        onChangeText={onChange}
        keyboardType="decimal-pad"
        placeholder="0"
        placeholderTextColor="#3A4F5C"
        maxLength={6}
      />
      <Text style={styles.fieldUnit}>{unit}</Text>
    </View>
    {hint && <Text style={styles.fieldHint}>{hint}</Text>}
  </View>
);

const NutritionScanner = ({ onSave, meals = [] }) => {
  const [name,        setName]       = useState('');
  const [totalCarbs,  setTotalCarbs] = useState('');
  const [fiber,       setFiber]      = useState('');
  const [polyols,     setPolyols]    = useState('');
  const [erythritol,  setErythritol] = useState('');
  const [polyolType,  setPolyolType] = useState('generic');
  const [servings,    setServings]   = useState('1');
  const [result,      setResult]     = useState(null);
  const [showAdvanced, setShowAdvanced] = useState(false);

  const calculate = () => {
    const macros = {
      totalCarbs:  parseFloat(totalCarbs)  || 0,
      fiber:       parseFloat(fiber)       || 0,
      polyols:     parseFloat(polyols)     || 0,
      erythritol:  parseFloat(erythritol)  || 0,
      polyolType,
    };

    if (macros.totalCarbs === 0) {
      Alert.alert('ZIMA', 'Ingresa al menos los carbohidratos totales.');
      return;
    }

    const srvgs = parseFloat(servings) || 1;
    const r = calculateNetCarbs(macros);
    const scaledNetCarbs = r.netCarbs * srvgs;
    const friendly = isKetoFriendly(r.netCarbs, srvgs);

    setResult({ ...r, scaledNetCarbs, servings: srvgs, friendly });
  };

  const saveFood = async () => {
    if (!result) { calculate(); return; }

    const entry = {
      id:         Date.now().toString(),
      name:       name || 'Alimento sin nombre',
      netCarbs:   result.scaledNetCarbs,
      totalCarbs: result.totalCarbs * result.servings,
      servings:   result.servings,
      timestamp:  Date.now(),
      date:       new Date().toLocaleDateString('es-ES'),
      breakdown:  result.breakdown,
      ketoImpact: result.ketoImpact,
    };

    await onSave?.(entry);
    // Reset
    setName(''); setTotalCarbs(''); setFiber('');
    setPolyols(''); setErythritol(''); setServings('1');
    setResult(null);
    Alert.alert('ZIMA', `✓ "${entry.name}" guardado. +${entry.netCarbs.toFixed(1)}g carbs netos.`);
  };

  const dailyTotal = meals.reduce((a, m) => a + (m.netCarbs || 0), 0);

  return (
    <View style={styles.container}>
      {/* Total del día */}
      <View style={styles.dailyBanner}>
        <Text style={styles.dailyLabel}>CARBS NETOS HOY</Text>
        <Text style={[
          styles.dailyValue,
          { color: dailyTotal <= 25 ? '#4EBE8A' : dailyTotal <= 50 ? '#D4A853' : '#E05A4E' }
        ]}>
          {dailyTotal.toFixed(1)}g
        </Text>
        <View style={styles.dailyTrack}>
          <View style={[
            styles.dailyFill,
            {
              width: `${Math.min((dailyTotal / 50) * 100, 100)}%`,
              backgroundColor: dailyTotal <= 25 ? '#4EBE8A' : dailyTotal <= 50 ? '#D4A853' : '#E05A4E',
            }
          ]} />
        </View>
        <View style={styles.dailyMarkers}>
          <Text style={styles.markerLabel}>0</Text>
          <Text style={[styles.markerLabel, { color: '#4EBE8A' }]}>25g ✓</Text>
          <Text style={styles.markerLabel}>50g</Text>
        </View>
      </View>

      {/* Scanner card */}
      <View style={styles.card}>
        <Text style={styles.cardTitle}>ESCÁNER DE TABLA NUTRICIONAL</Text>

        {/* Nombre del alimento */}
        <View style={{ gap: 4 }}>
          <Text style={styles.fieldLabel}>NOMBRE DEL ALIMENTO</Text>
          <TextInput
            style={styles.fieldInput}
            value={name}
            onChangeText={setName}
            placeholder="Ej: Chocolate 85% cacao"
            placeholderTextColor="#3A4F5C"
            maxLength={60}
          />
        </View>

        {/* Macros principales */}
        <View style={styles.macrosGrid}>
          <MacroField
            label="CARBS TOTALES"
            value={totalCarbs}
            onChange={setTotalCarbs}
            hint="Del envase"
          />
          <MacroField
            label="FIBRA"
            value={fiber}
            onChange={setFiber}
            hint="Dietética"
          />
        </View>

        {/* Porciones */}
        <MacroField
          label="PORCIONES"
          value={servings}
          onChange={setServings}
          unit="×"
          hint="Número de porciones que consumes"
        />

        {/* Avanzado */}
        <TouchableOpacity
          onPress={() => setShowAdvanced(!showAdvanced)}
          style={styles.advancedToggle}
          activeOpacity={0.7}
        >
          <Text style={styles.advancedToggleText}>
            {showAdvanced ? '▲' : '▼'} Polialcoholes / Eritritol
          </Text>
        </TouchableOpacity>

        {showAdvanced && (
          <View style={styles.advancedSection}>
            <View style={styles.macrosGrid}>
              <MacroField
                label="POLIALCOHOLES"
                value={polyols}
                onChange={setPolyols}
                hint="50% de impacto gluc."
              />
              <MacroField
                label="ERITRITOL"
                value={erythritol}
                onChange={setErythritol}
                hint="0% de impacto gluc."
              />
            </View>
            <Text style={styles.fieldLabel}>TIPO DE POLIALCOHOL</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginTop: 6 }}>
              {POLYOL_OPTIONS.map(opt => (
                <TouchableOpacity
                  key={opt}
                  onPress={() => setPolyolType(opt)}
                  style={[
                    styles.polyolChip,
                    polyolType === opt && styles.polyolChipActive,
                  ]}
                  activeOpacity={0.7}
                >
                  <Text style={[
                    styles.polyolChipText,
                    polyolType === opt && { color: '#5BCFDA' },
                  ]}>
                    {opt}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        )}

        {/* Resultado */}
        {result && (
          <View style={[styles.resultBox, { borderColor: result.friendly.friendly ? '#4EBE8A44' : result.friendly.avoid ? '#E05A4E44' : '#D4A85344' }]}>
            <View style={styles.resultMain}>
              <Text style={styles.resultNumLabel}>CARBS NETOS</Text>
              <Text style={[styles.resultNum, {
                color: result.friendly.friendly ? '#4EBE8A' : result.friendly.avoid ? '#E05A4E' : '#D4A853'
              }]}>
                {result.scaledNetCarbs.toFixed(1)}g
              </Text>
            </View>
            <View style={styles.resultBreakdown}>
              <BreakdownRow label="Total" value={`${result.totalCarbs * result.servings}g`} />
              <BreakdownRow label="− Fibra" value={`${(result.fiberReduction * result.servings).toFixed(1)}g`} color="#4EBE8A" />
              {result.polyolReduction > 0 && (
                <BreakdownRow label="− Polialcoholes ×50%" value={`${(result.polyolReduction * result.servings).toFixed(1)}g`} color="#4EBE8A" />
              )}
              {result.erythritolReduction > 0 && (
                <BreakdownRow label="− Eritritol ×0%" value={`${(result.erythritolReduction * result.servings).toFixed(1)}g`} color="#4EBE8A" />
              )}
            </View>
            <Text style={[styles.ketoImpactLabel, {
              color: result.friendly.friendly ? '#4EBE8A' : result.friendly.avoid ? '#E05A4E' : '#D4A853'
            }]}>
              {result.friendly.message} · Impacto cetogénico: {result.ketoImpact}
            </Text>
          </View>
        )}

        {/* Botones */}
        <View style={styles.btnRow}>
          <TouchableOpacity style={styles.calcBtn} onPress={calculate} activeOpacity={0.7}>
            <Text style={styles.calcBtnText}>CALCULAR</Text>
          </TouchableOpacity>
          {result && (
            <TouchableOpacity style={styles.saveBtn} onPress={saveFood} activeOpacity={0.7}>
              <Text style={styles.saveBtnText}>+ GUARDAR</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>

      {/* Lista de comidas del día */}
      {meals.length > 0 && (
        <View style={styles.card}>
          <Text style={styles.cardTitle}>COMIDAS DE HOY</Text>
          {meals.map(meal => (
            <View key={meal.id} style={styles.mealRow}>
              <View style={styles.mealDot} />
              <View style={{ flex: 1 }}>
                <Text style={styles.mealName}>{meal.name}</Text>
                <Text style={styles.mealTime}>{meal.date}</Text>
              </View>
              <Text style={[styles.mealCarbs, {
                color: meal.netCarbs <= 5 ? '#4EBE8A' : meal.netCarbs <= 10 ? '#D4A853' : '#E05A4E'
              }]}>
                {meal.netCarbs.toFixed(1)}g
              </Text>
            </View>
          ))}
        </View>
      )}
    </View>
  );
};

const BreakdownRow = ({ label, value, color = '#E8EDF2' }) => (
  <View style={styles.breakdownRow}>
    <Text style={styles.breakdownLabel}>{label}</Text>
    <Text style={[styles.breakdownValue, { color }]}>{value}</Text>
  </View>
);

const styles = StyleSheet.create({
  container:     { gap: 12 },
  dailyBanner: {
    backgroundColor: '#111820',
    borderWidth:      1,
    borderColor:      '#1C2730',
    borderRadius:     12,
    padding:          14,
    gap:              8,
  },
  dailyLabel:  { fontSize: 9, color: '#6B7F8E', fontFamily: 'monospace', letterSpacing: 2 },
  dailyValue:  { fontFamily: 'monospace', fontWeight: '800', fontSize: 32 },
  dailyTrack: { height: 5, backgroundColor: '#1C2730', borderRadius: 3, overflow: 'hidden' },
  dailyFill:  { height: '100%', borderRadius: 3 },
  dailyMarkers: { flexDirection: 'row', justifyContent: 'space-between' },
  markerLabel:  { fontSize: 9, color: '#6B7F8E', fontFamily: 'monospace' },
  card: {
    backgroundColor: '#111820',
    borderWidth:      1,
    borderColor:      '#1C2730',
    borderRadius:     16,
    padding:          16,
    gap:              12,
  },
  cardTitle: {
    color: '#5BCFDA', fontFamily: 'monospace', fontWeight: '700',
    fontSize: 12, letterSpacing: 2,
    paddingBottom: 10, borderBottomWidth: 1, borderBottomColor: '#1C2730',
  },
  macrosGrid:  { flexDirection: 'row', gap: 12 },
  fieldWrap:   { flex: 1, gap: 4 },
  fieldLabel:  { fontSize: 9, color: '#6B7F8E', fontFamily: 'monospace', letterSpacing: 1 },
  fieldRow:    { flexDirection: 'row', alignItems: 'center', gap: 6 },
  fieldInput: {
    flex: 1, backgroundColor: '#1C2730', borderWidth: 1, borderColor: '#2A3640',
    borderRadius: 8, paddingHorizontal: 10, paddingVertical: 8,
    color: '#E8EDF2', fontFamily: 'monospace', fontSize: 15,
  },
  fieldUnit:  { fontSize: 12, color: '#6B7F8E', fontFamily: 'monospace' },
  fieldHint:  { fontSize: 9, color: '#3A4F5C', fontFamily: 'monospace' },
  advancedToggle: { paddingVertical: 6 },
  advancedToggleText: { color: '#5BCFDA', fontFamily: 'monospace', fontSize: 11, letterSpacing: 1 },
  advancedSection: { gap: 8 },
  polyolChip: {
    paddingHorizontal: 12, paddingVertical: 5, borderRadius: 16,
    backgroundColor: '#1C2730', borderWidth: 1, borderColor: '#2A3640', marginRight: 6,
  },
  polyolChipActive: { borderColor: '#5BCFDA44', backgroundColor: '#5BCFDA11' },
  polyolChipText:   { fontSize: 10, color: '#6B7F8E', fontFamily: 'monospace' },
  resultBox: {
    backgroundColor: '#0D1219', borderWidth: 1, borderRadius: 10, padding: 14, gap: 10,
  },
  resultMain:    { flexDirection: 'row', alignItems: 'baseline', gap: 8 },
  resultNumLabel: { fontSize: 10, color: '#6B7F8E', fontFamily: 'monospace' },
  resultNum:     { fontFamily: 'monospace', fontWeight: '800', fontSize: 28 },
  resultBreakdown: { gap: 3 },
  breakdownRow:   { flexDirection: 'row', justifyContent: 'space-between' },
  breakdownLabel: { fontSize: 11, color: '#6B7F8E', fontFamily: 'monospace' },
  breakdownValue: { fontSize: 11, fontFamily: 'monospace', fontWeight: '600' },
  ketoImpactLabel: { fontSize: 11, fontFamily: 'monospace' },
  btnRow:   { flexDirection: 'row', gap: 8 },
  calcBtn: {
    flex: 1, backgroundColor: '#1C2730', borderWidth: 1, borderColor: '#2A3640',
    borderRadius: 10, paddingVertical: 12, alignItems: 'center',
  },
  calcBtnText: { color: '#5BCFDA', fontFamily: 'monospace', fontWeight: '700', fontSize: 12, letterSpacing: 2 },
  saveBtn: {
    flex: 1, backgroundColor: '#5BCFDA22', borderWidth: 1, borderColor: '#5BCFDA66',
    borderRadius: 10, paddingVertical: 12, alignItems: 'center',
  },
  saveBtnText: { color: '#5BCFDA', fontFamily: 'monospace', fontWeight: '700', fontSize: 12, letterSpacing: 2 },
  mealRow: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: '#1C2730',
  },
  mealDot:   { width: 6, height: 6, borderRadius: 3, backgroundColor: '#5BCFDA' },
  mealName:  { color: '#E8EDF2', fontFamily: 'monospace', fontSize: 13 },
  mealTime:  { color: '#6B7F8E', fontFamily: 'monospace', fontSize: 10 },
  mealCarbs: { fontFamily: 'monospace', fontWeight: '700', fontSize: 14 },
});

export default NutritionScanner;
