/**
 * ZIMA · NutritionScreen
 */
import React from 'react';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet } from 'react-native';
import NutritionScanner from '../components/NutritionScanner';

const NutritionScreen = ({ state, onUpdate }) => {
  const handleSaveMeal = async (meal) => {
    const updated = {
      ...state,
      meals:         [...(state.meals || []), meal],
      netCarbsToday: (state.netCarbsToday || 0) + meal.netCarbs,
    };
    await onUpdate(updated);
  };

  const handleReset = async () => {
    await onUpdate({ ...state, meals: [], netCarbsToday: 0 });
  };

  return (
    <ScrollView
      style={styles.scroll}
      contentContainerStyle={styles.content}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.screenHeader}>
        <View>
          <Text style={styles.screenTitle}>NUTRICIÓN</Text>
          <Text style={styles.screenSub}>Calcula carbohidratos netos</Text>
        </View>
        {(state.meals?.length > 0) && (
          <TouchableOpacity onPress={handleReset} style={styles.resetBtn}>
            <Text style={styles.resetText}>↺ Nuevo día</Text>
          </TouchableOpacity>
        )}
      </View>

      <NutritionScanner
        onSave={handleSaveMeal}
        meals={state.meals || []}
      />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  scroll:  { flex: 1 },
  content: { padding: 16, gap: 14, paddingBottom: 32 },
  screenHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  screenTitle: { color: '#E8EDF2', fontFamily: 'monospace', fontWeight: '800', fontSize: 22 },
  screenSub:   { color: '#6B7F8E', fontFamily: 'monospace', fontSize: 11, marginTop: 2 },
  resetBtn: { paddingHorizontal: 12, paddingVertical: 6, backgroundColor: '#1C2730', borderRadius: 8 },
  resetText: { color: '#5BCFDA', fontFamily: 'monospace', fontSize: 11 },
});

export default NutritionScreen;
