/**
 * ZIMA · BiometricsScreen
 */
import React from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';
import BiometricInput from '../components/BiometricInput';
import InflammationEngine from '../components/InflammationEngine';

const BiometricsScreen = ({ state, onUpdate }) => {
  const { bioHistory, ketones, netCarbsToday } = state;

  const handleSave = async (entry) => {
    const updated = {
      ...state,
      ketones:    entry.ketones,
      weight:     entry.weight,
      bioHistory: [...(bioHistory || []), entry],
    };
    await onUpdate(updated);
  };

  return (
    <ScrollView
      style={styles.scroll}
      contentContainerStyle={styles.content}
      showsVerticalScrollIndicator={false}
    >
      <Text style={styles.screenTitle}>BIOMETRÍA</Text>
      <Text style={styles.screenSub}>Registro de cetonas y peso corporal</Text>

      <BiometricInput
        onSave={handleSave}
        history={bioHistory || []}
      />

      <InflammationEngine
        ketones={ketones}
        netCarbsToday={netCarbsToday}
      />
    </ScrollView>
  );
};

/**
 * ZIMA · NutritionScreen
 */
export const NutritionScreen = ({ state, onUpdate }) => {
  const handleSaveMeal = async (meal) => {
    const updated = {
      ...state,
      meals:         [...(state.meals || []), meal],
      netCarbsToday: (state.netCarbsToday || 0) + meal.netCarbs,
    };
    await onUpdate(updated);
  };

  const handleReset = async () => {
    await onUpdate({ ...state, meals: [], netCarbsToday: 0 });
  };

  return (
    <ScrollView
      style={styles.scroll}
      contentContainerStyle={styles.content}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.screenHeader}>
        <View>
          <Text style={styles.screenTitle}>ESCÁNER</Text>
          <Text style={styles.screenSub}>Calcula carbohidratos netos</Text>
        </View>
        {(state.meals?.length > 0) && (
          <TouchableOpacity onPress={handleReset} style={styles.resetBtn}>
            <Text style={styles.resetText}>↺ Reset</Text>
          </TouchableOpacity>
        )}
      </View>

      {/* Import NutritionScanner inline to avoid circular dependency */}
      <NutritionScannerWrapper
        onSave={handleSaveMeal}
        meals={state.meals || []}
      />
    </ScrollView>
  );
};

// Wrapper lazy import to keep file self-contained
const NutritionScannerWrapper = ({ onSave, meals }) => {
  const NutritionScanner = require('../components/NutritionScanner').default;
  return <NutritionScanner onSave={onSave} meals={meals} />;
};

const { TouchableOpacity } = require('react-native');

/**
 * ZIMA · AvatarScreen
 */
export const AvatarScreen = ({ state, onUpdate }) => {
  const AvatarEvolution = require('../components/AvatarEvolution').default;
  const { calculateAvatarLevel } = require('../engine/SIMEngine');
  const [sets, setSets] = React.useState('');
  const [reps, setReps] = React.useState('');
  const [kg,   setKg]   = React.useState('');

  const avatarLevel = calculateAvatarLevel(
    state.loadVolume || 0,
    state.ketones    || 0,
    state.adherenceDays || 0,
  );

  const addLoad = async () => {
    const vol = (parseFloat(sets)||0) * (parseFloat(reps)||0) * (parseFloat(kg)||0);
    if (vol <= 0) return;
    const newVol = (state.loadVolume || 0) + vol;
    const newAdh = (state.adherenceDays || 0) + (state.ketones >= 0.5 ? 1 : 0);
    await onUpdate({ ...state, loadVolume: newVol, adherenceDays: newAdh });
    setSets(''); setReps(''); setKg('');
  };

  const { TextInput, StyleSheet: S } = require('react-native');

  return (
    <ScrollView style={styles.scroll} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <Text style={styles.screenTitle}>AVATAR</Text>
      <Text style={styles.screenSub}>Evolución según carga y cetosis</Text>

      <View style={styles.avatarBigCard}>
        <AvatarEvolution
          level={avatarLevel}
          ketones={state.ketones || 0}
          loadVolume={state.loadVolume || 0}
          size="lg"
        />
      </View>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>REGISTRAR SERIE</Text>
        <Text style={styles.cardHint}>Series × Reps × Peso = Volumen de carga</Text>
        <View style={styles.inputRow}>
          {[['Series', sets, setSets], ['Reps', reps, setReps], ['kg', kg, setKg]].map(([ph, val, setVal]) => (
            <TextInput
              key={ph}
              style={styles.smallInput}
              value={val}
              onChangeText={setVal}
              keyboardType="decimal-pad"
              placeholder={ph}
              placeholderTextColor="#3A4F5C"
            />
          ))}
        </View>
        <TouchableOpacity style={styles.addBtn} onPress={addLoad} activeOpacity={0.7}>
          <Text style={styles.addBtnText}>+ AGREGAR SERIE</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.statsCard}>
        {[
          ['VOLUMEN TOTAL', `${(state.loadVolume || 0).toLocaleString()} kg·rep`, '#5BCFDA'],
          ['NIVEL AVATAR',  `${avatarLevel} / 4`, '#D4A853'],
          ['DÍAS EN CETOSIS', `${state.adherenceDays || 0}`, '#4EBE8A'],
        ].map(([label, val, color]) => (
          <View key={label} style={styles.statRow}>
            <Text style={styles.statLabel}>{label}</Text>
            <Text style={[styles.statValue, { color }]}>{val}</Text>
          </View>
        ))}
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  scroll:  { flex: 1 },
  content: { padding: 16, gap: 14, paddingBottom: 32 },
  screenHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  screenTitle: { color: '#E8EDF2', fontFamily: 'monospace', fontWeight: '800', fontSize: 22 },
  screenSub:   { color: '#6B7F8E', fontFamily: 'monospace', fontSize: 11, marginTop: 2 },
  resetBtn:    { paddingHorizontal: 10, paddingVertical: 5, backgroundColor: '#1C2730', borderRadius: 6 },
  resetText:   { color: '#5BCFDA', fontFamily: 'monospace', fontSize: 10 },
  avatarBigCard: {
    backgroundColor: '#111820', borderWidth: 1, borderColor: '#1C2730',
    borderRadius: 16, padding: 24, alignItems: 'center',
  },
  card: {
    backgroundColor: '#111820', borderWidth: 1, borderColor: '#1C2730',
    borderRadius: 16, padding: 16, gap: 10,
  },
  cardTitle: { color: '#5BCFDA', fontFamily: 'monospace', fontWeight: '700', fontSize: 12, letterSpacing: 2 },
  cardHint:  { color: '#6B7F8E', fontFamily: 'monospace', fontSize: 10 },
  inputRow:  { flexDirection: 'row', gap: 8 },
  smallInput: {
    flex: 1, backgroundColor: '#1C2730', borderWidth: 1, borderColor: '#2A3640',
    borderRadius: 8, paddingHorizontal: 10, paddingVertical: 10,
    color: '#E8EDF2', fontFamily: 'monospace', fontSize: 15, textAlign: 'center',
  },
  addBtn: {
    backgroundColor: '#5BCFDA22', borderWidth: 1, borderColor: '#5BCFDA66',
    borderRadius: 10, paddingVertical: 12, alignItems: 'center',
  },
  addBtnText: { color: '#5BCFDA', fontFamily: 'monospace', fontWeight: '700', fontSize: 12, letterSpacing: 2 },
  statsCard: {
    backgroundColor: '#111820', borderWidth: 1, borderColor: '#1C2730',
    borderRadius: 16, padding: 16, gap: 12,
  },
  statRow:   { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  statLabel: { color: '#6B7F8E', fontFamily: 'monospace', fontSize: 11 },
  statValue: { fontFamily: 'monospace', fontWeight: '700', fontSize: 16 },
});

export default BiometricsScreen;
