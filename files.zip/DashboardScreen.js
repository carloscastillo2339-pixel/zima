/**
 * ZIMA · DashboardScreen
 * Vista principal del asistente metabólico.
 */
import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, ScrollView, StyleSheet, Animated,
  TouchableOpacity,
} from 'react-native';
import AvatarEvolution from '../components/AvatarEvolution';
import BotanicalRecommendation from '../components/BotanicalRecommendation';
import {
  calculateInflammation,
  getMetabolicStatus,
  generateSIMInsight,
  calculateAvatarLevel,
} from '../engine/SIMEngine';
import { analyzeKetoLevel } from '../utils/ketosisAnalyzer';

const MetricCard = ({ label, value, unit, color, sub }) => (
  <View style={[styles.metricCard, { borderColor: color + '33' }]}>
    <Text style={styles.metricLabel}>{label}</Text>
    <Text style={[styles.metricValue, { color }]}>{value}</Text>
    <Text style={styles.metricUnit}>{unit}</Text>
    {sub && <Text style={[styles.metricSub, { color: color + 'AA' }]}>{sub}</Text>}
  </View>
);

const DashboardScreen = ({ state }) => {
  const { ketones, weight, netCarbsToday, loadVolume, adherenceDays } = state;

  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 600, useNativeDriver: true }).start();
  }, []);

  const inflammationScore = calculateInflammation({
    ketones,
    netCarbsToday,
    stressLevel: 3,
    sleepHours:  7,
  });

  const ketoAnalysis   = analyzeKetoLevel(ketones);
  const metabolicStatus = getMetabolicStatus({ ketones, netCarbsToday, inflammationScore });
  const avatarLevel    = calculateAvatarLevel(loadVolume, ketones, adherenceDays);
  const insights       = generateSIMInsight({ ketones, netCarbsToday, weight, loadVolume, inflammationScore });

  const [insightIdx, setInsightIdx] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setInsightIdx(i => (i + 1) % insights.length), 4000);
    return () => clearInterval(t);
  }, [insights]);

  return (
    <Animated.View style={{ flex: 1, opacity: fadeAnim }}>
      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        {/* Header ZIMA */}
        <View style={styles.header}>
          <View>
            <Text style={styles.brand}>
              <Text style={styles.brandZ}>Z</Text>IMA
            </Text>
            <Text style={styles.brandSub}>MOTOR SIM · ACTIVO</Text>
          </View>
          <AvatarEvolution level={avatarLevel} ketones={ketones} loadVolume={loadVolume} size="sm" />
        </View>

        {/* Status metabólico */}
        <View style={[styles.statusCard, { borderLeftColor: metabolicStatus.color }]}>
          <View style={styles.statusRow}>
            <View style={[styles.statusDot, { backgroundColor: metabolicStatus.color }]} />
            <Text style={[styles.statusLabel, { color: metabolicStatus.color }]}>
              {metabolicStatus.status}
            </Text>
          </View>
          <Text style={styles.statusMessage}>{metabolicStatus.message}</Text>
        </View>

        {/* Grid métricas */}
        <View style={styles.metricsGrid}>
          <MetricCard
            label="CETONAS"
            value={ketones.toFixed(1)}
            unit="mmol/L"
            color={ketoAnalysis.color}
            sub={ketoAnalysis.label}
          />
          <MetricCard
            label="PESO"
            value={weight.toFixed(1)}
            unit="kg"
            color="#E8EDF2"
          />
          <MetricCard
            label="CARBS NETOS"
            value={netCarbsToday.toFixed(0)}
            unit="g hoy"
            color={netCarbsToday <= 25 ? '#4EBE8A' : netCarbsToday <= 50 ? '#D4A853' : '#E05A4E'}
            sub={netCarbsToday <= 25 ? '✓ Óptimo' : 'Reducir'}
          />
          <MetricCard
            label="INFLAMACIÓN"
            value={Math.round(inflammationScore * 100)}
            unit="%"
            color={inflammationScore < 0.3 ? '#4EBE8A' : inflammationScore < 0.6 ? '#D4A853' : '#E05A4E'}
          />
        </View>

        {/* Ticker SIM */}
        <View style={styles.ticker}>
          <View style={styles.tickerDot} />
          <Text style={styles.tickerText} numberOfLines={1}>{insights[insightIdx]}</Text>
        </View>

        {/* Avatar detallado */}
        <View style={styles.avatarCard}>
          <Text style={styles.sectionTitle}>EVOLUCIÓN DEL AVATAR</Text>
          <AvatarEvolution
            level={avatarLevel}
            ketones={ketones}
            loadVolume={loadVolume}
            size="lg"
          />
          <View style={styles.avatarStats}>
            <View style={styles.avatarStat}>
              <Text style={styles.avatarStatLabel}>VOLUMEN</Text>
              <Text style={styles.avatarStatValue}>{loadVolume.toLocaleString()} kg</Text>
            </View>
            <View style={styles.avatarStat}>
              <Text style={styles.avatarStatLabel}>ADHERENCIA</Text>
              <Text style={styles.avatarStatValue}>{adherenceDays} días</Text>
            </View>
            <View style={styles.avatarStat}>
              <Text style={styles.avatarStatLabel}>NIVEL</Text>
              <Text style={[styles.avatarStatValue, { color: '#5BCFDA' }]}>{avatarLevel} / 4</Text>
            </View>
          </View>
        </View>

        {/* Alerta botánica si aplica */}
        {inflammationScore >= 0.3 && (
          <BotanicalRecommendation inflammationScore={inflammationScore} />
        )}
      </ScrollView>
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  scroll:   { flex: 1 },
  content:  { padding: 16, gap: 14, paddingBottom: 32 },
  header: {
    flexDirection:  'row',
    justifyContent: 'space-between',
    alignItems:     'center',
    marginBottom:   4,
  },
  brand:    { fontFamily: 'monospace', fontWeight: '800', fontSize: 32, color: '#E8EDF2', letterSpacing: -0.5 },
  brandZ:   { color: '#5BCFDA' },
  brandSub: { fontSize: 9, color: '#6B7F8E', fontFamily: 'monospace', letterSpacing: 3, marginTop: 2 },
  statusCard: {
    backgroundColor: '#111820',
    borderWidth:      1,
    borderColor:      '#1C2730',
    borderLeftWidth:  3,
    borderRadius:     12,
    padding:          14,
    gap:              6,
  },
  statusRow:    { flexDirection: 'row', alignItems: 'center', gap: 8 },
  statusDot:    { width: 8, height: 8, borderRadius: 4 },
  statusLabel:  { fontFamily: 'monospace', fontWeight: '700', fontSize: 13, letterSpacing: 2 },
  statusMessage: { color: '#E8EDF2', fontFamily: 'monospace', fontSize: 12, lineHeight: 18 },
  metricsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  metricCard: {
    flex: 1, minWidth: '45%',
    backgroundColor: '#111820',
    borderWidth:      1,
    borderRadius:     12,
    padding:          14,
    gap:              3,
    alignItems:       'center',
  },
  metricLabel: { fontSize: 8, color: '#6B7F8E', fontFamily: 'monospace', letterSpacing: 2 },
  metricValue: { fontFamily: 'monospace', fontWeight: '800', fontSize: 28 },
  metricUnit:  { fontSize: 10, color: '#6B7F8E', fontFamily: 'monospace' },
  metricSub:   { fontSize: 10, fontFamily: 'monospace', marginTop: 2 },
  ticker: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    backgroundColor: '#1C2730', borderRadius: 8, padding: '8px 12px',
    paddingHorizontal: 12, paddingVertical: 8,
  },
  tickerDot: {
    width: 6, height: 6, borderRadius: 3, backgroundColor: '#5BCFDA',
  },
  tickerText: { flex: 1, fontSize: 11, color: '#6B7F8E', fontFamily: 'monospace' },
  avatarCard: {
    backgroundColor: '#111820',
    borderWidth:      1,
    borderColor:      '#1C2730',
    borderRadius:     16,
    padding:          20,
    alignItems:       'center',
    gap:              16,
  },
  sectionTitle: {
    color: '#5BCFDA', fontFamily: 'monospace', fontWeight: '700',
    fontSize: 11, letterSpacing: 2, alignSelf: 'flex-start',
  },
  avatarStats: { flexDirection: 'row', width: '100%', justifyContent: 'space-around' },
  avatarStat:  { alignItems: 'center', gap: 4 },
  avatarStatLabel: { fontSize: 8, color: '#6B7F8E', fontFamily: 'monospace', letterSpacing: 1 },
  avatarStatValue: { fontFamily: 'monospace', fontWeight: '700', fontSize: 14, color: '#E8EDF2' },
});

export default DashboardScreen;
