/**
 * ZIMA · BiometricInput
 * Registro de cetonas y peso con historial.
 */
import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity,
  ScrollView, StyleSheet, Alert,
} from 'react-native';
import { analyzeKetoLevel } from '../utils/ketosisAnalyzer';

const BiometricInput = ({ onSave, history = [] }) => {
  const [ketones, setKetones]   = useState('');
  const [weight,  setWeight]    = useState('');
  const [notes,   setNotes]     = useState('');
  const [loading, setLoading]   = useState(false);

  const handleSave = async () => {
    const ketoVal   = parseFloat(ketones);
    const weightVal = parseFloat(weight);

    if (isNaN(ketoVal) || ketoVal < 0 || ketoVal > 15) {
      Alert.alert('ZIMA', 'Ingresa un valor de cetonas válido (0–15 mmol/L)');
      return;
    }
    if (isNaN(weightVal) || weightVal < 30 || weightVal > 300) {
      Alert.alert('ZIMA', 'Ingresa un peso válido (30–300 kg)');
      return;
    }

    setLoading(true);
    const entry = {
      id:        Date.now().toString(),
      ketones:   ketoVal,
      weight:    weightVal,
      notes:     notes.trim(),
      timestamp: Date.now(),
      date:      new Date().toLocaleDateString('es-ES'),
      time:      new Date().toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' }),
    };

    await onSave?.(entry);
    setKetones('');
    setWeight('');
    setNotes('');
    setLoading(false);
  };

  const ketoAnalysis = ketones ? analyzeKetoLevel(parseFloat(ketones) || 0) : null;

  return (
    <View style={styles.container}>
      {/* Formulario */}
      <View style={styles.card}>
        <Text style={styles.cardTitle}>REGISTRO BIOMÉTRICO</Text>

        <View style={styles.inputRow}>
          {/* Cetonas */}
          <View style={styles.inputGroup}>
            <Text style={styles.label}>CETONAS (mmol/L)</Text>
            <TextInput
              style={[styles.input, ketoAnalysis && { borderColor: ketoAnalysis.color + '88' }]}
              value={ketones}
              onChangeText={setKetones}
              keyboardType="decimal-pad"
              placeholder="0.0"
              placeholderTextColor="#6B7F8E"
              maxLength={5}
            />
            {ketoAnalysis && (
              <Text style={[styles.zoneLabel, { color: ketoAnalysis.color }]}>
                {ketoAnalysis.label}
              </Text>
            )}
          </View>

          {/* Peso */}
          <View style={styles.inputGroup}>
            <Text style={styles.label}>PESO (kg)</Text>
            <TextInput
              style={styles.input}
              value={weight}
              onChangeText={setWeight}
              keyboardType="decimal-pad"
              placeholder="00.0"
              placeholderTextColor="#6B7F8E"
              maxLength={5}
            />
            <Text style={styles.zoneLabel}> </Text>
          </View>
        </View>

        {/* Notas opcionales */}
        <View style={styles.notesGroup}>
          <Text style={styles.label}>NOTAS (opcional)</Text>
          <TextInput
            style={[styles.input, styles.notesInput]}
            value={notes}
            onChangeText={setNotes}
            placeholder="Ej: ayuno 18h, post-entrenamiento..."
            placeholderTextColor="#6B7F8E"
            multiline
            maxLength={120}
          />
        </View>

        {/* Análisis rápido */}
        {ketoAnalysis && (
          <View style={[styles.analysisBox, { borderColor: ketoAnalysis.color + '44' }]}>
            <Text style={[styles.analysisText, { color: ketoAnalysis.color }]}>
              {ketoAnalysis.recommendation}
            </Text>
          </View>
        )}

        <TouchableOpacity
          style={[styles.saveBtn, loading && styles.saveBtnDisabled]}
          onPress={handleSave}
          disabled={loading}
          activeOpacity={0.7}
        >
          <Text style={styles.saveBtnText}>
            {loading ? 'GUARDANDO...' : '+ REGISTRAR'}
          </Text>
        </TouchableOpacity>
      </View>

      {/* Historial */}
      {history.length > 0 && (
        <View style={styles.card}>
          <Text style={styles.cardTitle}>HISTORIAL RECIENTE</Text>
          <ScrollView style={styles.historyScroll} nestedScrollEnabled>
            {[...history].reverse().slice(0, 10).map((entry) => {
              const analysis = analyzeKetoLevel(entry.ketones);
              return (
                <View key={entry.id} style={styles.historyRow}>
                  <View style={[styles.ketoIndicator, { backgroundColor: analysis.color + '33', borderColor: analysis.color + '55' }]}>
                    <Text style={[styles.ketoValue, { color: analysis.color }]}>
                      {entry.ketones.toFixed(1)}
                    </Text>
                    <Text style={styles.ketoUnit}>mmol</Text>
                  </View>
                  <View style={styles.historyMeta}>
                    <Text style={styles.historyWeight}>{entry.weight} kg</Text>
                    <Text style={styles.historyDate}>{entry.date} · {entry.time}</Text>
                    {entry.notes ? <Text style={styles.historyNotes}>{entry.notes}</Text> : null}
                  </View>
                  <Text style={[styles.historyZone, { color: analysis.color }]}>
                    {analysis.label}
                  </Text>
                </View>
              );
            })}
          </ScrollView>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: { gap: 12 },
  card: {
    backgroundColor: '#111820',
    borderWidth:      1,
    borderColor:      '#1C2730',
    borderRadius:     16,
    padding:          16,
    gap:              12,
  },
  cardTitle: {
    color:        '#5BCFDA',
    fontFamily:   'monospace',
    fontWeight:   '700',
    fontSize:     12,
    letterSpacing: 2,
    paddingBottom: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#1C2730',
  },
  inputRow: {
    flexDirection: 'row',
    gap: 12,
  },
  inputGroup: {
    flex: 1,
    gap:  4,
  },
  notesGroup: { gap: 4 },
  label: {
    fontSize:     9,
    color:        '#6B7F8E',
    fontFamily:   'monospace',
    letterSpacing: 1,
  },
  input: {
    backgroundColor: '#1C2730',
    borderWidth:     1,
    borderColor:     '#2A3640',
    borderRadius:    8,
    paddingHorizontal: 12,
    paddingVertical:   10,
    color:           '#E8EDF2',
    fontFamily:      'monospace',
    fontSize:        16,
  },
  notesInput: {
    height:     64,
    textAlignVertical: 'top',
    fontSize:   12,
  },
  zoneLabel: {
    fontSize:   10,
    fontFamily: 'monospace',
    color:      '#6B7F8E',
    minHeight:  14,
  },
  analysisBox: {
    padding:      12,
    borderWidth:   1,
    borderRadius:  8,
    backgroundColor: '#0D1219',
  },
  analysisText: {
    fontSize:   12,
    fontFamily: 'monospace',
    lineHeight: 18,
  },
  saveBtn: {
    backgroundColor: '#5BCFDA22',
    borderWidth:      1,
    borderColor:      '#5BCFDA66',
    borderRadius:     10,
    paddingVertical:  12,
    alignItems:       'center',
  },
  saveBtnDisabled: {
    opacity: 0.5,
  },
  saveBtnText: {
    color:        '#5BCFDA',
    fontFamily:   'monospace',
    fontWeight:   '700',
    fontSize:     13,
    letterSpacing: 2,
  },
  historyScroll: { maxHeight: 280 },
  historyRow: {
    flexDirection:  'row',
    alignItems:     'center',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#1C2730',
    gap:            12,
  },
  ketoIndicator: {
    width:         52,
    height:        52,
    borderRadius:  10,
    borderWidth:    1,
    alignItems:    'center',
    justifyContent: 'center',
  },
  ketoValue: {
    fontFamily: 'monospace',
    fontWeight: '700',
    fontSize:   16,
  },
  ketoUnit: {
    fontSize:   9,
    color:      '#6B7F8E',
    fontFamily: 'monospace',
  },
  historyMeta: {
    flex: 1,
    gap:  2,
  },
  historyWeight: {
    color:      '#E8EDF2',
    fontFamily: 'monospace',
    fontWeight: '600',
    fontSize:   14,
  },
  historyDate: {
    color:      '#6B7F8E',
    fontFamily: 'monospace',
    fontSize:   10,
  },
  historyNotes: {
    color:      '#6B7F8E',
    fontFamily: 'monospace',
    fontSize:   10,
    fontStyle:  'italic',
  },
  historyZone: {
    fontSize:   10,
    fontFamily: 'monospace',
    fontWeight: '600',
  },
});

export default BiometricInput;
