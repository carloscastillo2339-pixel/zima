/**
 * ZIMA · AvatarEvolution
 * Avatar visual que evoluciona según carga,
 * cetonas y adherencia keto.
 */
import React, { useEffect, useRef } from 'react';
import { View, Text, Animated, StyleSheet } from 'react-native';
import { COLORS, FONTS, SPACING } from '../theme';

export const AVATAR_STATES = [
  {
    level:   0,
    id:      'SEED',
    label:   'Semilla',
    emoji:   '🌱',
    description: 'Inicio del viaje metabólico.',
    minLoad: 0,
    color:   '#6B7F8E',
  },
  {
    level:   1,
    id:      'SPROUT',
    label:   'Brote',
    emoji:   '🌿',
    description: 'Adaptación cetogénica en marcha.',
    minLoad: 500,
    color:   '#4EBE8A',
  },
  {
    level:   2,
    id:      'TREE',
    label:   'Árbol',
    emoji:   '🌳',
    description: 'Raíces metabólicas establecidas.',
    minLoad: 2000,
    color:   '#5BCFDA',
  },
  {
    level:   3,
    id:      'WARRIOR',
    label:   'Guerrero',
    emoji:   '⚔️',
    description: 'Cuerpo optimizado. Mente afilada.',
    minLoad: 5000,
    color:   '#D4A853',
  },
  {
    level:   4,
    id:      'MASTER',
    label:   'Maestro',
    emoji:   '🔮',
    description: 'Maestría metabólica total.',
    minLoad: 10000,
    color:   '#5BCFDA',
  },
];

const AvatarEvolution = ({ level = 0, ketones = 0, loadVolume = 0, size = 'md' }) => {
  const pulseAnim  = useRef(new Animated.Value(1)).current;
  const floatAnim  = useRef(new Animated.Value(0)).current;

  const avatarData = AVATAR_STATES[Math.min(level, 4)];
  const nextData   = AVATAR_STATES[Math.min(level + 1, 4)];

  const THRESHOLDS = [0, 500, 2000, 5000, 10000];
  const progressPct = level >= 4
    ? 100
    : Math.round(
        ((loadVolume - THRESHOLDS[level]) /
         (THRESHOLDS[level + 1] - THRESHOLDS[level])) * 100
      );

  const sizes = { sm: 64, md: 88, lg: 112 };
  const avatarSize = sizes[size] || sizes.md;

  // Pulso según intensidad cetogénica
  useEffect(() => {
    const pulse = Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, { toValue: ketones >= 1.5 ? 1.08 : 1.03, duration: 1200, useNativeDriver: true }),
        Animated.timing(pulseAnim, { toValue: 1,                             duration: 1200, useNativeDriver: true }),
      ])
    );
    pulse.start();
    return () => pulse.stop();
  }, [ketones]);

  // Flotación suave
  useEffect(() => {
    const float = Animated.loop(
      Animated.sequence([
        Animated.timing(floatAnim, { toValue: -6, duration: 1800, useNativeDriver: true }),
        Animated.timing(floatAnim, { toValue:  0, duration: 1800, useNativeDriver: true }),
      ])
    );
    float.start();
    return () => float.stop();
  }, []);

  return (
    <View style={styles.container}>
      {/* Avatar animado */}
      <Animated.View
        style={[
          styles.avatarCircle,
          {
            width:       avatarSize,
            height:      avatarSize,
            borderRadius: avatarSize / 2,
            borderColor: avatarData.color,
            shadowColor: avatarData.color,
            transform:   [{ scale: pulseAnim }, { translateY: floatAnim }],
          },
        ]}
      >
        <Text style={{ fontSize: avatarSize * 0.42 }}>{avatarData.emoji}</Text>
      </Animated.View>

      {/* Label y nivel */}
      <View style={styles.labelRow}>
        <Text style={[styles.levelLabel, { color: avatarData.color }]}>
          {avatarData.label.toUpperCase()}
        </Text>
        <View style={[styles.levelBadge, { backgroundColor: avatarData.color + '22', borderColor: avatarData.color + '55' }]}>
          <Text style={[styles.levelNum, { color: avatarData.color }]}>LVL {level}</Text>
        </View>
      </View>

      <Text style={styles.description}>{avatarData.description}</Text>

      {/* Barra de progreso hacia siguiente nivel */}
      {level < 4 && (
        <View style={styles.progressContainer}>
          <View style={styles.progressRow}>
            <Text style={styles.progressLabel}>→ {nextData.label}</Text>
            <Text style={[styles.progressPct, { color: avatarData.color }]}>{Math.max(0, Math.min(progressPct, 100))}%</Text>
          </View>
          <View style={styles.progressTrack}>
            <View style={[
              styles.progressFill,
              {
                width:           `${Math.max(0, Math.min(progressPct, 100))}%`,
                backgroundColor: avatarData.color,
              },
            ]} />
          </View>
        </View>
      )}

      {level >= 4 && (
        <Text style={[styles.masterLabel, { color: avatarData.color }]}>
          ✦ MAESTRÍA METABÓLICA ALCANZADA ✦
        </Text>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    gap: 8,
  },
  avatarCircle: {
    borderWidth:     2,
    backgroundColor: '#111820',
    alignItems:      'center',
    justifyContent:  'center',
    shadowOffset:    { width: 0, height: 0 },
    shadowOpacity:   0.6,
    shadowRadius:    12,
    elevation:       8,
  },
  labelRow: {
    flexDirection: 'row',
    alignItems:    'center',
    gap:           8,
    marginTop:     4,
  },
  levelLabel: {
    fontFamily: 'monospace',
    fontWeight: '700',
    fontSize:   13,
    letterSpacing: 2,
  },
  levelBadge: {
    paddingHorizontal: 8,
    paddingVertical:   2,
    borderRadius:      6,
    borderWidth:       1,
  },
  levelNum: {
    fontSize:   10,
    fontWeight: '600',
    fontFamily: 'monospace',
  },
  description: {
    fontSize:   12,
    color:      '#6B7F8E',
    fontFamily: 'monospace',
    textAlign:  'center',
  },
  progressContainer: {
    width: '100%',
    gap:   4,
    marginTop: 4,
  },
  progressRow: {
    flexDirection:  'row',
    justifyContent: 'space-between',
  },
  progressLabel: {
    fontSize:   10,
    color:      '#6B7F8E',
    fontFamily: 'monospace',
  },
  progressPct: {
    fontSize:   10,
    fontWeight: '700',
    fontFamily: 'monospace',
  },
  progressTrack: {
    height:          5,
    backgroundColor: '#1C2730',
    borderRadius:    3,
    overflow:        'hidden',
  },
  progressFill: {
    height:      '100%',
    borderRadius: 3,
  },
  masterLabel: {
    fontSize:     10,
    fontWeight:   '700',
    fontFamily:   'monospace',
    letterSpacing: 1,
    marginTop:    4,
  },
});

export default AvatarEvolution;
