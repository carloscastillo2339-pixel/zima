/**
 * ZIMA · Calculador de Carbohidratos Netos
 * ─────────────────────────────────────────
 * Fórmula: Carbs Netos = Total − Fibra − (Polialcoholes × 0.5)
 *
 * Los polialcoholes tienen impacto glucémico parcial (~50%).
 * El eritritol tiene factor 0 (se puede excluir completamente).
 */

export const POLYOL_FACTORS = {
  generic:    0.50,  // Polialcohol genérico
  maltitol:   0.50,  // Impacto glucémico moderado
  xylitol:    0.30,  // Menor impacto
  sorbitol:   0.50,
  erythritol: 0.00,  // No eleva glucosa
  isomalt:    0.50,
};

/**
 * Calcula carbohidratos netos
 * @param {Object} macros
 * @param {number} macros.totalCarbs        - g carbohidratos totales
 * @param {number} macros.fiber             - g fibra dietética
 * @param {number} macros.polyols           - g polialcoholes (genérico)
 * @param {number} macros.erythritol        - g eritritol (factor 0)
 * @param {string} macros.polyolType        - tipo de polialcohol
 * @returns {Object} resultado detallado
 */
export const calculateNetCarbs = ({
  totalCarbs   = 0,
  fiber        = 0,
  polyols      = 0,
  erythritol   = 0,
  polyolType   = 'generic',
}) => {
  const factor         = POLYOL_FACTORS[polyolType] ?? POLYOL_FACTORS.generic;
  const fiberReduction = fiber;
  const polyolReduction = polyols * factor;
  const erythritolReduction = erythritol; // factor 0 = resta completo

  const netCarbs = Math.max(
    0,
    totalCarbs - fiberReduction - polyolReduction - erythritolReduction
  );

  return {
    netCarbs:           parseFloat(netCarbs.toFixed(1)),
    totalCarbs:         parseFloat(totalCarbs),
    fiberReduction:     parseFloat(fiberReduction.toFixed(1)),
    polyolReduction:    parseFloat(polyolReduction.toFixed(1)),
    erythritolReduction:parseFloat(erythritolReduction.toFixed(1)),
    breakdown: {
      fromFiber:       fiberReduction,
      fromPolyols:     polyolReduction,
      fromErythritol:  erythritolReduction,
      totalReduction:  fiberReduction + polyolReduction + erythritolReduction,
    },
    ketoImpact: netCarbs <= 5   ? 'NINGUNO'
              : netCarbs <= 15  ? 'MÍNIMO'
              : netCarbs <= 25  ? 'MODERADO'
              : netCarbs <= 50  ? 'ALTO'
              : 'CRÍTICO',
  };
};

/**
 * Suma los carbs netos de múltiples comidas del día
 */
export const sumDailyNetCarbs = (meals = []) =>
  meals.reduce((acc, meal) => acc + (meal.netCarbs || 0), 0);

/**
 * Valida si un alimento es keto-compatible
 */
export const isKetoFriendly = (netCarbs, servings = 1) => {
  const total = netCarbs * servings;
  return {
    friendly:  total <= 5,
    moderate:  total > 5 && total <= 10,
    avoid:     total > 10,
    message:   total <= 5  ? '✓ Keto-compatible'
             : total <= 10 ? '⚠ Consumo moderado'
             : '✗ Evitar en cetosis estricta',
  };
};
