/**
 * ZIMA · InflammationEngine
 * Visualiza el estado inflamatorio y permite
 * ajustar factores contextuales.
 */
import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { calculateInflammation } from '../engine/SIMEngine';

const ScoreBar = ({ label, value, max, color }) => {
  const pct = Math.min((value / max) * 100, 100);
  return (
    <View style={styles.scoreRow}>
      <Text style={styles.scoreLabel}>{label}</Text>
      <View style={styles.scoreTrack}>
        <View style={[styles.scoreFill, { width: `${pct}%`, backgroundColor: color }]} />
      </View>
      <Text style={[styles.scoreValue, { color }]}>{value}/{max}</Text>
    </View>
  );
};

const InflammationEngine = ({ ketones = 1.0, netCarbsToday = 25, onScoreChange }) => {
  const [stressLevel, setStressLevel] = useState(3);
  const [sleepHours,  setSleepHours]  = useState(7);
  const [showFactors, setShowFactors] = useState(false);

  const score   = calculateInflammation({ ketones, netCarbsToday, stressLevel, sleepHours });
  const pct     = Math.round(score * 100);
  const color   = pct < 30 ? '#4EBE8A' : pct < 60 ? '#D4A853' : '#E05A4E';
  const status  = pct < 30 ? 'BAJO' : pct < 60 ? 'MODERADO' : 'ELEVADO';

  React.useEffect(() => { onScoreChange?.(score); }, [score]);

  const steps = (val, setter, min, max, step) => ({
    inc: () => setter(v => Math.min(v + step, max)),
    dec: () => setter(v => Math.max(v - step, min)),
    val,
  });

  const stress = steps(stressLevel, setStressLevel, 0, 10, 1);
  const sleep  = steps(sleepHours, setSleepHours, 3, 12, 0.5);

  // Gauge SVG via View geometry
  const gaugeAngle = (score) => score * 180;

  return (
    <View style={styles.card}>
      <Text style={styles.cardTitle}>MOTOR INFLAMATORIO SIM</Text>

      {/* Gauge visual */}
      <View style={styles.gaugeContainer}>
        {/* Barra semicircular simulada con View */}
        <View style={styles.gaugeBg}>
          <View style={[styles.gaugeFill, {
            width: `${pct}%`,
            backgroundColor: color,
          }]} />
        </View>
        <View style={styles.gaugeCenter}>
          <Text style={[styles.gaugeScore, { color }]}>{pct}%</Text>
          <Text style={[styles.gaugeStatus, { color }]}>{status}</Text>
        </View>
      </View>

      {/* Factores contribuyentes */}
      <View style={styles.factorsGrid}>
        <FactorChip
          label="CETONAS"
          value={`${ketones.toFixed(1)} mmol`}
          impact={ketones >= 1.5 ? 'bajo' : 'alto'}
        />
        <FactorChip
          label="CARBS NETOS"
          value={`${netCarbsToday.toFixed(0)}g`}
          impact={netCarbsToday <= 25 ? 'bajo' : 'alto'}
        />
        <FactorChip
          label="ESTRÉS"
          value={`${stressLevel}/10`}
          impact={stressLevel <= 4 ? 'bajo' : 'alto'}
        />
        <FactorChip
          label="SUEÑO"
          value={`${sleepHours}h`}
          impact={sleepHours >= 7 ? 'bajo' : 'alto'}
        />
      </View>

      {/* Controles de estrés y sueño */}
      <TouchableOpacity
        onPress={() => setShowFactors(!showFactors)}
        style={styles.toggle}
        activeOpacity={0.7}
      >
        <Text style={styles.toggleText}>
          {showFactors ? '▲' : '▼'} Ajustar factores contextuales
        </Text>
      </TouchableOpacity>

      {showFactors && (
        <View style={styles.controlsSection}>
          <FactorStepper
            label="NIVEL DE ESTRÉS"
            value={stressLevel}
            unit="/10"
            onDec={stress.dec}
            onInc={stress.inc}
          />
          <FactorStepper
            label="HORAS DE SUEÑO"
            value={sleepHours}
            unit="h"
            onDec={sleep.dec}
            onInc={sleep.inc}
          />
        </View>
      )}

      {/* Indicador de riesgo detallado */}
      <View style={[styles.riskBox, { borderColor: color + '44' }]}>
        <Text style={[styles.riskTitle, { color }]}>ANÁLISIS SIM</Text>
        <Text style={styles.riskText}>
          {pct < 30
            ? 'Sistema en homeostasis. Marcadores inflamatorios dentro de rango óptimo. Mantén protocolo.'
            : pct < 60
            ? `Inflamación moderada. ${netCarbsToday > 25 ? 'Reduce carbohidratos netos. ' : ''}${stressLevel > 5 ? 'Gestiona el estrés. ' : ''}${sleepHours < 7 ? 'Prioriza 7–9h de sueño.' : ''}`
            : 'Inflamación sistémica elevada. Activa protocolo botánico de urgencia. Revisa todos los factores.'}
        </Text>
      </View>
    </View>
  );
};

const FactorChip = ({ label, value, impact }) => (
  <View style={[styles.chip, { borderColor: impact === 'bajo' ? '#4EBE8A33' : '#E05A4E33' }]}>
    <Text style={styles.chipLabel}>{label}</Text>
    <Text style={[styles.chipValue, { color: impact === 'bajo' ? '#4EBE8A' : '#E05A4E' }]}>{value}</Text>
  </View>
);

const FactorStepper = ({ label, value, unit, onDec, onInc }) => (
  <View style={styles.stepperRow}>
    <Text style={styles.stepperLabel}>{label}</Text>
    <View style={styles.stepperControls}>
      <TouchableOpacity style={styles.stepBtn} onPress={onDec} activeOpacity={0.7}>
        <Text style={styles.stepBtnText}>−</Text>
      </TouchableOpacity>
      <Text style={styles.stepValue}>{value}{unit}</Text>
      <TouchableOpacity style={styles.stepBtn} onPress={onInc} activeOpacity={0.7}>
        <Text style={styles.stepBtnText}>+</Text>
      </TouchableOpacity>
    </View>
  </View>
);

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#111820', borderWidth: 1, borderColor: '#1C2730',
    borderRadius: 16, padding: 16, gap: 14,
  },
  cardTitle: {
    color: '#5BCFDA', fontFamily: 'monospace', fontWeight: '700',
    fontSize: 12, letterSpacing: 2,
    paddingBottom: 10, borderBottomWidth: 1, borderBottomColor: '#1C2730',
  },
  gaugeContainer: { alignItems: 'center', gap: 10 },
  gaugeBg: {
    width: '100%', height: 12, backgroundColor: '#1C2730',
    borderRadius: 6, overflow: 'hidden',
  },
  gaugeFill: { height: '100%', borderRadius: 6, transition: 'width 0.4s' },
  gaugeCenter: { flexDirection: 'row', alignItems: 'baseline', gap: 8 },
  gaugeScore:  { fontFamily: 'monospace', fontWeight: '800', fontSize: 36 },
  gaugeStatus: { fontFamily: 'monospace', fontWeight: '700', fontSize: 14, letterSpacing: 2 },
  factorsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chip: {
    flex: 1, minWidth: '45%', backgroundColor: '#0D1219',
    borderWidth: 1, borderRadius: 10, padding: 10, gap: 4,
  },
  chipLabel: { fontSize: 9, color: '#6B7F8E', fontFamily: 'monospace', letterSpacing: 1 },
  chipValue: { fontFamily: 'monospace', fontWeight: '700', fontSize: 14 },
  toggle:     { paddingVertical: 6 },
  toggleText: { color: '#5BCFDA', fontFamily: 'monospace', fontSize: 11, letterSpacing: 1 },
  controlsSection: { gap: 10 },
  stepperRow: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingVertical: 6,
  },
  stepperLabel:    { fontSize: 11, color: '#6B7F8E', fontFamily: 'monospace' },
  stepperControls: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  stepBtn: {
    width: 32, height: 32, backgroundColor: '#1C2730',
    borderRadius: 6, alignItems: 'center', justifyContent: 'center',
  },
  stepBtnText: { color: '#5BCFDA', fontSize: 18, fontFamily: 'monospace' },
  stepValue:   { color: '#E8EDF2', fontFamily: 'monospace', fontWeight: '700', fontSize: 16, minWidth: 48, textAlign: 'center' },
  scoreRow:    { flexDirection: 'row', alignItems: 'center', gap: 8 },
  scoreLabel:  { fontSize: 10, color: '#6B7F8E', fontFamily: 'monospace', width: 80 },
  scoreTrack:  { flex: 1, height: 4, backgroundColor: '#1C2730', borderRadius: 2, overflow: 'hidden' },
  scoreFill:   { height: '100%', borderRadius: 2 },
  scoreValue:  { fontSize: 10, fontFamily: 'monospace', width: 32, textAlign: 'right' },
  riskBox: {
    padding: 12, borderWidth: 1, borderRadius: 10,
    backgroundColor: '#0D1219', gap: 6,
  },
  riskTitle: { fontSize: 10, fontFamily: 'monospace', fontWeight: '700', letterSpacing: 2 },
  riskText:  { fontSize: 12, color: '#6B7F8E', fontFamily: 'monospace', lineHeight: 18 },
});

export default InflammationEngine;
