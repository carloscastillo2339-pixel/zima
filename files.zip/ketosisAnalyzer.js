/**
 * ZIMA · Analizador de Cetosis
 * ─────────────────────────────
 * Interpreta valores de cetonas sanguíneas
 * y genera recomendaciones de protocolo.
 */

export const KETOSIS_ZONES = {
  POST_ABSORPTIVE: { min: 0.1,  max: 0.5,  label: 'Post-absortiva',  color: '#6B7F8E' },
  NUTRITIONAL:     { min: 0.5,  max: 1.5,  label: 'Nutricional',     color: '#D4A853' },
  OPTIMAL:         { min: 1.5,  max: 3.0,  label: 'Óptima',          color: '#5BCFDA' },
  FASTING:         { min: 3.0,  max: 5.0,  label: 'Ayuno profundo',  color: '#D4A853' },
  MEDICAL:         { min: 5.0,  max: 10.0, label: 'Nivel médico',    color: '#E05A4E' },
};

/**
 * Analiza el valor de cetonas y devuelve contexto completo
 */
export const analyzeKetoLevel = (mmolL) => {
  const zone = Object.entries(KETOSIS_ZONES)
    .find(([, z]) => mmolL >= z.min && mmolL < z.max);

  const zoneKey  = zone?.[0] ?? (mmolL >= 10 ? 'MEDICAL' : 'NONE');
  const zoneData = zone?.[1] ?? { label: 'Sin cetosis', color: '#6B7F8E' };

  const brainPerformance = mmolL >= 1.5 && mmolL <= 3.0
    ? 'PEAK — Cetonas alimentan neuronas con máxima eficiencia.'
    : mmolL >= 0.5
    ? 'PARCIAL — Transición glucosa/cetonas en curso.'
    : 'GLUCOLÍTICO — Sin combustible cetogénico activo.';

  const recommendation = mmolL < 0.5
    ? 'Reduce carbohidratos a < 20g. Considera ayuno 16:8 o ejercicio en ayunas.'
    : mmolL < 1.5
    ? 'Cetosis iniciada. Mantén proteína moderada y carbohidratos < 25g.'
    : mmolL < 3.0
    ? 'Cetosis óptima. Mantén protocolo. Monitorea cada 24–48h.'
    : mmolL < 5.0
    ? 'Cetosis de ayuno. Hidratación y electrolitos prioritarios.'
    : '⚠ Nivel elevado. Descarta cetoacidosis si eres diabético. Consultar médico.';

  return {
    mmolL,
    zone:       zoneKey,
    label:      zoneData.label,
    color:      zoneData.color,
    brainPerformance,
    recommendation,
    percentage: Math.min((mmolL / 5) * 100, 100),
    isOptimal:  mmolL >= 1.5 && mmolL < 3.0,
  };
};

/**
 * Calcula tendencia comparando historial
 * @param {Array} history - Array de { value, timestamp }
 */
export const calculateTrend = (history = []) => {
  if (history.length < 2) return { trend: 'neutral', delta: 0, message: 'Datos insuficientes' };

  const sorted = [...history].sort((a, b) => a.timestamp - b.timestamp);
  const last   = sorted[sorted.length - 1].value;
  const prev   = sorted[sorted.length - 2].value;
  const delta  = last - prev;

  return {
    trend:   delta > 0.2 ? 'up' : delta < -0.2 ? 'down' : 'stable',
    delta:   parseFloat(delta.toFixed(2)),
    message: delta > 0.2 ? `↑ +${delta.toFixed(2)} mmol/L respecto a medición anterior`
           : delta < -0.2 ? `↓ ${delta.toFixed(2)} mmol/L respecto a medición anterior`
           : '→ Cetosis estable',
  };
};

/**
 * Adherencia keto: días consecutivos en cetosis (≥ 0.5 mmol/L)
 */
export const calculateAdherence = (history = []) => {
  if (!history.length) return { days: 0, streak: 0, percentage: 0 };

  const sorted   = [...history].sort((a, b) => b.timestamp - a.timestamp);
  let streak     = 0;
  let ketoCount  = 0;

  for (const entry of sorted) {
    if (entry.value >= 0.5) {
      streak++;
      ketoCount++;
    } else {
      if (streak === sorted.indexOf(entry)) break; // rompe racha
    }
  }

  return {
    days:       history.length,
    streak,
    inKeto:     ketoCount,
    percentage: Math.round((ketoCount / history.length) * 100),
    label:      streak >= 30 ? '🔥 Racha épica'
              : streak >= 14 ? '⚡ Adaptado'
              : streak >= 7  ? '✓ En curso'
              : '🌱 Iniciando',
  };
};
