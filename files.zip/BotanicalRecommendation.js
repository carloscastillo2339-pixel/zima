/**
 * ZIMA · BotanicalRecommendation
 * Muestra el protocolo botánico basado en inflamación.
 */
import React, { useState } from 'react';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet } from 'react-native';
import { getBotanicalProtocol } from '../engine/SIMEngine';

const UrgencyBadge = ({ level, color }) => {
  const labels = { 1: 'PREVENTIVO', 2: 'ACTIVO', 3: 'CRÍTICO' };
  const icons  = { 1: '🌿', 2: '⚡', 3: '⚠️' };
  return (
    <View style={[styles.badge, { backgroundColor: color + '22', borderColor: color + '55' }]}>
      <Text style={styles.badgeIcon}>{icons[level]}</Text>
      <Text style={[styles.badgeText, { color }]}>{labels[level]}</Text>
    </View>
  );
};

const HerbCard = ({ herb, index }) => (
  <View style={styles.herbCard}>
    <View style={styles.herbIndex}>
      <Text style={styles.herbIndexText}>{String(index + 1).padStart(2, '0')}</Text>
    </View>
    <View style={styles.herbInfo}>
      <Text style={styles.herbName}>{herb.name}</Text>
      <View style={styles.herbMeta}>
        <View style={styles.herbTag}>
          <Text style={styles.herbTagText}>DOSIS: {herb.dose}</Text>
        </View>
        <View style={[styles.herbTag, { backgroundColor: '#5BCFDA11', borderColor: '#5BCFDA33' }]}>
          <Text style={[styles.herbTagText, { color: '#5BCFDA' }]}>{herb.timing}</Text>
        </View>
      </View>
    </View>
  </View>
);

const BotanicalRecommendation = ({ inflammationScore = 0 }) => {
  const [expanded, setExpanded] = useState(true);
  const protocol = getBotanicalProtocol(inflammationScore);
  const pct      = Math.round(inflammationScore * 100);

  if (!protocol) {
    return (
      <View style={styles.card}>
        <View style={styles.cardHeader}>
          <Text style={styles.cardTitle}>BOTÁNICA FUNCIONAL</Text>
          <Text style={styles.cardIcon}>🌿</Text>
        </View>
        <View style={styles.okBox}>
          <Text style={styles.okIcon}>✓</Text>
          <View>
            <Text style={styles.okTitle}>Sin intervención necesaria</Text>
            <Text style={styles.okSub}>
              Marcadores inflamatorios en rango óptimo ({pct}%). Mantén protocolo cetogénico.
            </Text>
          </View>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.card}>
      <TouchableOpacity
        style={styles.cardHeader}
        onPress={() => setExpanded(!expanded)}
        activeOpacity={0.7}
      >
        <Text style={styles.cardTitle}>BOTÁNICA FUNCIONAL</Text>
        <View style={styles.headerRight}>
          <UrgencyBadge level={protocol.urgency} color={protocol.color} />
          <Text style={[styles.expandChevron, { color: '#6B7F8E' }]}>
            {expanded ? '▲' : '▼'}
          </Text>
        </View>
      </TouchableOpacity>

      {expanded && (
        <View style={styles.body}>
          {/* Indicador de inflamación */}
          <View style={styles.scoreRow}>
            <Text style={styles.scoreText}>RIESGO INFLAMATORIO</Text>
            <Text style={[styles.scoreNum, { color: protocol.color }]}>{pct}%</Text>
          </View>
          <View style={styles.scoreTrack}>
            <View style={[styles.scoreFill, { width: `${pct}%`, backgroundColor: protocol.color }]} />
          </View>

          {/* Hierbas */}
          <Text style={styles.sectionLabel}>PROTOCOLO RECOMENDADO</Text>
          {protocol.herbs.map((herb, i) => (
            <HerbCard key={i} herb={herb} index={i} />
          ))}

          {/* Protocolo conductual */}
          <View style={[styles.protocolBox, { borderColor: protocol.color + '44' }]}>
            <Text style={styles.protocolLabel}>PROTOCOLO CONDUCTUAL</Text>
            <Text style={[styles.protocolText, { color: protocol.urgency === 3 ? protocol.color : '#E8EDF2' }]}>
              {protocol.protocol}
            </Text>
          </View>

          {/* Disclaimer */}
          <Text style={styles.disclaimer}>
            * Información educativa. No reemplaza diagnóstico médico. Consulta a un profesional de salud.
          </Text>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#111820', borderWidth: 1, borderColor: '#1C2730',
    borderRadius: 16, padding: 16, gap: 14,
  },
  cardHeader: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingBottom: 10, borderBottomWidth: 1, borderBottomColor: '#1C2730',
  },
  cardTitle: { color: '#5BCFDA', fontFamily: 'monospace', fontWeight: '700', fontSize: 12, letterSpacing: 2 },
  cardIcon:  { fontSize: 18 },
  headerRight: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  expandChevron: { fontSize: 12 },
  badge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6, borderWidth: 1,
  },
  badgeIcon: { fontSize: 10 },
  badgeText: { fontSize: 9, fontFamily: 'monospace', fontWeight: '700', letterSpacing: 1 },
  body: { gap: 12 },
  okBox: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    padding: 12, backgroundColor: '#4EBE8A11', borderRadius: 10,
    borderWidth: 1, borderColor: '#4EBE8A33',
  },
  okIcon:  { fontSize: 24, color: '#4EBE8A' },
  okTitle: { color: '#4EBE8A', fontFamily: 'monospace', fontWeight: '700', fontSize: 13 },
  okSub:   { color: '#6B7F8E', fontFamily: 'monospace', fontSize: 11, marginTop: 2, lineHeight: 16 },
  scoreRow: { flexDirection: 'row', justifyContent: 'space-between' },
  scoreText: { fontSize: 9, color: '#6B7F8E', fontFamily: 'monospace', letterSpacing: 1 },
  scoreNum:  { fontSize: 12, fontFamily: 'monospace', fontWeight: '700' },
  scoreTrack: { height: 5, backgroundColor: '#1C2730', borderRadius: 3, overflow: 'hidden' },
  scoreFill:  { height: '100%', borderRadius: 3 },
  sectionLabel: {
    fontSize: 9, color: '#6B7F8E', fontFamily: 'monospace',
    letterSpacing: 2, marginTop: 2,
  },
  herbCard: {
    flexDirection: 'row', gap: 10,
    backgroundColor: '#0D1219', borderRadius: 10, padding: 12,
    borderWidth: 1, borderColor: '#1C2730',
  },
  herbIndex: {
    width: 36, height: 36, backgroundColor: '#1C2730',
    borderRadius: 8, alignItems: 'center', justifyContent: 'center',
  },
  herbIndexText: { color: '#5BCFDA', fontFamily: 'monospace', fontWeight: '700', fontSize: 12 },
  herbInfo: { flex: 1, gap: 6 },
  herbName: { color: '#E8EDF2', fontFamily: 'monospace', fontWeight: '600', fontSize: 13 },
  herbMeta: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
  herbTag: {
    paddingHorizontal: 8, paddingVertical: 2,
    backgroundColor: '#D4A85311', borderRadius: 4,
    borderWidth: 1, borderColor: '#D4A85333',
  },
  herbTagText: { fontSize: 9, color: '#D4A853', fontFamily: 'monospace' },
  protocolBox: {
    padding: 12, borderWidth: 1, borderRadius: 10,
    backgroundColor: '#0D1219', gap: 6,
  },
  protocolLabel: { fontSize: 9, color: '#6B7F8E', fontFamily: 'monospace', letterSpacing: 2 },
  protocolText:  { fontFamily: 'monospace', fontSize: 12, lineHeight: 18 },
  disclaimer:    { fontSize: 9, color: '#3A4F5C', fontFamily: 'monospace', lineHeight: 14, textAlign: 'center' },
});

export default BotanicalRecommendation;
