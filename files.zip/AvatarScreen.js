/**
 * ZIMA · AvatarScreen
 * Registro de carga de entrenamiento y evolución del avatar.
 */
import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity,
  ScrollView, StyleSheet,
} from 'react-native';
import AvatarEvolution, { AVATAR_STATES } from '../components/AvatarEvolution';
import { calculateAvatarLevel } from '../engine/SIMEngine';

const AvatarScreen = ({ state, onUpdate }) => {
  const [sets, setSets] = useState('');
  const [reps, setReps] = useState('');
  const [kg,   setKg]   = useState('');
  const [exercise, setExercise] = useState('');

  const { loadVolume = 0, ketones = 0, adherenceDays = 0 } = state;
  const avatarLevel = calculateAvatarLevel(loadVolume, ketones, adherenceDays);
  const avatarData  = AVATAR_STATES[avatarLevel];

  const addLoad = async () => {
    const s = parseFloat(sets) || 0;
    const r = parseFloat(reps) || 0;
    const k = parseFloat(kg)   || 0;
    const vol = s * r * k;
    if (vol <= 0) return;

    const newVol = loadVolume + vol;
    const ketoBonus = ketones >= 0.5 ? 1 : 0;

    const entry = {
      id:        Date.now().toString(),
      exercise:  exercise || 'Ejercicio',
      sets:      s, reps: r, kg: k,
      volume:    vol,
      timestamp: Date.now(),
      date:      new Date().toLocaleDateString('es-ES'),
    };

    await onUpdate({
      ...state,
      loadVolume:     newVol,
      adherenceDays:  adherenceDays + ketoBonus,
      loadHistory:    [...(state.loadHistory || []), entry],
    });

    setSets(''); setReps(''); setKg(''); setExercise('');
  };

  const THRESHOLDS = [0, 500, 2000, 5000, 10000];
  const nextThreshold = THRESHOLDS[Math.min(avatarLevel + 1, 4)];
  const remaining     = Math.max(0, nextThreshold - loadVolume);

  return (
    <ScrollView
      style={styles.scroll}
      contentContainerStyle={styles.content}
      showsVerticalScrollIndicator={false}
    >
      <Text style={styles.screenTitle}>AVATAR</Text>
      <Text style={styles.screenSub}>Evolución según carga y cetosis</Text>

      {/* Avatar grande */}
      <View style={styles.avatarCard}>
        <AvatarEvolution
          level={avatarLevel}
          ketones={ketones}
          loadVolume={loadVolume}
          size="lg"
        />
        {avatarLevel < 4 && (
          <View style={styles.remainingBox}>
            <Text style={styles.remainingLabel}>Para siguiente nivel</Text>
            <Text style={[styles.remainingValue, { color: avatarData.color }]}>
              {remaining.toLocaleString()} kg·rep
            </Text>
          </View>
        )}
      </View>

      {/* Niveles */}
      <View style={styles.card}>
        <Text style={styles.cardTitle}>MAPA DE EVOLUCIÓN</Text>
        {AVATAR_STATES.map((av) => (
          <View key={av.id} style={[
            styles.levelRow,
            av.level === avatarLevel && styles.levelRowActive,
          ]}>
            <Text style={styles.levelEmoji}>{av.emoji}</Text>
            <View style={styles.levelInfo}>
              <Text style={[styles.levelName, av.level === avatarLevel && { color: av.color }]}>
                {av.label}
              </Text>
              <Text style={styles.levelDesc}>{av.description}</Text>
            </View>
            <Text style={[styles.levelThreshold, { color: av.level === avatarLevel ? av.color : '#6B7F8E' }]}>
              {av.minLoad.toLocaleString()}
            </Text>
          </View>
        ))}
      </View>

      {/* Registro de carga */}
      <View style={styles.card}>
        <Text style={styles.cardTitle}>REGISTRAR ENTRENAMIENTO</Text>

        <View style={{ gap: 4 }}>
          <Text style={styles.fieldLabel}>EJERCICIO</Text>
          <TextInput
            style={styles.input}
            value={exercise}
            onChangeText={setExercise}
            placeholder="Ej: Sentadilla, Press banca..."
            placeholderTextColor="#3A4F5C"
          />
        </View>

        <View style={styles.tripleRow}>
          {[
            ['SERIES', sets, setSets, '4'],
            ['REPS',   reps, setReps, '8'],
            ['PESO kg', kg,  setKg,  '80'],
          ].map(([label, val, setVal, ph]) => (
            <View key={label} style={styles.tripleField}>
              <Text style={styles.fieldLabel}>{label}</Text>
              <TextInput
                style={[styles.input, styles.inputCenter]}
                value={val}
                onChangeText={setVal}
                keyboardType="decimal-pad"
                placeholder={ph}
                placeholderTextColor="#3A4F5C"
              />
            </View>
          ))}
        </View>

        {sets && reps && kg && (
          <View style={styles.calcPreview}>
            <Text style={styles.calcLabel}>VOLUMEN A AGREGAR</Text>
            <Text style={styles.calcValue}>
              {((parseFloat(sets)||0) * (parseFloat(reps)||0) * (parseFloat(kg)||0)).toLocaleString()} kg·rep
            </Text>
          </View>
        )}

        <TouchableOpacity style={styles.addBtn} onPress={addLoad} activeOpacity={0.7}>
          <Text style={styles.addBtnText}>+ AGREGAR SERIE</Text>
        </TouchableOpacity>
      </View>

      {/* Stats */}
      <View style={styles.statsCard}>
        {[
          ['VOLUMEN TOTAL',   `${loadVolume.toLocaleString()} kg·rep`, '#5BCFDA'],
          ['NIVEL ACTUAL',    `${avatarLevel} / 4`,                   '#D4A853'],
          ['DÍAS EN CETOSIS', `${adherenceDays} días`,                 '#4EBE8A'],
          ['SESIONES',        `${(state.loadHistory || []).length}`,   '#E8EDF2'],
        ].map(([label, val, color]) => (
          <View key={label} style={styles.statRow}>
            <Text style={styles.statLabel}>{label}</Text>
            <Text style={[styles.statValue, { color }]}>{val}</Text>
          </View>
        ))}
      </View>

      {/* Historial reciente */}
      {(state.loadHistory || []).length > 0 && (
        <View style={styles.card}>
          <Text style={styles.cardTitle}>HISTORIAL</Text>
          {[...(state.loadHistory || [])].reverse().slice(0, 5).map(entry => (
            <View key={entry.id} style={styles.historyRow}>
              <Text style={styles.historyExercise}>{entry.exercise}</Text>
              <Text style={styles.historyDetail}>
                {entry.sets}×{entry.reps} · {entry.kg}kg
              </Text>
              <Text style={styles.historyVolume}>+{entry.volume.toFixed(0)}</Text>
            </View>
          ))}
        </View>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  scroll:   { flex: 1 },
  content:  { padding: 16, gap: 14, paddingBottom: 32 },
  screenTitle: { color: '#E8EDF2', fontFamily: 'monospace', fontWeight: '800', fontSize: 22 },
  screenSub:   { color: '#6B7F8E', fontFamily: 'monospace', fontSize: 11, marginTop: 2 },
  avatarCard: {
    backgroundColor: '#111820', borderWidth: 1, borderColor: '#1C2730',
    borderRadius: 16, padding: 24, alignItems: 'center', gap: 16,
  },
  remainingBox: { alignItems: 'center', gap: 4 },
  remainingLabel: { fontSize: 10, color: '#6B7F8E', fontFamily: 'monospace' },
  remainingValue: { fontFamily: 'monospace', fontWeight: '700', fontSize: 18 },
  card: {
    backgroundColor: '#111820', borderWidth: 1, borderColor: '#1C2730',
    borderRadius: 16, padding: 16, gap: 10,
  },
  cardTitle: {
    color: '#5BCFDA', fontFamily: 'monospace', fontWeight: '700',
    fontSize: 12, letterSpacing: 2,
    paddingBottom: 10, borderBottomWidth: 1, borderBottomColor: '#1C2730',
  },
  levelRow: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: '#1C2730',
    opacity: 0.5,
  },
  levelRowActive: { opacity: 1 },
  levelEmoji:     { fontSize: 24 },
  levelInfo:      { flex: 1 },
  levelName:      { color: '#E8EDF2', fontFamily: 'monospace', fontWeight: '600', fontSize: 13 },
  levelDesc:      { color: '#6B7F8E', fontFamily: 'monospace', fontSize: 10, marginTop: 2 },
  levelThreshold: { fontFamily: 'monospace', fontSize: 11 },
  fieldLabel:  { fontSize: 9, color: '#6B7F8E', fontFamily: 'monospace', letterSpacing: 1 },
  input: {
    backgroundColor: '#1C2730', borderWidth: 1, borderColor: '#2A3640',
    borderRadius: 8, paddingHorizontal: 12, paddingVertical: 10,
    color: '#E8EDF2', fontFamily: 'monospace', fontSize: 14,
  },
  inputCenter: { textAlign: 'center' },
  tripleRow:   { flexDirection: 'row', gap: 8 },
  tripleField: { flex: 1, gap: 4 },
  calcPreview: {
    padding: 10, backgroundColor: '#5BCFDA11', borderRadius: 8,
    borderWidth: 1, borderColor: '#5BCFDA33',
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
  },
  calcLabel: { fontSize: 9, color: '#6B7F8E', fontFamily: 'monospace' },
  calcValue: { color: '#5BCFDA', fontFamily: 'monospace', fontWeight: '700', fontSize: 14 },
  addBtn: {
    backgroundColor: '#5BCFDA22', borderWidth: 1, borderColor: '#5BCFDA66',
    borderRadius: 10, paddingVertical: 12, alignItems: 'center',
  },
  addBtnText: { color: '#5BCFDA', fontFamily: 'monospace', fontWeight: '700', fontSize: 12, letterSpacing: 2 },
  statsCard: {
    backgroundColor: '#111820', borderWidth: 1, borderColor: '#1C2730',
    borderRadius: 16, padding: 16, gap: 12,
  },
  statRow:   { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  statLabel: { color: '#6B7F8E', fontFamily: 'monospace', fontSize: 11 },
  statValue: { fontFamily: 'monospace', fontWeight: '700', fontSize: 15 },
  historyRow: {
    flexDirection: 'row', alignItems: 'center', paddingVertical: 8,
    borderBottomWidth: 1, borderBottomColor: '#1C2730', gap: 8,
  },
  historyExercise: { flex: 1, color: '#E8EDF2', fontFamily: 'monospace', fontSize: 12 },
  historyDetail:   { color: '#6B7F8E', fontFamily: 'monospace', fontSize: 10 },
  historyVolume:   { color: '#5BCFDA', fontFamily: 'monospace', fontWeight: '700', fontSize: 12 },
});

export default AvatarScreen;
