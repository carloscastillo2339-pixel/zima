# ZIMA · Motor SIM v2.0
### Asistente Metabólico Inteligente — React Native + Expo

```
Z I M A
Sistema de Inteligencia Metabólica Avanzada
```

---

## 🚀 Instalación rápida

```bash
# 1. Crear proyecto Expo
npx create-expo-app zima-app --template blank
cd zima-app

# 2. Instalar dependencia de persistencia
npx expo install @react-native-async-storage/async-storage

# 3. Copiar todos los archivos del proyecto

# 4. Ejecutar
npx expo start
```

---

## 📁 Estructura del proyecto

```
zima-app/
├── App.js                          # Raíz: estado global + navegación
├── components/
│   ├── AvatarEvolution.js          # Avatar animado (5 estados)
│   ├── BiometricInput.js           # Registro cetonas + peso
│   ├── NutritionScanner.js         # Escáner de macros + carbs netos
│   ├── InflammationEngine.js       # Motor de inflamación visual
│   └── BotanicalRecommendation.js  # Protocolo botánico automático
├── screens/
│   ├── DashboardScreen.js          # Vista principal completa
│   ├── BiometricsScreen.js         # Pantalla de biometría
│   ├── NutritionScreen.js          # Pantalla de nutrición
│   └── AvatarScreen.js             # Pantalla de avatar y carga
├── engine/
│   └── SIMEngine.js                # Motor metabólico desacoplado
├── utils/
│   ├── netCarbsCalculator.js       # Cálculo preciso de carbs netos
│   └── ketosisAnalyzer.js          # Análisis de cetosis y tendencias
└── package.json
```

---

## 🧠 Cómo escalar el Motor SIM hacia IA

### Fase 1 — Datos reales (ahora)
El Motor SIM ya funciona con reglas expertas. Cada función es pura e intercambiable.

```js
// engine/SIMEngine.js — funciones intercambiables
export const calculateInflammation = ({ ketones, netCarbsToday, ... }) => { ... }
export const getBotanicalProtocol  = (score)                            => { ... }
export const generateSIMInsight    = (state)                            => { ... }
```

### Fase 2 — Persistencia y contexto (semanas 1-4)
```bash
# Agrega SQLite para historial largo plazo
npx expo install expo-sqlite

# Agrega notificaciones para recordatorios
npx expo install expo-notifications
```

Crea `engine/SIMContext.js` que acumule:
- Últimos 30 días de cetonas y peso
- Tendencias de inflamación
- Patrones de comida

### Fase 3 — IA conversacional (mes 2)
Reemplaza `generateSIMInsight` con llamada a Claude API:

```js
// engine/SIMEngine.js — versión IA
export const generateSIMInsight = async (state) => {
  const context = buildMetabolicContext(state); // serializa estado

  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'x-api-key':         process.env.ANTHROPIC_API_KEY,
      'anthropic-version': '2023-06-01',
      'content-type':      'application/json',
    },
    body: JSON.stringify({
      model:      'claude-sonnet-4-20250514',
      max_tokens: 300,
      system: `Eres el Motor SIM de ZIMA, un asistente metabólico experto en
               dieta cetogénica, biohacking y rendimiento físico. Responde en
               español. Sé conciso y accionable. Máximo 2 oraciones.`,
      messages: [{
        role:    'user',
        content: `Estado metabólico del usuario: ${JSON.stringify(context)}.
                  ¿Cuál es el insight más importante para hoy?`,
      }],
    }),
  });

  const data = await response.json();
  return [data.content[0].text];
};
```

### Fase 4 — Visión computacional (mes 3)
```bash
npx expo install expo-camera
npx expo install expo-image-manipulator
```

Flujo OCR para escáner real:
```
Cámara → expo-camera
→ Captura imagen tabla nutricional
→ Google Vision API / Tesseract.js
→ Parsea macros (regex + NLP)
→ Alimenta SIM.netCarbs()
```

### Fase 5 — Biométrica Bluetooth (mes 4)
```bash
npx expo install expo-bluetooth
```

Compatible con:
- Keto-Mojo GKI (medidor cetonas/glucosa BT)
- Abbott Libre 3 (glucosa continua)
- Withings Body+ (báscula BT)
- Apple Watch / Garmin (HRV, sueño)

### Fase 6 — Modelo predictivo local (mes 5-6)
```bash
npx expo install expo-ml-kit
# o
npm install @tensorflow/tfjs @tensorflow/tfjs-react-native
```

Con 30+ días de datos, entrena un modelo que:
- Predice cetonas del día siguiente (regresión)
- Detecta riesgo de salida de cetosis (clasificación)
- Personaliza umbrales de inflamación por usuario

### Arquitectura IA final

```
[Datos] ────→ [SIMEngine] ────→ [Claude API]
   ↑                                  ↓
[BT/OCR]   [SQLite local]    [Insights personalizados]
   ↑              ↓                   ↓
[Wearables] [TFLite Model] ────→ [UI ZIMA]
```

---

## 🎨 Sistema visual

| Token    | Valor     | Uso                    |
|----------|-----------|------------------------|
| void     | `#080B0F` | Fondo principal        |
| surface  | `#111820` | Cards                  |
| rim      | `#1C2730` | Bordes                 |
| ice      | `#5BCFDA` | Acento principal       |
| gold     | `#D4A853` | Alertas moderadas      |
| danger   | `#E05A4E` | Alertas críticas       |
| ok       | `#4EBE8A` | Estados óptimos        |

---

## 📊 Fórmulas del Motor SIM

### Carbohidratos Netos
```
Carbs Netos = Total − Fibra − (Polialcoholes × 0.5) − (Eritritol × 0)
```

### Score de Inflamación (0–1)
```
Inflamación = (KetoFactor × 0.40)
            + (CarbFactor × 0.35)
            + (EtrésFactor × 0.15)
            + (SueñoFactor × 0.10)
```

### Nivel de Avatar
```
BaseLevel = thresholds.findIndex(t => loadVolume >= t)
BonusKeto = ketones >= 1.5 ? 1 : 0
BonusAdh  = adherenceDays >= 30 ? 1 : 0
Level     = min(BaseLevel + floor((BonusKeto + BonusAdh) / 2), 4)
```

---

> ZIMA es un proyecto de biohacking personal.
> No reemplaza diagnóstico ni tratamiento médico.
> Consulta a un profesional de salud antes de modificar tu dieta.
