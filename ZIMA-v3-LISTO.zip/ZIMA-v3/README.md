# ZIMA v3 — Motor SIM
**Carlos Espina Property**

---

## ▶ INICIO RÁPIDO — 3 comandos en PowerShell

```powershell
npm install
```

```powershell
npm install -g expo-cli
```

```powershell
npx expo start
```

Escanea el QR con la app **Expo Go** en tu celular.

---

## Estructura del proyecto

```
ZIMA-v3/
├── App.js              ← Entrada principal + Dashboard
├── app.json            ← Configuración Expo
├── package.json        ← Dependencias
├── babel.config.js     ← Transpilador
├── .gitignore          ← Protección IP
├── engine/
│   └── SIMEngine.js    ← Algoritmo SIM (motor metabólico)
├── screens/
│   ├── OnboardingScreen.js
│   ├── TrainingScreen.js
│   ├── KitchenScreen.js
│   ├── SleepScreen.js
│   ├── KetonesScreen.js
│   ├── HydrationScreen.js
│   ├── SupplementsScreen.js
│   └── HistoryScreen.js
├── data/
│   └── index.js
└── theme/
    └── index.js
```

---

*© Carlos Espina Property — Todos los derechos reservados*
