// shims/empty.js
// Módulo vacío que reemplaza shims de Node.js incompatibles con React Native / Windows
// Evita el error: ENOENT: no such file or directory, mkdir ... node:sea

module.exports = {};
