// metro.config.js
// Solución para error ENOENT en Windows con node:sea y otros shims node:*
// Compatible con Expo 50 + Node.js 20+

const { getDefaultConfig } = require('expo/metro-config');

const config = getDefaultConfig(__dirname);

// Redirige todos los módulos "node:*" a módulos vacíos
// para evitar que Metro intente crear carpetas con ":" en Windows (NTFS no lo permite)
config.resolver.extraNodeModules = {
  ...config.resolver.extraNodeModules,

  // Shims problemáticos que generan rutas con ":" en Windows
  'node:sea':         require.resolve('./shims/empty.js'),
  'node:fs':          require.resolve('./shims/empty.js'),
  'node:path':        require.resolve('./shims/empty.js'),
  'node:os':          require.resolve('./shims/empty.js'),
  'node:crypto':      require.resolve('./shims/empty.js'),
  'node:stream':      require.resolve('./shims/empty.js'),
  'node:buffer':      require.resolve('./shims/empty.js'),
  'node:util':        require.resolve('./shims/empty.js'),
  'node:events':      require.resolve('./shims/empty.js'),
  'node:assert':      require.resolve('./shims/empty.js'),
  'node:process':     require.resolve('./shims/empty.js'),
  'node:http':        require.resolve('./shims/empty.js'),
  'node:https':       require.resolve('./shims/empty.js'),
  'node:net':         require.resolve('./shims/empty.js'),
  'node:tls':         require.resolve('./shims/empty.js'),
  'node:zlib':        require.resolve('./shims/empty.js'),
  'node:child_process': require.resolve('./shims/empty.js'),
  'node:worker_threads': require.resolve('./shims/empty.js'),
};

// Asegura que Metro no intente resolver módulos node: nativos
config.resolver.resolveRequest = (context, moduleName, platform) => {
  if (moduleName.startsWith('node:')) {
    return {
      filePath: require.resolve('./shims/empty.js'),
      type: 'sourceFile',
    };
  }
  return context.resolveRequest(context, moduleName, platform);
};

module.exports = config;
