module.exports = function(api) {
  api.cache(true);
  return {
    presets: ['babel-preset-expo'],
    plugins: [
      // Evita transformaciones que generan rutas node: incompatibles con Windows
      ['module-resolver', {
        alias: {
          // Redirige cualquier import node:* al shim vacío
        }
      }]
    ].filter(Boolean)
  };
};
