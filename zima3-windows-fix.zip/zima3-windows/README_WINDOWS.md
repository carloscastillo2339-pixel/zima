# ZIMA — Instalación en Windows

## ¿Por qué este error?

Windows (NTFS) **no permite** carpetas con dos puntos (`:`) en el nombre.
Expo 50 + Node.js 20+ internamente intenta crear rutas como `node:sea`, `node:fs`, etc., lo que provoca:

```
ENOENT: no such file or directory, mkdir '...\node:sea'
```

Este proyecto ya incluye la solución. Solo sigue los pasos.

---

## Requisitos previos

- **Node.js 18 LTS** (recomendado) — descarga en https://nodejs.org
  - ⚠️ Si tienes Node.js 20+, también funciona con este fix
- **Git** (opcional) — https://git-scm.com
- **Expo Go** en tu celular (Android o iOS)

---

## Instalación paso a paso

### 1. Abrir PowerShell en la carpeta del proyecto

Haz clic derecho en la carpeta `zima3` → **"Abrir en Terminal"**

O en PowerShell:
```powershell
cd C:\ruta\a\zima3
```

### 2. Instalar Expo CLI (solo la primera vez)
```powershell
npm install -g expo-cli
```

### 3. Instalar dependencias
```powershell
npm install
```

### 4. Iniciar la app
```powershell
npx expo start
```

---

## Si aún aparece el error ENOENT

**Opción A — Limpiar caché de npm:**
```powershell
npm cache clean --force
npm install
```

**Opción B — Usar Node.js 18 LTS en lugar de 20+:**

Descarga Node.js 18 LTS desde https://nodejs.org/en/download y reinstala.

**Opción C — Limpiar caché de Metro:**
```powershell
npx expo start --clear
```

**Opción D — Error de política de ejecución en PowerShell:**

Abre PowerShell como Administrador y ejecuta:
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

---

## Ver la app en tu celular

1. Instala **Expo Go** desde Play Store o App Store
2. Conecta tu celular y PC a la **misma red WiFi**
3. Escanea el código QR que aparece al ejecutar `npx expo start`
4. Si no carga, en el menú de Expo DevTools cambia de **LAN** a **Tunnel**

---

## Archivos agregados para compatibilidad Windows

| Archivo | Propósito |
|---|---|
| `metro.config.js` | Redirige módulos `node:*` a shims vacíos |
| `shims/empty.js` | Módulo vacío que reemplaza los shims problemáticos |
| `.npmrc` | Configuración de npm para evitar errores en NTFS |

---

## Estructura del proyecto

```
zima3/
├── App.js                  ← Punto de entrada principal
├── app.json                ← Configuración de Expo
├── package.json            ← Dependencias
├── metro.config.js         ← ✅ FIX Windows: manejo de node:*
├── babel.config.js         ← Configuración de Babel
├── .npmrc                  ← ✅ FIX Windows: configuración npm
├── shims/
│   └── empty.js            ← ✅ FIX Windows: módulo vacío
├── engine/
│   └── SIMEngine.js        ← Motor metabólico SIM
├── screens/                ← 8 pantallas de la app
├── theme/                  ← Colores y estilos
└── data/                   ← Datos estáticos
```
