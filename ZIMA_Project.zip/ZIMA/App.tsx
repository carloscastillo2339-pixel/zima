// © Carlos Espina Property — ZIMA App Entry Point
// ZIMA — Ecosistema de Bio-Optimización Cetogénica de Última Generación
// Algoritmo SIM | Propiedad Intelectual: Carlos Espina | 2026
import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { AppNavigator } from './src/navigation/AppNavigator';

export default function App() {
  return (
    <GestureHandlerRootView style={{ flex: 1, backgroundColor: '#000000' }}>
      <StatusBar style="light" backgroundColor="#000000" />
      <AppNavigator />
    </GestureHandlerRootView>
  );
}
