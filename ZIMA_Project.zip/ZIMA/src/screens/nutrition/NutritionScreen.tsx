// © Carlos Espina Property — Fase 2 & 4: Nutrición (Funciones 9-16, 25-32)
import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, TextInput, StyleSheet, SafeAreaView, Alert } from 'react-native';
import { COLORS, RADIUS, SPACING } from '../../constants/theme';
import { useZIMAStore, PantryItem } from '../../store/useZIMAStore';
import { PantryItemCard } from '../../components/pantry/PantryItem';
import { FaithWidget } from '../../components/faith/FaithWidget';
import { SectionLabel } from '../../components/ui/SectionLabel';
import { ZIMAButton } from '../../components/ui/ZIMAButton';
import { IPSignature } from '../../components/ui/IPSignature';
import { calcCarbosNetos, isKetogenic, detectAceite } from '../../utils/sim';

type Tab = 'pantry' | 'scanner' | 'suplements' | 'faith';

export const NutritionScreen: React.FC = () => {
  const { idioma, pantry, addPantryItem, suplementos, addSuplemento, removeSuplemento } = useZIMAStore();
  const t = idioma === 'EN';
  const [tab, setTab] = useState<Tab>('pantry');
  const [scanResult, setScanResult] = useState<{ carbos: number; fibra: number; grasas: number; proteinas: number; aceite: string } | null>(null);

  // Keto-Scanner Manual (Función 25, 26, 27, 28)
  const [carbos, setCarbos] = useState('');
  const [fibra, setFibra] = useState('');
  const [grasas, setGrasas] = useState('');
  const [proteinas, setProteinas] = useState('');
  const [aceiteInput, setAceiteInput] = useState('');

  const runScan = () => {
    const c = parseFloat(carbos) || 0;
    const f = parseFloat(fibra) || 0;
    const g = parseFloat(grasas) || 0;
    const p = parseFloat(proteinas) || 0;
    const netos = calcCarbosNetos(c, f);
    const keto = isKetogenic(netos, g, p);
    const aceite = detectAceite(aceiteInput);
    setScanResult({ carbos: netos, fibra: f, grasas: g, proteinas: p, aceite });
    if (aceite === 'toxic') {
      Alert.alert('⚠️ ALERTA ROJA', t ? 'Pro-inflammatory oil detected! Botanical intervention recommended.' : '¡Aceite pro-inflamatorio detectado! Intervención botánica recomendada.

Infusión: Albahaca o Aloe Vera.');
    }
  };

  const TABS: { id: Tab; label: string }[] = [
    { id: 'pantry', label: t ? '🥗 Pantry' : '🥗 Despensa' },
    { id: 'scanner', label: t ? '📸 Scanner' : '📸 Scanner' },
    { id: 'suplements', label: t ? '💊 Supps' : '💊 Suplementos' },
    { id: 'faith', label: t ? '✝ Faith' : '✝ Fe' },
  ];

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView style={styles.scroll} showsVerticalScrollIndicator={false}>
        <SectionLabel>{t ? 'Nutritional Intelligence' : 'Inteligencia Nutricional'}</SectionLabel>
        <View style={styles.tabs}>
          {TABS.map(tb => (
            <TouchableOpacity key={tb.id} onPress={() => setTab(tb.id)}
              style={[styles.tab, tab === tb.id && styles.tabActive]}>
              <Text style={[styles.tabText, tab === tb.id && { color: COLORS.white }]}>{tb.label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* SMART PANTRY (Funciones 9-11) */}
        {tab === 'pantry' && (
          <View>
            <Text style={styles.secTitle}>{t ? 'Smart Pantry' : 'Smart Pantry (Despensa SaaS)'}</Text>
            {pantry.length === 0
              ? <Text style={styles.empty}>{t ? 'Empty pantry. Add items below.' : 'Despensa vacía. Agrega insumos.'}</Text>
              : pantry.map(item => <PantryItemCard key={item.id} item={item} />)
            }
            <ZIMAButton label={t ? '+ Add Item' : '+ Agregar Insumo'} onPress={() => {
              const sample: PantryItem = {
                id: Date.now().toString(),
                nombre: t ? 'Avocado Oil' : 'Aceite de Palta',
                tipo: 'Grasa',
                stockGramos: 300,
              };
              addPantryItem(sample);
            }} variant="outline" style={{ marginTop: 12 }} />
          </View>
        )}

        {/* KETO SCANNER PRO (Funciones 25-28) */}
        {tab === 'scanner' && (
          <View>
            <Text style={styles.secTitle}>{t ? 'Keto-Scanner Pro' : 'Keto-Scanner Pro'}</Text>
            <Text style={styles.secSub}>{t ? 'Enter nutritional values manually or scan barcode.' : 'Ingresa valores nutricionales o escanea código de barras.'}</Text>
            {[
              { label: t ? 'Total Carbs (g)' : 'Carbos Totales (g)', val: carbos, set: setCarbos },
              { label: t ? 'Fiber (g)' : 'Fibra (g)', val: fibra, set: setFibra },
              { label: t ? 'Fats (g)' : 'Grasas (g)', val: grasas, set: setGrasas },
              { label: t ? 'Protein (g)' : 'Proteínas (g)', val: proteinas, set: setProteinas },
            ].map((f, i) => (
              <View key={i} style={styles.inputGroup}>
                <Text style={styles.inputLabel}>{f.label}</Text>
                <TextInput value={f.val} onChangeText={f.set} keyboardType="numeric" placeholder="0"
                  placeholderTextColor={COLORS.grayDark} style={styles.input} />
              </View>
            ))}
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>{t ? 'Ingredients (for oil detection)' : 'Ingredientes (para detectar aceites)'}</Text>
              <TextInput value={aceiteInput} onChangeText={setAceiteInput} placeholder={t ? 'e.g. sunflower oil, canola...' : 'ej. aceite de maravilla, canola...'}
                placeholderTextColor={COLORS.grayDark} style={styles.input} />
            </View>
            <ZIMAButton label={t ? '⚡ Analyze' : '⚡ Analizar'} onPress={runScan} style={{ marginBottom: 16 }} />
            {scanResult && (
              <View style={[styles.result, { borderColor: calcCarbosNetos(parseFloat(carbos) || 0, parseFloat(fibra) || 0) <= 20 ? COLORS.eliteBlue : COLORS.red }]}>
                <Text style={styles.resultTitle}>
                  {calcCarbosNetos(parseFloat(carbos) || 0, parseFloat(fibra) || 0) <= 20 ? '🔵 ELITE BLUE — CETOGÉNICO' : '🔴 ALERTA — NO CETOGÉNICO'}
                </Text>
                <Text style={styles.resultLine}>{t ? 'Net Carbs:' : 'Carbos Netos:'} {scanResult.carbos}g</Text>
                <Text style={styles.resultLine}>{t ? 'Oil status:' : 'Estado aceite:'} {scanResult.aceite === 'elite' ? '✅ Elite Blue' : scanResult.aceite === 'toxic' ? '⚠️ Tóxico' : '—'}</Text>
                {scanResult.aceite === 'toxic' && <Text style={styles.botan}>🌿 {t ? 'Botanical intervention: Basil or Aloe Vera' : 'Intervención: Albahaca o Aloe Vera'}</Text>}
              </View>
            )}
          </View>
        )}

        {/* RACK DE SUPLEMENTOS (Funciones 12-14) */}
        {tab === 'suplements' && (
          <View>
            <Text style={styles.secTitle}>{t ? 'Supplement Rack (Max 10)' : 'Rack de Suplementos (Tope 10)'}</Text>
            <Text style={styles.secSub}>{t ? `${suplementos.length}/10 slots used` : `${suplementos.length}/10 slots usados`}</Text>
            {suplementos.map(s => (
              <View key={s.slotId} style={styles.suplCard}>
                <View style={styles.suplRow}>
                  <Text style={styles.suplSlot}>#{s.slotId}</Text>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.suplName}>{s.nombre}</Text>
                    <Text style={styles.suplBio}>{s.propiedadBio}</Text>
                  </View>
                  <View style={[styles.suplBadge, { backgroundColor: s.certificadoCetogenico ? 'rgba(0,112,255,0.2)' : 'rgba(255,45,85,0.2)' }]}>
                    <Text style={{ color: s.certificadoCetogenico ? COLORS.eliteBlue : COLORS.red, fontSize: 9, fontWeight: '700' }}>
                      {s.certificadoCetogenico ? (t ? 'KETO ✓' : 'KETO ✓') : (t ? 'NO KETO' : 'NO KETO')}
                    </Text>
                  </View>
                </View>
              </View>
            ))}
            <ZIMAButton label={t ? '+ Add Supplement' : '+ Agregar Suplemento'} onPress={() => {
              const ok = addSuplemento({
                slotId: suplementos.length + 1,
                nombre: t ? 'Magnesium Glycinate' : 'Magnesio Glicinato',
                certificadoCetogenico: true,
                propiedadBio: t ? 'Reduces cortisol. Improves deep sleep.' : 'Reduce cortisol. Mejora sueño profundo.',
              });
              if (!ok) Alert.alert('ZIMA', t ? 'Rack full (10/10). Remove one first.' : 'Rack lleno (10/10). Reemplaza uno primero.');
            }} variant="outline" style={{ marginTop: 12 }} />
          </View>
        )}

        {/* FAITH VAULT (Funciones 15-16) */}
        {tab === 'faith' && (
          <View>
            <FaithWidget showVault />
            <Text style={styles.secTitle}>{t ? 'Psalm Vault' : 'Bóveda de Salmos'}</Text>
          </View>
        )}

        <IPSignature />
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.bg },
  scroll: { flex: 1, paddingHorizontal: 24 },
  tabs: { flexDirection: 'row', gap: 6, marginBottom: 20 },
  tab: { flex: 1, padding: 10, borderRadius: RADIUS.sm, backgroundColor: COLORS.darkGray, alignItems: 'center', borderWidth: 1, borderColor: '#333' },
  tabActive: { borderColor: COLORS.eliteBlue, backgroundColor: 'rgba(0,112,255,0.15)' },
  tabText: { color: COLORS.gray, fontSize: 10, fontWeight: '700' },
  secTitle: { fontSize: 18, fontWeight: '800', color: COLORS.white, marginBottom: 6 },
  secSub: { fontSize: 12, color: COLORS.gray, marginBottom: 14 },
  empty: { color: COLORS.gray, textAlign: 'center', marginTop: 20, fontSize: 13 },
  inputGroup: { marginBottom: 12 },
  inputLabel: { fontSize: 11, color: COLORS.gray, fontWeight: '700', letterSpacing: 1, marginBottom: 4 },
  input: { backgroundColor: COLORS.darkGray, borderRadius: RADIUS.sm, padding: 14, color: COLORS.white, fontSize: 16, fontWeight: '700', borderWidth: 1, borderColor: '#2A2A2A' },
  result: { backgroundColor: COLORS.darkGray, borderRadius: RADIUS.md, padding: 16, borderWidth: 2, marginBottom: 16 },
  resultTitle: { fontSize: 15, fontWeight: '900', color: COLORS.white, marginBottom: 10 },
  resultLine: { fontSize: 13, color: COLORS.gray, marginBottom: 4 },
  botan: { fontSize: 12, color: COLORS.green, marginTop: 8, fontWeight: '600' },
  suplCard: { backgroundColor: COLORS.darkGray, borderRadius: RADIUS.md, padding: 14, marginBottom: 8, borderWidth: 1, borderColor: '#222' },
  suplRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  suplSlot: { width: 28, height: 28, borderRadius: 14, backgroundColor: COLORS.eliteBlue, textAlign: 'center', lineHeight: 28, color: COLORS.white, fontWeight: '900', fontSize: 12 },
  suplName: { fontSize: 14, fontWeight: '700', color: COLORS.white },
  suplBio: { fontSize: 11, color: COLORS.gray, marginTop: 2 },
  suplBadge: { padding: 6, borderRadius: RADIUS.sm },
});
