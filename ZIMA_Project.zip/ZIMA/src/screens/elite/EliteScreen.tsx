// © Carlos Espina Property — Fase 6: Funciones Élite (Funciones 41-54)
import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, SafeAreaView, Alert, TextInput } from 'react-native';
import { COLORS, RADIUS, SPACING, SIGNATURE } from '../../constants/theme';
import { useZIMAStore } from '../../store/useZIMAStore';
import { SectionLabel } from '../../components/ui/SectionLabel';
import { ZIMAButton } from '../../components/ui/ZIMAButton';
import { IPSignature } from '../../components/ui/IPSignature';
import { AvatarSIM } from '../../components/avatar/AvatarSIM';
import { calcLongevidad, calcPuntoEbullicion, calcExposicionUV } from '../../utils/sim';

export const EliteScreen: React.FC = () => {
  const { idioma, biotipo, faith, bioMonitor, workoutLog, psalmFavoritos } = useZIMAStore();
  const t = idioma === 'EN';
  const [fabOpen, setFabOpen] = useState(false);
  const [postureActive, setPostureActive] = useState(false);
  const [voiceStress, setVoiceStress] = useState(false);

  const cetonasEntries = bioMonitor.filter(b => b.tipo === 'Cetonas');
  const cetonasPromedio = cetonasEntries.length
    ? cetonasEntries.reduce((a, b) => a + b.valor, 0) / cetonasEntries.length : 0;
  const longevidad = calcLongevidad(workoutLog.length, cetonasEntries.length, cetonasPromedio, psalmFavoritos.length);
  const puntoEbullicion = calcPuntoEbullicion(100, 2, cetonasPromedio);
  const uvMinutes = calcExposicionUV(-33.45, new Date().getHours(), new Date().getMonth());

  const ELITE_FUNCTIONS = [
    {
      icon: '🫀', title: t ? 'Metabolic Mirror (X-Ray)' : 'Espejo Metabólico (Rayos X)',
      desc: t ? 'Avatar becomes transparent showing organs. Liver glows blue in ketosis.' : 'Avatar transparente mostrando órganos. Hígado brilla azul en cetosis.',
      fn: 41,
    },
    {
      icon: '🌙', title: t ? 'Circadian Sync (Red Light)' : 'Sincronización Circadiana (Luz Roja)',
      desc: t ? 'App auto-detects night hours and switches to deep red tones to protect melatonin.' : 'App detecta horario nocturno y cambia a tonos rojos profundos para preservar melatonina.',
      fn: 42,
    },
    {
      icon: '📸', title: t ? 'AI Posture Corrector' : 'Corrector de Postura AI',
      desc: t ? 'Front camera analyzes posture in real-time during exercises. Audible alert if incorrect.' : 'Cámara frontal analiza postura en tiempo real. Alerta audible si detecta error.',
      fn: 43,
    },
    {
      icon: '🎤', title: t ? 'ZIMA Voice Stress' : 'ZIMA Voice Stress',
      desc: t ? 'Analyzes cortisol markers via voice when reading Psalms.' : 'Analiza marcadores de estrés (cortisol estimado) mediante la voz al leer Salmos.',
      fn: 45,
    },
    {
      icon: '📦', title: t ? 'Scan & Stock' : 'Scan & Stock',
      desc: t ? 'AI vision loads pantry by scanning physical products.' : 'Visión artificial: escanea productos físicos y los registra automáticamente en la despensa.',
      fn: 46,
    },
    {
      icon: '🤜', title: t ? 'Grip Strength Test' : 'Test de Fuerza de Agarre',
      desc: t ? 'Neurological and muscular health assessment via on-screen grip test.' : 'Evaluación de salud neurológica y muscular mediante prueba de fuerza de agarre en pantalla.',
      fn: 50,
    },
  ];

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView style={styles.scroll} showsVerticalScrollIndicator={false}>
        <SectionLabel>{t ? 'Elite Functions — Last Gen' : 'Funciones de Última Generación'}</SectionLabel>

        {/* Longevidad (Función 51) */}
        <View style={styles.longevCard}>
          <Text style={styles.longevLabel}>{t ? 'LONGEVITY ALGORITHM' : 'ALGORITMO DE LONGEVIDAD'}</Text>
          <Text style={styles.longevVal}>+{longevidad}</Text>
          <Text style={styles.longevUnit}>{t ? 'estimated healthy years added' : 'años saludables estimados sumados'}</Text>
        </View>

        {/* Punto de Ebullición (Función 47) */}
        <View style={styles.infoRow}>
          <View style={styles.infoCard}>
            <Text style={styles.infoIcon}>🏋️</Text>
            <Text style={styles.infoVal}>{puntoEbullicion}kg</Text>
            <Text style={styles.infoLabel}>{t ? "Today's lift target" : 'Objetivo levantamiento hoy'}</Text>
          </View>
          <View style={styles.infoCard}>
            <Text style={styles.infoIcon}>☀️</Text>
            <Text style={styles.infoVal}>{uvMinutes}min</Text>
            <Text style={styles.infoLabel}>{t ? 'UV exposure (Vit D)' : 'Exposición UV (Vit D)'}</Text>
          </View>
        </View>

        {/* Elite Functions Grid */}
        {ELITE_FUNCTIONS.map((ef, i) => (
          <TouchableOpacity key={i} onPress={() => Alert.alert(`F${ef.fn}: ${ef.title}`, ef.desc)}
            style={styles.eliteCard}>
            <Text style={styles.eliteIcon}>{ef.icon}</Text>
            <View style={styles.eliteInfo}>
              <View style={styles.eliteRow}>
                <Text style={styles.eliteTitle}>{ef.title}</Text>
                <View style={styles.badge}><Text style={styles.badgeText}>F{ef.fn}</Text></View>
              </View>
              <Text style={styles.eliteDesc}>{ef.desc}</Text>
            </View>
          </TouchableOpacity>
        ))}

        {/* BFR Training (Función 48) */}
        <View style={styles.bfrCard}>
          <Text style={styles.bfrTitle}>🩸 {t ? 'BFR Training (Blood Flow Restriction)' : 'Entrenamiento Oclusivo (BFR)'}</Text>
          <Text style={styles.bfrText}>{t
            ? 'Use occlusion bands at 50-70% pressure on upper arms or thighs. Compatible exercises: curls, extensions, leg press.'
            : 'Usa bandas de oclusión al 50-70% de presión en brazos o muslos. Ejercicios compatibles: curl, extensiones, press de pierna.'}</Text>
          <Text style={styles.bfrWarning}>{t ? '⚠️ Not recommended with cardiovascular conditions.' : '⚠️ No recomendado con condiciones cardiovasculares.'}</Text>
        </View>

        {/* FAB Menu (Función 54) */}
        <View style={styles.fabContainer}>
          <Text style={styles.fabTitle}>{t ? '+ Action Console (FAB)' : '+ Consola de Comandos (FAB)'}</Text>
          <TouchableOpacity onPress={() => setFabOpen(!fabOpen)} style={styles.fab}>
            <Text style={styles.fabIcon}>{fabOpen ? '✕' : '+'}</Text>
          </TouchableOpacity>
          {fabOpen && (
            <View style={styles.fabMenu}>
              {[
                { icon: '🔥', label: t ? 'Log Ketones' : 'Registrar Cetonas' },
                { icon: '💪', label: t ? 'Start Training' : 'Iniciar Entrenamiento' },
                { icon: '📸', label: t ? 'Keto-Scanner' : 'Keto-Scanner' },
                { icon: '😴', label: t ? 'Sleep Mode' : 'Modo Sueño' },
              ].map((item, i) => (
                <TouchableOpacity key={i} style={styles.fabItem}>
                  <Text style={styles.fabItemText}>{item.icon} {item.label}</Text>
                </TouchableOpacity>
              ))}
            </View>
          )}
        </View>

        <IPSignature />
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.bg },
  scroll: { flex: 1, paddingHorizontal: 24 },
  longevCard: { backgroundColor: COLORS.darkGray, borderRadius: RADIUS.lg, padding: 28, alignItems: 'center', marginBottom: 12, borderWidth: 1, borderColor: 'rgba(0,112,255,0.3)' },
  longevLabel: { fontSize: 10, color: COLORS.eliteBlue, fontWeight: '700', letterSpacing: 2, marginBottom: 8 },
  longevVal: { fontSize: 56, fontWeight: '900', color: COLORS.white },
  longevUnit: { fontSize: 12, color: COLORS.gray, textAlign: 'center', marginTop: 4 },
  infoRow: { flexDirection: 'row', gap: 10, marginBottom: 12 },
  infoCard: { flex: 1, backgroundColor: COLORS.darkGray, borderRadius: RADIUS.md, padding: 16, alignItems: 'center' },
  infoIcon: { fontSize: 24, marginBottom: 4 },
  infoVal: { fontSize: 22, fontWeight: '900', color: COLORS.eliteBlue },
  infoLabel: { fontSize: 10, color: COLORS.gray, textAlign: 'center', marginTop: 4 },
  eliteCard: { flexDirection: 'row', backgroundColor: COLORS.darkGray, borderRadius: RADIUS.md, padding: 16, marginBottom: 8, borderWidth: 1, borderColor: '#222', gap: 14, alignItems: 'flex-start' },
  eliteIcon: { fontSize: 28 },
  eliteInfo: { flex: 1 },
  eliteRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4 },
  eliteTitle: { fontSize: 14, fontWeight: '700', color: COLORS.white, flex: 1 },
  badge: { backgroundColor: 'rgba(0,112,255,0.2)', paddingHorizontal: 8, paddingVertical: 2, borderRadius: RADIUS.sm },
  badgeText: { color: COLORS.eliteBlue, fontSize: 9, fontWeight: '700' },
  eliteDesc: { fontSize: 11, color: COLORS.gray, lineHeight: 16 },
  bfrCard: { backgroundColor: 'rgba(255,45,85,0.08)', borderRadius: RADIUS.md, padding: 16, marginBottom: 12, borderWidth: 1, borderColor: 'rgba(255,45,85,0.25)' },
  bfrTitle: { fontSize: 14, fontWeight: '800', color: COLORS.white, marginBottom: 8 },
  bfrText: { fontSize: 12, color: COLORS.gray, lineHeight: 18, marginBottom: 8 },
  bfrWarning: { fontSize: 11, color: COLORS.red, fontWeight: '600' },
  fabContainer: { backgroundColor: COLORS.darkGray, borderRadius: RADIUS.lg, padding: 20, marginBottom: 20 },
  fabTitle: { fontSize: 13, fontWeight: '700', color: COLORS.gray, marginBottom: 14 },
  fab: { width: 56, height: 56, borderRadius: 28, backgroundColor: COLORS.eliteBlue, alignItems: 'center', justifyContent: 'center', alignSelf: 'center', marginBottom: 12 },
  fabIcon: { color: COLORS.white, fontSize: 28, fontWeight: '900' },
  fabMenu: { gap: 8 },
  fabItem: { padding: 14, backgroundColor: COLORS.medGray, borderRadius: RADIUS.sm },
  fabItemText: { color: COLORS.white, fontSize: 14, fontWeight: '600' },
});
