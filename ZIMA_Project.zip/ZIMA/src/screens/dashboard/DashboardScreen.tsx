// © Carlos Espina Property — Dashboard Principal
import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, Switch, StyleSheet, SafeAreaView } from 'react-native';
import { COLORS, SPACING, RADIUS, SIGNATURE } from '../../constants/theme';
import { useZIMAStore } from '../../store/useZIMAStore';
import { AvatarSIM } from '../../components/avatar/AvatarSIM';
import { FaithWidget } from '../../components/faith/FaithWidget';
import { IPSignature } from '../../components/ui/IPSignature';
import { ZIMAButton } from '../../components/ui/ZIMAButton';
import { SectionLabel } from '../../components/ui/SectionLabel';
import { calcEdadMetabolica, calcBMI } from '../../utils/sim';

export const DashboardScreen: React.FC = () => {
  const {
    idioma, faith, setFaith, biotipo, medidas, volumenCargaSemanal,
    modoCircadiano, zimaFocusActive, setZIMAFocus, bioMonitor, workoutLog
  } = useZIMAStore();
  const [xray, setXray] = useState(false);
  const t = idioma === 'EN';

  const cetonasEntries = bioMonitor.filter(b => b.tipo === 'Cetonas');
  const cetonasPromedio = cetonasEntries.length
    ? cetonasEntries.reduce((a, b) => a + b.valor, 0) / cetonasEntries.length : 0;
  const bmi = calcBMI(medidas.peso || 70, medidas.estatura || 175);
  const edadMet = calcEdadMetabolica(30, cetonasPromedio, volumenCargaSemanal, bmi);
  const muscleLevel = Math.min(5, Math.floor(volumenCargaSemanal / 1000));

  const today = new Date();
  const bgColor = modoCircadiano ? '#0D0000' : COLORS.bg;

  const metrics = [
    { label: t ? 'Ketones' : 'Cetonas', value: cetonasPromedio ? cetonasPromedio.toFixed(1) : '—', unit: 'mmol/L', icon: '🔥' },
    { label: t ? 'Training Vol.' : 'Vol. Entreno', value: volumenCargaSemanal ? volumenCargaSemanal.toString() : '—', unit: 'kg', icon: '💪' },
    { label: t ? 'Metabolic Age' : 'Edad Met.', value: edadMet.toString(), unit: t ? 'yrs' : 'años', icon: '🧬' },
    { label: 'BMI', value: bmi.toString(), unit: '', icon: '📊' },
  ];

  return (
    <SafeAreaView style={[styles.safe, { backgroundColor: bgColor }]}>
      <ScrollView style={styles.scroll} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.logo}>Z I M A</Text>
          <Text style={styles.date}>
            {today.toLocaleDateString(idioma === 'EN' ? 'en-US' : 'es-CL', { weekday: 'short', month: 'short', day: 'numeric' }).toUpperCase()}
          </Text>
        </View>

        {/* ZIMA Faith Widget (Función 15) */}
        <FaithWidget />

        {/* Faith Toggle (Función 2) */}
        <View style={styles.faithToggle}>
          <View>
            <Text style={styles.faithLabel}>ZIMA Faith</Text>
            <Text style={styles.faithSub}>{faith ? (t ? 'Active ✝' : 'Activo ✝') : (t ? 'Disabled' : 'Desactivado')}</Text>
          </View>
          <Switch value={faith} onValueChange={setFaith}
            trackColor={{ false: '#444', true: COLORS.gold }} thumbColor={COLORS.white} />
        </View>

        {/* Avatar SIM (Funciones 5, 6, 41) */}
        <View style={styles.avatarCard}>
          <SectionLabel>{t ? 'SIM AVATAR' : 'AVATAR SIM'}</SectionLabel>
          <View style={{ alignItems: 'center' }}>
            <AvatarSIM biotipo={biotipo} muscleLevel={muscleLevel} faith={faith} xray={xray} />
          </View>
          <View style={styles.avatarControls}>
            <TouchableOpacity onPress={() => setXray(!xray)}
              style={[styles.ctrlBtn, xray && { borderColor: COLORS.green, backgroundColor: 'rgba(0,255,148,0.1)' }]}>
              <Text style={[styles.ctrlText, xray && { color: COLORS.green }]}>🫀 {t ? 'X-Ray' : 'Rayos X'}</Text>
            </TouchableOpacity>
            <View style={styles.ctrlBtn}>
              <Text style={styles.ctrlText}>💪 {t ? 'Lv.' : 'Nv.'}{muscleLevel}/5</Text>
            </View>
          </View>
        </View>

        {/* Metrics Grid */}
        <View style={styles.metricsGrid}>
          {metrics.map((m, i) => (
            <View key={i} style={styles.metricCard}>
              <Text style={styles.metricIcon}>{m.icon}</Text>
              <Text style={styles.metricValue}>{m.value}</Text>
              <Text style={styles.metricUnit}>{m.unit}</Text>
              <Text style={styles.metricLabel}>{m.label.toUpperCase()}</Text>
            </View>
          ))}
        </View>

        {/* ZIMA Focus (Función 39) */}
        <View style={styles.focusCard}>
          <View>
            <Text style={styles.focusLabel}>ZIMA Focus</Text>
            <Text style={styles.focusSub}>
              {t ? 'Block notifications during training' : 'Bloquear notificaciones durante entrenamiento'}
            </Text>
          </View>
          <Switch value={zimaFocusActive} onValueChange={setZIMAFocus}
            trackColor={{ false: '#444', true: COLORS.eliteBlue }} thumbColor={COLORS.white} />
        </View>

        {/* Circadian Mode indicator (Función 42) */}
        {modoCircadiano && (
          <View style={styles.circadian}>
            <Text style={styles.circadianText}>
              🌙 {t ? 'Circadian Mode Active — Melatonin protection ON' : 'Modo Circadiano Activo — Protección melatonina ON'}
            </Text>
          </View>
        )}

        <IPSignature />
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1 },
  scroll: { flex: 1, paddingHorizontal: 24 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 16 },
  logo: { fontSize: 20, fontWeight: '900', letterSpacing: 8, color: COLORS.white },
  date: { fontSize: 11, color: COLORS.eliteBlue, fontWeight: '700', letterSpacing: 1 },
  faithToggle: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, backgroundColor: COLORS.darkGray, borderRadius: RADIUS.md, marginBottom: 12 },
  faithLabel: { fontSize: 14, fontWeight: '700', color: COLORS.white },
  faithSub: { fontSize: 11, color: COLORS.gray, marginTop: 2 },
  avatarCard: { backgroundColor: COLORS.darkGray, borderRadius: RADIUS.lg, padding: 20, marginBottom: 12 },
  avatarControls: { flexDirection: 'row', gap: 10, marginTop: 14 },
  ctrlBtn: { flex: 1, padding: 10, backgroundColor: COLORS.medGray, borderRadius: RADIUS.sm, alignItems: 'center', borderWidth: 1, borderColor: '#333' },
  ctrlText: { color: COLORS.white, fontSize: 12, fontWeight: '700' },
  metricsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 12 },
  metricCard: { width: '47%', backgroundColor: COLORS.darkGray, borderRadius: RADIUS.md, padding: 14 },
  metricIcon: { fontSize: 22, marginBottom: 4 },
  metricValue: { fontSize: 24, fontWeight: '900', color: COLORS.eliteBlue },
  metricUnit: { fontSize: 11, color: COLORS.gray },
  metricLabel: { fontSize: 9, color: COLORS.gray, fontWeight: '700', letterSpacing: 1, marginTop: 2 },
  focusCard: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, backgroundColor: COLORS.darkGray, borderRadius: RADIUS.md, marginBottom: 12 },
  focusLabel: { fontSize: 14, fontWeight: '700', color: COLORS.white },
  focusSub: { fontSize: 11, color: COLORS.gray, marginTop: 2 },
  circadian: { backgroundColor: 'rgba(139,0,0,0.3)', borderRadius: RADIUS.md, padding: 12, marginBottom: 12, borderWidth: 1, borderColor: 'rgba(139,0,0,0.5)' },
  circadianText: { color: '#FF6B6B', fontSize: 12, fontWeight: '600', textAlign: 'center' },
});
