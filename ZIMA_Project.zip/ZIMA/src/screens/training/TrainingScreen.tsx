// © Carlos Espina Property — Fase 3: La Triada (Funciones 17-24)
import React, { useState, useEffect, useRef } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, SafeAreaView, Alert } from 'react-native';
import { COLORS, RADIUS, SPACING } from '../../constants/theme';
import { useZIMAStore, Entorno } from '../../store/useZIMAStore';
import { getExercisesForEntorno, getSwapExercise, Exercise } from '../../constants/exercises';
import { SectionLabel } from '../../components/ui/SectionLabel';
import { ZIMAButton } from '../../components/ui/ZIMAButton';
import { IPSignature } from '../../components/ui/IPSignature';

export const TrainingScreen: React.FC = () => {
  const { entornoActivo, setEntorno, logWorkout, idioma, biotipo } = useZIMAStore();
  const t = idioma === 'EN';
  const [exercises, setExercises] = useState<Exercise[]>(() => getExercisesForEntorno(entornoActivo));
  const [activeSession, setActiveSession] = useState(false);
  const [serieActual, setSerieActual] = useState(1);
  const [timerSecs, setTimerSecs] = useState(25 * 60); // 25 min
  const [timerRunning, setTimerRunning] = useState(false);
  const [volumenTotal, setVolumenTotal] = useState(0);
  const [breathPhase, setBreathPhase] = useState<'inhale' | 'exhale'>('inhale'); // Función 24
  const timerRef = useRef<any>(null);

  useEffect(() => {
    setExercises(getExercisesForEntorno(entornoActivo));
  }, [entornoActivo]);

  useEffect(() => {
    if (timerRunning) {
      timerRef.current = setInterval(() => {
        setTimerSecs(s => {
          if (s <= 1) { clearInterval(timerRef.current); setTimerRunning(false); return 0; }
          return s - 1;
        });
        setBreathPhase(p => p === 'inhale' ? 'exhale' : 'inhale');
      }, 4000); // 4s ciclo respiratorio
    } else {
      clearInterval(timerRef.current);
    }
    return () => clearInterval(timerRef.current);
  }, [timerRunning]);

  const handleSwap = (index: number) => {
    const swap = getSwapExercise(exercises[index].id, entornoActivo);
    if (swap) {
      const updated = [...exercises];
      updated[index] = swap;
      setExercises(updated);
    }
  };

  const finishSerie = () => {
    const vol = exercises.reduce((acc, ex) => acc + ex.duracionSeg * 10, 0);
    setVolumenTotal(v => v + vol);
    setTimerSecs(25 * 60);
    setTimerRunning(false);
    if (serieActual === 3) {
      const session = {
        id: Date.now().toString(),
        fecha: new Date().toISOString(),
        entorno: entornoActivo,
        duracionSerie: 25,
        volumenCargaTotal: volumenTotal + vol,
        ejercicios: exercises.map(e => e.id),
      };
      logWorkout(session);
      setActiveSession(false);
      setSerieActual(1);
      Alert.alert('ZIMA ⚡', t ? 'Session complete! SIM Avatar updated.' : '¡Sesión completa! Avatar SIM actualizado.');
    } else {
      setSerieActual(s => s + 1);
    }
  };

  const mins = Math.floor(timerSecs / 60);
  const secs = timerSecs % 60;
  const ENTORNOS: Entorno[] = ['Casa', 'Barra', 'Gimnasio'];

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView style={styles.scroll} showsVerticalScrollIndicator={false}>
        <SectionLabel>{t ? 'Power-SIM Training' : 'Entrenamiento Power-SIM'}</SectionLabel>
        <Text style={styles.title}>{t ? 'The Triad' : 'La Tríada'}</Text>

        {/* Selector de Entorno (Función 17) */}
        <View style={styles.entornoRow}>
          {ENTORNOS.map(e => (
            <TouchableOpacity key={e} onPress={() => setEntorno(e)}
              style={[styles.entornoBtn, entornoActivo === e && styles.entornoBtnActive]}>
              <Text style={[styles.entornoText, entornoActivo === e && { color: COLORS.white }]}>
                {e === 'Casa' ? '🏠' : e === 'Barra' ? '🏋️' : '💪'} {e}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Power-SIM 3x25 indicator (Función 18) */}
        <View style={styles.serieRow}>
          {[1, 2, 3].map(s => (
            <View key={s} style={[styles.serieDot, s < serieActual && styles.serieDotDone, s === serieActual && styles.serieDotActive]}>
              <Text style={styles.serieDotText}>{s < serieActual ? '✓' : s.toString()}</Text>
            </View>
          ))}
          <Text style={styles.serieLabel}>{t ? 'Serie' : 'Serie'} {serieActual}/3 — 25 {t ? 'min' : 'min'}</Text>
        </View>

        {/* Cronómetro (Función 22) */}
        <View style={styles.timerCard}>
          <Text style={styles.timerLabel}>{t ? 'TENSION TIMER' : 'CRONÓMETRO DE TENSIÓN'}</Text>
          <Text style={styles.timerDisplay}>{String(mins).padStart(2, '0')}:{String(secs).padStart(2, '0')}</Text>
          {/* Metrónomo Respiratorio (Función 24) */}
          {timerRunning && (
            <View style={[styles.breathIndicator, breathPhase === 'inhale' && styles.breathIn]}>
              <Text style={styles.breathText}>{breathPhase === 'inhale' ? (t ? '↓ INHALE' : '↓ INHALAR') : (t ? '↑ EXHALE' : '↑ EXHALAR')}</Text>
            </View>
          )}
          <View style={styles.timerBtns}>
            <TouchableOpacity onPress={() => setTimerRunning(r => !r)}
              style={[styles.timerBtn, { backgroundColor: timerRunning ? COLORS.red : COLORS.eliteBlue }]}>
              <Text style={styles.timerBtnText}>{timerRunning ? (t ? 'PAUSE' : 'PAUSAR') : (t ? 'START' : 'INICIAR')}</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={finishSerie} style={[styles.timerBtn, { backgroundColor: COLORS.medGray }]}>
              <Text style={styles.timerBtnText}>{t ? 'FINISH SERIE' : 'FIN SERIE'}</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* 8 Ejercicios con Swap (Funciones 19, 20, 21) */}
        <Text style={styles.exTitle}>{t ? '8 Core Exercises' : '8 Ejercicios Fundamentales'}</Text>
        {exercises.slice(0, 8).map((ex, i) => (
          <View key={ex.id} style={styles.exCard}>
            <View style={styles.exRow}>
              <View style={styles.exNum}><Text style={styles.exNumText}>{i + 1}</Text></View>
              <View style={styles.exInfo}>
                <Text style={styles.exName}>{ex.nombre}</Text>
                <Text style={styles.exMuscle}>{ex.musculosPrincipales.join(' · ')}</Text>
                <Text style={styles.exDesc}>{ex.descripcion}</Text>
              </View>
              <TouchableOpacity onPress={() => handleSwap(i)} style={styles.swapBtn}>
                <Text style={styles.swapText}>↕</Text>
              </TouchableOpacity>
            </View>
          </View>
        ))}

        <IPSignature />
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.bg },
  scroll: { flex: 1, paddingHorizontal: 24 },
  title: { fontSize: 28, fontWeight: '900', color: COLORS.white, marginBottom: 20 },
  entornoRow: { flexDirection: 'row', gap: 8, marginBottom: 20 },
  entornoBtn: { flex: 1, padding: 12, borderRadius: RADIUS.sm, borderWidth: 1, borderColor: '#333', backgroundColor: COLORS.darkGray, alignItems: 'center' },
  entornoBtnActive: { borderColor: COLORS.eliteBlue, backgroundColor: 'rgba(0,112,255,0.15)' },
  entornoText: { color: COLORS.gray, fontSize: 12, fontWeight: '700' },
  serieRow: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 20 },
  serieDot: { width: 36, height: 36, borderRadius: 18, backgroundColor: COLORS.darkGray, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: '#333' },
  serieDotActive: { borderColor: COLORS.eliteBlue, backgroundColor: 'rgba(0,112,255,0.2)' },
  serieDotDone: { backgroundColor: COLORS.eliteBlue },
  serieDotText: { color: COLORS.white, fontWeight: '900', fontSize: 14 },
  serieLabel: { color: COLORS.gray, fontSize: 13, fontWeight: '600' },
  timerCard: { backgroundColor: COLORS.darkGray, borderRadius: RADIUS.lg, padding: 24, marginBottom: 20, alignItems: 'center' },
  timerLabel: { fontSize: 10, fontWeight: '700', letterSpacing: 2, color: COLORS.eliteBlue, marginBottom: 8 },
  timerDisplay: { fontSize: 64, fontWeight: '900', color: COLORS.white, letterSpacing: 4, marginBottom: 12 },
  breathIndicator: { paddingHorizontal: 20, paddingVertical: 8, borderRadius: RADIUS.full, borderWidth: 1, borderColor: COLORS.gray, marginBottom: 16 },
  breathIn: { borderColor: COLORS.eliteBlue, backgroundColor: 'rgba(0,112,255,0.15)' },
  breathText: { color: COLORS.white, fontWeight: '700', fontSize: 13 },
  timerBtns: { flexDirection: 'row', gap: 10, width: '100%' },
  timerBtn: { flex: 1, padding: 14, borderRadius: RADIUS.md, alignItems: 'center' },
  timerBtnText: { color: COLORS.white, fontWeight: '700', fontSize: 14 },
  exTitle: { fontSize: 16, fontWeight: '800', color: COLORS.white, marginBottom: 12 },
  exCard: { backgroundColor: COLORS.darkGray, borderRadius: RADIUS.md, padding: 16, marginBottom: 10, borderWidth: 1, borderColor: '#222' },
  exRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 12 },
  exNum: { width: 28, height: 28, borderRadius: 14, backgroundColor: COLORS.eliteBlue, alignItems: 'center', justifyContent: 'center' },
  exNumText: { color: COLORS.white, fontWeight: '900', fontSize: 12 },
  exInfo: { flex: 1 },
  exName: { fontSize: 15, fontWeight: '700', color: COLORS.white },
  exMuscle: { fontSize: 11, color: COLORS.eliteBlue, fontWeight: '600', marginTop: 2 },
  exDesc: { fontSize: 11, color: COLORS.gray, marginTop: 4, lineHeight: 16 },
  swapBtn: { width: 36, height: 36, borderRadius: RADIUS.sm, backgroundColor: COLORS.medGray, alignItems: 'center', justifyContent: 'center' },
  swapText: { color: COLORS.white, fontSize: 18, fontWeight: '700' },
});
