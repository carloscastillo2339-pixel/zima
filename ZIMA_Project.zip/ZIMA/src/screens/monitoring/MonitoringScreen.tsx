// © Carlos Espina Property — Fase 5: Monitoreo Avanzado (Funciones 33-40)
import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, TextInput, Switch, StyleSheet, SafeAreaView, Alert } from 'react-native';
import { COLORS, RADIUS, SPACING } from '../../constants/theme';
import { useZIMAStore } from '../../store/useZIMAStore';
import { SectionLabel } from '../../components/ui/SectionLabel';
import { ZIMAButton } from '../../components/ui/ZIMAButton';
import { IPSignature } from '../../components/ui/IPSignature';
import { AvatarSIM } from '../../components/avatar/AvatarSIM';
import { calcImpactoRuptura, calcEdadMetabolica, calcBMI } from '../../utils/sim';

type Tab = 'sleep' | 'ketones' | 'ruptura' | 'edad' | 'run';

export const MonitoringScreen: React.FC = () => {
  const { idioma, biotipo, modoSueno, setModoSueno, bioMonitor, addBioMonitor, medidas, volumenCargaSemanal } = useZIMAStore();
  const t = idioma === 'EN';
  const [tab, setTab] = useState<Tab>('ketones');
  const [ketonaVal, setKetonaVal] = useState('');
  const [rupturaCarbos, setRupturaCarbos] = useState('');
  const [rupturaResult, setRupturaResult] = useState<any>(null);

  const logKetona = () => {
    const val = parseFloat(ketonaVal);
    if (!val) return;
    addBioMonitor({ id: Date.now().toString(), tipo: 'Cetonas', valor: val, horaInicio: new Date().toISOString() });
    setKetonaVal('');
    Alert.alert('ZIMA 🔥', t ? `Ketone level ${val} mmol/L registered.` : `Nivel cetónico ${val} mmol/L registrado.`);
  };

  const runRuptura = () => {
    const carbos = parseFloat(rupturaCarbos) || 50;
    const result = calcImpactoRuptura(carbos, biotipo);
    setRupturaResult(result);
  };

  const cetonasEntries = bioMonitor.filter(b => b.tipo === 'Cetonas');
  const cetonasPromedio = cetonasEntries.length
    ? cetonasEntries.reduce((a, b) => a + b.valor, 0) / cetonasEntries.length : 0;
  const bmi = calcBMI(medidas.peso || 70, medidas.estatura || 175);
  const edadMet = calcEdadMetabolica(30, cetonasPromedio, volumenCargaSemanal, bmi);

  const TABS = [
    { id: 'ketones', label: '🔥' },
    { id: 'sleep',   label: '😴' },
    { id: 'ruptura', label: '⚠️' },
    { id: 'edad',    label: '🧬' },
    { id: 'run',     label: '🏃' },
  ];

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView style={styles.scroll} showsVerticalScrollIndicator={false}>
        <SectionLabel>{t ? 'Advanced Monitoring' : 'Monitoreo Avanzado'}</SectionLabel>
        <View style={styles.tabs}>
          {TABS.map(tb => (
            <TouchableOpacity key={tb.id} onPress={() => setTab(tb.id as Tab)}
              style={[styles.tab, tab === tb.id && styles.tabActive]}>
              <Text style={styles.tabText}>{tb.label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* CETONAS (Función 32) */}
        {tab === 'ketones' && (
          <View>
            <Text style={styles.secTitle}>{t ? 'Ketone Check-up' : 'Check-up de Cetonas'}</Text>
            <Text style={styles.secSub}>{t ? 'Register blood ketones (mmol/L) weekly.' : 'Registra cetonas en sangre (mmol/L) semanalmente.'}</Text>
            <View style={styles.inputRow}>
              <TextInput value={ketonaVal} onChangeText={setKetonaVal} keyboardType="numeric"
                placeholder="1.5" placeholderTextColor={COLORS.grayDark}
                style={[styles.input, { flex: 1 }]} />
              <Text style={styles.unit}>mmol/L</Text>
            </View>
            <ZIMAButton label={t ? '+ Log Ketones' : '+ Registrar Cetonas'} onPress={logKetona} />
            <View style={styles.statsRow}>
              <View style={styles.statBox}>
                <Text style={styles.statVal}>{cetonasPromedio.toFixed(1)}</Text>
                <Text style={styles.statLabel}>{t ? 'Average' : 'Promedio'}</Text>
              </View>
              <View style={styles.statBox}>
                <Text style={styles.statVal}>{cetonasEntries.length}</Text>
                <Text style={styles.statLabel}>{t ? 'Records' : 'Registros'}</Text>
              </View>
              <View style={styles.statBox}>
                <Text style={[styles.statVal, { color: cetonasPromedio >= 0.5 ? COLORS.eliteBlue : COLORS.red }]}>
                  {cetonasPromedio >= 1.5 ? (t ? 'DEEP' : 'PROFUNDA') : cetonasPromedio >= 0.5 ? (t ? 'LIGHT' : 'LEVE') : (t ? 'NONE' : 'NINGUNA')}
                </Text>
                <Text style={styles.statLabel}>{t ? 'Ketosis' : 'Cetosis'}</Text>
              </View>
            </View>
          </View>
        )}

        {/* SUEÑO (Funciones 33-34) */}
        {tab === 'sleep' && (
          <View>
            <Text style={styles.secTitle}>{t ? 'Sleep Ritual' : 'Ritual de Sueño'}</Text>
            <Text style={styles.secSub}>{t ? 'Activate manually when going to sleep. Audio processed locally — deleted after report.' : 'Activa manualmente al acostarte. Audio procesado localmente — eliminado tras el reporte.'}</Text>
            <View style={styles.sleepToggle}>
              <View>
                <Text style={styles.sleepLabel}>{modoSueno ? (t ? 'Monitoring ON 🌙' : 'Monitoreando ON 🌙') : (t ? 'Ready to activate' : 'Listo para activar')}</Text>
                <Text style={styles.sleepSub}>{t ? 'Edge computing — 100% local privacy' : 'Edge computing — Privacidad 100% local'}</Text>
              </View>
              <Switch value={modoSueno} onValueChange={setModoSueno}
                trackColor={{ false: '#444', true: COLORS.eliteBlue }} thumbColor={COLORS.white} />
            </View>
            <View style={styles.privacyNote}>
              <Text style={styles.privacyText}>🔒 {t ? 'Audio data is never stored. Processed on-device and deleted after report generation.' : 'Los datos de audio nunca se almacenan. Procesados en el dispositivo y eliminados tras generar el reporte.'}</Text>
            </View>
          </View>
        )}

        {/* SIMULADOR DE RUPTURA (Función 37) */}
        {tab === 'ruptura' && (
          <View>
            <Text style={styles.secTitle}>{t ? 'Break Simulator' : 'Simulador de Ruptura'}</Text>
            <Text style={styles.secSub}>{t ? 'Visualize how a cheat meal affects your progress.' : 'Visualiza cómo un alimento prohibido afecta tu progreso.'}</Text>
            <View style={styles.inputRow}>
              <TextInput value={rupturaCarbos} onChangeText={setRupturaCarbos} keyboardType="numeric"
                placeholder="50" placeholderTextColor={COLORS.grayDark}
                style={[styles.input, { flex: 1 }]} />
              <Text style={styles.unit}>g {t ? 'carbs' : 'carbos'}</Text>
            </View>
            <ZIMAButton label={t ? '⚡ Simulate Impact' : '⚡ Simular Impacto'} onPress={runRuptura} />
            {rupturaResult && (
              <View>
                <View style={[styles.statBox, { width: '100%', marginTop: 16 }]}>
                  <Text style={[styles.statVal, { color: COLORS.red }]}>{rupturaResult.perdidaDefinicion.toFixed(0)}%</Text>
                  <Text style={styles.statLabel}>{t ? 'Definition Loss' : 'Pérdida Definición'}</Text>
                </View>
                <View style={styles.statsRow}>
                  <View style={styles.statBox}>
                    <Text style={styles.statVal}>{rupturaResult.tiempoRecuperacion}d</Text>
                    <Text style={styles.statLabel}>{t ? 'Recovery' : 'Recuperación'}</Text>
                  </View>
                  <View style={styles.statBox}>
                    <Text style={styles.statVal}>{rupturaResult.impactoEnergia.toFixed(0)}%</Text>
                    <Text style={styles.statLabel}>{t ? 'Energy Impact' : 'Impacto Energía'}</Text>
                  </View>
                </View>
                <View style={styles.rescueCard}>
                  <Text style={styles.rescueTitle}>🛡 {t ? 'Rescue Protocol' : 'Protocolo de Rescate'}</Text>
                  <Text style={styles.rescueText}>{t ? '1. 24h intermittent fasting
2. Electrolytes + water
3. High intensity cardio
4. Resume ketogenic diet' : '1. Ayuno intermitente 24h
2. Electrolitos + agua
3. Cardio de alta intensidad
4. Retomar dieta cetogénica'}</Text>
                </View>
              </View>
            )}
          </View>
        )}

        {/* EDAD METABÓLICA (Función 38) */}
        {tab === 'edad' && (
          <View>
            <Text style={styles.secTitle}>{t ? 'Metabolic Age' : 'Edad Metabólica Final'}</Text>
            <View style={styles.edadCard}>
              <Text style={styles.edadLabel}>{t ? 'METABOLIC AGE' : 'EDAD METABÓLICA'}</Text>
              <Text style={styles.edadVal}>{edadMet}</Text>
              <Text style={styles.edadUnit}>{t ? 'years' : 'años'}</Text>
              <Text style={styles.edadNote}>{t ? 'Based on ketones, training volume, and BMI data.' : 'Basado en cetonas, volumen de entrenamiento y BMI.'}</Text>
            </View>
            <View style={{ alignItems: 'center' }}>
              <AvatarSIM biotipo={biotipo} muscleLevel={Math.min(5, Math.floor(volumenCargaSemanal / 1000))} />
            </View>
          </View>
        )}

        {/* ZIMA RUN GPS (Función 36) */}
        {tab === 'run' && (
          <View>
            <Text style={styles.secTitle}>ZIMA-Run GPS</Text>
            <Text style={styles.secSub}>{t ? 'Route mapping with automatic return calculation.' : 'Mapeo de rutas con cálculo automático de retorno.'}</Text>
            <View style={styles.mapPlaceholder}>
              <Text style={{ fontSize: 48 }}>🗺</Text>
              <Text style={{ color: COLORS.gray, marginTop: 8, textAlign: 'center', fontSize: 13 }}>
                {t ? 'GPS module — Enable location permission
Route tracking + return path calculation' : 'Módulo GPS — Habilitar permiso de ubicación
Rastreo de ruta + cálculo de retorno'}
              </Text>
            </View>
            <ZIMAButton label={t ? '📍 Start Run' : '📍 Iniciar Trote'} onPress={() => Alert.alert('ZIMA-Run', t ? 'Enable location permission in device settings.' : 'Habilita el permiso de ubicación en los ajustes del dispositivo.')} />
          </View>
        )}

        <IPSignature />
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.bg },
  scroll: { flex: 1, paddingHorizontal: 24 },
  tabs: { flexDirection: 'row', gap: 8, marginBottom: 20 },
  tab: { flex: 1, padding: 12, borderRadius: RADIUS.sm, backgroundColor: COLORS.darkGray, alignItems: 'center', borderWidth: 1, borderColor: '#333' },
  tabActive: { borderColor: COLORS.eliteBlue, backgroundColor: 'rgba(0,112,255,0.15)' },
  tabText: { fontSize: 18 },
  secTitle: { fontSize: 20, fontWeight: '800', color: COLORS.white, marginBottom: 6 },
  secSub: { fontSize: 12, color: COLORS.gray, marginBottom: 16, lineHeight: 18 },
  inputRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 14 },
  input: { backgroundColor: COLORS.darkGray, borderRadius: RADIUS.sm, padding: 14, color: COLORS.white, fontSize: 18, fontWeight: '700', borderWidth: 1, borderColor: '#2A2A2A' },
  unit: { color: COLORS.eliteBlue, fontWeight: '700', fontSize: 13 },
  statsRow: { flexDirection: 'row', gap: 10, marginTop: 16 },
  statBox: { flex: 1, backgroundColor: COLORS.darkGray, borderRadius: RADIUS.md, padding: 16, alignItems: 'center' },
  statVal: { fontSize: 22, fontWeight: '900', color: COLORS.eliteBlue },
  statLabel: { fontSize: 10, color: COLORS.gray, fontWeight: '700', letterSpacing: 1, marginTop: 4 },
  sleepToggle: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 18, backgroundColor: COLORS.darkGray, borderRadius: RADIUS.md, marginBottom: 12 },
  sleepLabel: { fontSize: 15, fontWeight: '700', color: COLORS.white },
  sleepSub: { fontSize: 11, color: COLORS.gray, marginTop: 2 },
  privacyNote: { backgroundColor: 'rgba(0,112,255,0.08)', borderRadius: RADIUS.md, padding: 14, borderWidth: 1, borderColor: 'rgba(0,112,255,0.2)' },
  privacyText: { color: COLORS.gray, fontSize: 12, lineHeight: 18 },
  rescueCard: { backgroundColor: 'rgba(0,112,255,0.1)', borderRadius: RADIUS.md, padding: 16, marginTop: 16, borderWidth: 1, borderColor: 'rgba(0,112,255,0.3)' },
  rescueTitle: { color: COLORS.eliteBlue, fontWeight: '800', fontSize: 14, marginBottom: 8 },
  rescueText: { color: COLORS.gray, fontSize: 13, lineHeight: 22 },
  edadCard: { backgroundColor: COLORS.darkGray, borderRadius: RADIUS.lg, padding: 32, alignItems: 'center', marginBottom: 20 },
  edadLabel: { fontSize: 11, color: COLORS.eliteBlue, fontWeight: '700', letterSpacing: 2, marginBottom: 8 },
  edadVal: { fontSize: 72, fontWeight: '900', color: COLORS.white },
  edadUnit: { fontSize: 16, color: COLORS.gray, fontWeight: '600' },
  edadNote: { fontSize: 11, color: COLORS.gray, textAlign: 'center', marginTop: 12, lineHeight: 18 },
  mapPlaceholder: { backgroundColor: COLORS.darkGray, borderRadius: RADIUS.lg, height: 200, alignItems: 'center', justifyContent: 'center', marginBottom: 16 },
});
