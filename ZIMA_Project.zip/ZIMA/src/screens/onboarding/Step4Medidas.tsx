// © Carlos Espina Property — Paso 4: Carga Antropométrica (Función 4)
import React from 'react';
import { View, Text, TextInput, ScrollView, StyleSheet } from 'react-native';
import { COLORS, RADIUS, SPACING } from '../../constants/theme';
import { useZIMAStore } from '../../store/useZIMAStore';
import { ZIMAButton } from '../../components/ui/ZIMAButton';
import { SectionLabel } from '../../components/ui/SectionLabel';

interface Props { onNext: () => void; onBack: () => void; }

export const Step4Medidas: React.FC<Props> = ({ onNext, onBack }) => {
  const { idioma, medidas, setMedidas } = useZIMAStore();
  const t = idioma === 'EN';
  const isMetric = idioma === 'ES';

  const fields = [
    { key: 'peso',     label: t ? 'Weight'  : 'Peso',     unit: isMetric ? 'kg' : 'lb', ph: isMetric ? '75' : '165' },
    { key: 'estatura', label: t ? 'Height'  : 'Estatura', unit: isMetric ? 'cm' : 'in', ph: isMetric ? '175' : '69' },
    { key: 'cuello',   label: t ? 'Neck'    : 'Cuello',   unit: isMetric ? 'cm' : 'in', ph: isMetric ? '38' : '15' },
    { key: 'cintura',  label: t ? 'Waist'   : 'Cintura',  unit: isMetric ? 'cm' : 'in', ph: isMetric ? '85' : '33' },
    { key: 'brazo',    label: t ? 'Arm'     : 'Brazo',    unit: isMetric ? 'cm' : 'in', ph: isMetric ? '35' : '14' },
    { key: 'pierna',   label: t ? 'Leg'     : 'Pierna',   unit: isMetric ? 'cm' : 'in', ph: isMetric ? '55' : '22' },
  ];

  const update = (key: string, val: string) =>
    setMedidas({ ...medidas, [key]: parseFloat(val) || 0 });

  return (
    <ScrollView style={{ flex: 1 }} showsVerticalScrollIndicator={false}>
      <SectionLabel>{t ? 'Anthropometric Load' : 'Carga Antropométrica'}</SectionLabel>
      <Text style={styles.title}>{t ? 'Your Measurements' : 'Tus Medidas'}</Text>
      <Text style={styles.desc}>{t ? 'These will generate your 3D SIM Avatar.' : 'Estas medidas generarán tu Avatar 3D SIM.'}</Text>
      <View style={styles.grid}>
        {fields.map(f => (
          <View key={f.key} style={styles.field}>
            <Text style={styles.fieldLabel}>{f.label.toUpperCase()}</Text>
            <View style={styles.inputRow}>
              <TextInput
                keyboardType="numeric"
                placeholder={f.ph}
                placeholderTextColor={COLORS.grayDark}
                value={medidas[f.key as keyof typeof medidas]?.toString() || ''}
                onChangeText={v => update(f.key, v)}
                style={styles.input}
              />
              <Text style={styles.unit}>{f.unit}</Text>
            </View>
          </View>
        ))}
      </View>
      <View style={styles.buttons}>
        <ZIMAButton label={t ? '← Back' : '← Atrás'} onPress={onBack} variant="outline" style={{ flex: 0.4 }} />
        <ZIMAButton label={t ? 'Continue →' : 'Continuar →'} onPress={onNext} style={{ flex: 1 }} />
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  title: { fontSize: 22, fontWeight: '800', color: COLORS.white, marginBottom: 6 },
  desc: { fontSize: 13, color: COLORS.gray, marginBottom: 20 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  field: { width: '47%' },
  fieldLabel: { fontSize: 10, color: COLORS.gray, fontWeight: '700', letterSpacing: 1, marginBottom: 6 },
  inputRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.darkGray, borderRadius: RADIUS.sm, borderWidth: 1, borderColor: '#2A2A2A', overflow: 'hidden' },
  input: { flex: 1, color: COLORS.white, fontSize: 18, fontWeight: '700', padding: 12 },
  unit: { paddingHorizontal: 10, color: COLORS.eliteBlue, fontSize: 12, fontWeight: '700' },
  buttons: { flexDirection: 'row', gap: 10, marginTop: 24, marginBottom: 40 },
});
