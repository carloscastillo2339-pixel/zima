// © Carlos Espina Property — Onboarding 8 Pasos
import React, { useState } from 'react';
import { View, StyleSheet, SafeAreaView } from 'react-native';
import { COLORS } from '../../constants/theme';
import { useZIMAStore } from '../../store/useZIMAStore';
import { Step1Language } from './Step1Language';
import { Step2Faith } from './Step2Faith';
import { Step3Biotipo } from './Step3Biotipo';
import { Step4Medidas } from './Step4Medidas';
import { Step5Avatar } from './Step5Avatar';
import { Step6Inmersion } from './Step6Inmersion';
import { Step7Confirmacion } from './Step7Confirmacion';
import { ProgressBar } from '../../components/ui/ProgressBar';

const TOTAL = 7;

export const OnboardingNavigator: React.FC = () => {
  const [step, setStep] = useState(1);
  const completeOnboarding = useZIMAStore(s => s.completeOnboarding);

  const next = () => { if (step < TOTAL) setStep(s => s + 1); else completeOnboarding(); };
  const back = () => setStep(s => Math.max(1, s - 1));

  const renderStep = () => {
    switch (step) {
      case 1: return <Step1Language onNext={next} />;
      case 2: return <Step2Faith onNext={next} onBack={back} />;
      case 3: return <Step3Biotipo onNext={next} onBack={back} />;
      case 4: return <Step4Medidas onNext={next} onBack={back} />;
      case 5: return <Step5Avatar onNext={next} onBack={back} />;
      case 6: return <Step6Inmersion onNext={next} onBack={back} />;
      case 7: return <Step7Confirmacion onFinish={completeOnboarding} onBack={back} />;
      default: return null;
    }
  };

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.container}>
        <ProgressBar step={step} total={TOTAL} />
        {renderStep()}
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.bg },
  container: { flex: 1, paddingHorizontal: 24, paddingTop: 20 },
});
