// © Carlos Espina Property — Paso 5: Motor de Renderizado SIM (Función 5)
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { COLORS, SPACING } from '../../constants/theme';
import { useZIMAStore } from '../../store/useZIMAStore';
import { AvatarSIM } from '../../components/avatar/AvatarSIM';
import { ZIMAButton } from '../../components/ui/ZIMAButton';
import { SectionLabel } from '../../components/ui/SectionLabel';
import { calcBMI } from '../../utils/sim';

interface Props { onNext: () => void; onBack: () => void; }

export const Step5Avatar: React.FC<Props> = ({ onNext, onBack }) => {
  const { biotipo, medidas, faith, idioma } = useZIMAStore();
  const t = idioma === 'EN';
  const bmi = calcBMI(medidas.peso || 0, medidas.estatura || 175);
  return (
    <View style={styles.container}>
      <SectionLabel>{t ? 'SIM Rendering Engine' : 'Motor de Renderizado SIM'}</SectionLabel>
      <Text style={styles.title}>{t ? 'Your Digital Avatar' : 'Tu Avatar Digital'}</Text>
      <View style={{ alignItems: 'center', marginBottom: 20 }}>
        <AvatarSIM biotipo={biotipo} faith={faith} muscleLevel={0} />
      </View>
      <View style={styles.stats}>
        {[
          { label: t ? 'Biotype' : 'Biotipo', value: biotipo },
          { label: 'BMI', value: bmi.toString() },
          { label: t ? 'Status' : 'Estado', value: 'Elite Stealth' },
          { label: t ? 'Faith' : 'Fe', value: faith ? '✝ ON' : 'OFF' },
        ].map((s, i) => (
          <View key={i} style={styles.stat}>
            <Text style={styles.statLabel}>{s.label.toUpperCase()}</Text>
            <Text style={styles.statValue}>{s.value}</Text>
          </View>
        ))}
      </View>
      <View style={styles.buttons}>
        <ZIMAButton label={t ? '← Back' : '← Atrás'} onPress={onBack} variant="outline" style={{ flex: 0.4 }} />
        <ZIMAButton label={t ? 'Continue →' : 'Continuar →'} onPress={onNext} style={{ flex: 1 }} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1 },
  title: { fontSize: 22, fontWeight: '800', color: COLORS.white, marginBottom: 20 },
  stats: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 24 },
  stat: { flex: 1, minWidth: '45%', backgroundColor: COLORS.darkGray, borderRadius: 10, padding: 14 },
  statLabel: { fontSize: 9, color: COLORS.gray, fontWeight: '700', letterSpacing: 1 },
  statValue: { fontSize: 15, fontWeight: '900', color: COLORS.eliteBlue, marginTop: 4 },
  buttons: { flexDirection: 'row', gap: 10 },
});
