// © Carlos Espina Property — Paso 7: Confirmación (Función 8: Anti-Error)
import React from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';
import { COLORS, RADIUS, SPACING } from '../../constants/theme';
import { useZIMAStore } from '../../store/useZIMAStore';
import { ZIMAButton } from '../../components/ui/ZIMAButton';
import { IPSignature } from '../../components/ui/IPSignature';

interface Props { onFinish: () => void; onBack: () => void; }

export const Step7Confirmacion: React.FC<Props> = ({ onFinish, onBack }) => {
  const { idioma, faith, biotipo, medidas } = useZIMAStore();
  const t = idioma === 'EN';

  const checks = t ? [
    'Language & units configured',
    'Spiritual module: ' + (faith ? 'ACTIVE ✝' : 'Deactivated'),
    'Biotype: ' + biotipo,
    'Anthropometric measurements loaded',
    'SIM Avatar generated',
    'Ancestral immersion complete',
  ] : [
    'Idioma y unidades configurados',
    'Módulo espiritual: ' + (faith ? 'ACTIVO ✝' : 'Desactivado'),
    'Biotipo: ' + biotipo,
    'Medidas antropométricas cargadas',
    'Avatar SIM generado',
    'Inmersión ancestral completada',
  ];

  return (
    <ScrollView style={{ flex: 1 }} showsVerticalScrollIndicator={false}>
      <View style={{ alignItems: 'center', paddingVertical: 30 }}>
        <Text style={{ fontSize: 56 }}>⚡</Text>
        <Text style={styles.title}>{t ? 'ZIMA Core — Ready' : 'ZIMA Core — Listo'}</Text>
        <Text style={styles.sub}>{t ? 'Step 1 complete. SIM Engine initialized.' : 'Paso 1 completo. Motor SIM inicializado.'}</Text>
      </View>
      {checks.map((c, i) => (
        <View key={i} style={styles.check}>
          <View style={styles.checkIcon}><Text style={{ color: COLORS.white, fontSize: 11, fontWeight: '900' }}>✓</Text></View>
          <Text style={styles.checkText}>{c}</Text>
        </View>
      ))}
      <IPSignature />
      <View style={styles.buttons}>
        <ZIMAButton label={t ? '← Back' : '← Atrás'} onPress={onBack} variant="outline" style={{ flex: 0.4 }} />
        <ZIMAButton label={t ? 'Launch ZIMA 🚀' : 'Lanzar ZIMA 🚀'} onPress={onFinish} style={{ flex: 1 }} />
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  title: { fontSize: 24, fontWeight: '900', color: COLORS.eliteBlue, marginTop: 10 },
  sub: { fontSize: 13, color: COLORS.gray, marginTop: 6 },
  check: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 14, backgroundColor: COLORS.darkGray, borderRadius: RADIUS.md, marginBottom: 8 },
  checkIcon: { width: 24, height: 24, borderRadius: 12, backgroundColor: COLORS.eliteBlue, alignItems: 'center', justifyContent: 'center' },
  checkText: { fontSize: 13, fontWeight: '600', color: COLORS.white, flex: 1 },
  buttons: { flexDirection: 'row', gap: 10, marginTop: 20, marginBottom: 40 },
});
