// © Carlos Espina Property — Paso 1: Selector de Idioma (Función 1)
import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image } from 'react-native';
import { COLORS, SPACING, RADIUS } from '../../constants/theme';
import { useZIMAStore } from '../../store/useZIMAStore';
import { ZIMAButton } from '../../components/ui/ZIMAButton';
import { SectionLabel } from '../../components/ui/SectionLabel';

interface Props { onNext: () => void; }

export const Step1Language: React.FC<Props> = ({ onNext }) => {
  const { idioma, setIdioma } = useZIMAStore();

  const options = [
    { id: 'ES', flag: '🇪🇸', label: 'Español', sub: 'Unidades: kg / cm' },
    { id: 'EN', flag: '🇺🇸', label: 'English', sub: 'Units: lb / in' },
  ];

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.logo}>Z I M A</Text>
        <Text style={styles.subtitle}>Bio-Optimización Cetogénica{`\n`}de Última Generación</Text>
      </View>
      <SectionLabel>Selecciona tu idioma / Select language</SectionLabel>
      {options.map(opt => (
        <TouchableOpacity key={opt.id} onPress={() => setIdioma(opt.id as any)}
          style={[styles.option, idioma === opt.id && styles.optionSelected]}>
          <Text style={styles.flag}>{opt.flag}</Text>
          <View>
            <Text style={styles.optLabel}>{opt.label}</Text>
            <Text style={styles.optSub}>{opt.sub}</Text>
          </View>
          {idioma === opt.id && <View style={styles.check}><Text style={{ color: COLORS.white, fontSize: 10, fontWeight: '900' }}>✓</Text></View>}
        </TouchableOpacity>
      ))}
      <ZIMAButton label={idioma === 'EN' ? 'Continue →' : 'Continuar →'} onPress={onNext} style={styles.btn} />
      <Text style={styles.sig}>© Carlos Espina Property</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { alignItems: 'center', paddingVertical: 40 },
  logo: { fontSize: 36, fontWeight: '900', letterSpacing: 12, color: COLORS.white },
  subtitle: { marginTop: 10, color: COLORS.gray, fontSize: 13, textAlign: 'center', lineHeight: 20 },
  option: { flexDirection: 'row', alignItems: 'center', gap: 14, padding: 18, borderRadius: RADIUS.md, borderWidth: 1, borderColor: '#333', backgroundColor: COLORS.darkGray, marginBottom: 10 },
  optionSelected: { borderColor: COLORS.eliteBlue, backgroundColor: 'rgba(0,112,255,0.12)' },
  flag: { fontSize: 28 },
  optLabel: { fontSize: 16, fontWeight: '700', color: COLORS.white },
  optSub: { fontSize: 12, color: COLORS.gray, marginTop: 2 },
  check: { marginLeft: 'auto', width: 22, height: 22, borderRadius: 11, backgroundColor: COLORS.eliteBlue, alignItems: 'center', justifyContent: 'center' },
  btn: { marginTop: 30 },
  sig: { textAlign: 'center', color: '#333', fontSize: 9, marginTop: 16 },
});
