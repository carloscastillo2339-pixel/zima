// © Carlos Espina Property — Paso 6: Inmersión Ancestral (Función 7)
import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { COLORS, RADIUS } from '../../constants/theme';
import { useZIMAStore } from '../../store/useZIMAStore';
import { ZIMAButton } from '../../components/ui/ZIMAButton';
import { SectionLabel } from '../../components/ui/SectionLabel';

interface Props { onNext: () => void; onBack: () => void; }

const SLIDES_ES = [
  { icon: '🦴', title: 'Orígenes de la Cetosis', body: 'Hace 2.5 millones de años, el cerebro humano evolucionó alimentado principalmente por cuerpos cetónicos. Este es nuestro estado metabólico natural.' },
  { icon: '🔬', title: 'Metabolismo Cetogénico', body: 'Ante la ausencia de carbohidratos, el hígado convierte ácidos grasos en cetonas (BHB, AcAc), proveyendo energía limpia y sostenida para el cerebro y músculos.' },
  { icon: '⚡', title: 'Potencia Mitocondrial', body: 'Las cetonas generan más ATP por molécula que la glucosa. Tu cerebro, corazón y músculos operan con eficiencia superior en estado cetogénico.' },
  { icon: '🌿', title: 'Inflamación Ancestral', body: 'Nuestros ancestros no consumían aceites de semilla ni azúcares refinados. Retornar a este estado revierte la inflamación sistémica crónica.' },
  { icon: '🧬', title: 'Adaptación Genética', body: 'Los genes PPAR-alpha y AMPK se activan en el estado cetogénico, optimizando la longevidad, la regeneración celular y el rendimiento cognitivo.' },
];

const SLIDES_EN = [
  { icon: '🦴', title: 'Origins of Ketosis', body: '2.5 million years ago, the human brain evolved powered primarily by ketone bodies. This is our natural metabolic state.' },
  { icon: '🔬', title: 'Ketogenic Metabolism', body: 'Without carbohydrates, the liver converts fatty acids into ketones (BHB, AcAc), providing clean and sustained energy for brain and muscles.' },
  { icon: '⚡', title: 'Mitochondrial Power', body: 'Ketones generate more ATP per molecule than glucose. Your brain, heart and muscles operate with superior efficiency in ketosis.' },
  { icon: '🌿', title: 'Ancestral Inflammation', body: 'Our ancestors consumed no seed oils or refined sugars. Returning to this state reverses chronic systemic inflammation.' },
  { icon: '🧬', title: 'Genetic Adaptation', body: 'PPAR-alpha and AMPK genes activate in the ketogenic state, optimizing longevity, cellular regeneration and cognitive performance.' },
];

export const Step6Inmersion: React.FC<Props> = ({ onNext, onBack }) => {
  const { idioma } = useZIMAStore();
  const [slide, setSlide] = useState(0);
  const t = idioma === 'EN';
  const slides = t ? SLIDES_EN : SLIDES_ES;

  return (
    <View style={styles.container}>
      <SectionLabel>{t ? 'Ancestral Immersion' : 'Inmersión Ancestral'}</SectionLabel>
      <Text style={styles.title}>{t ? 'The Science of ZIMA' : 'La Ciencia de ZIMA'}</Text>
      <View style={styles.card}>
        <Text style={styles.icon}>{slides[slide].icon}</Text>
        <Text style={styles.slideTitle}>{slides[slide].title}</Text>
        <Text style={styles.slideBody}>{slides[slide].body}</Text>
      </View>
      <View style={styles.navRow}>
        <TouchableOpacity onPress={() => setSlide(s => Math.max(0, s - 1))} disabled={slide === 0}
          style={[styles.navBtn, slide === 0 && styles.navBtnDisabled]}>
          <Text style={styles.navArrow}>←</Text>
        </TouchableOpacity>
        <View style={styles.dots}>
          {slides.map((_, i) => (
            <TouchableOpacity key={i} onPress={() => setSlide(i)}
              style={[styles.dot, i === slide && styles.dotActive]} />
          ))}
        </View>
        <TouchableOpacity onPress={() => setSlide(s => Math.min(slides.length - 1, s + 1))} disabled={slide === slides.length - 1}
          style={[styles.navBtn, slide === slides.length - 1 && styles.navBtnDisabled]}>
          <Text style={styles.navArrow}>→</Text>
        </TouchableOpacity>
      </View>
      <Text style={styles.counter}>{slide + 1} / {slides.length}</Text>
      <View style={styles.buttons}>
        <ZIMAButton label={t ? '← Back' : '← Atrás'} onPress={onBack} variant="outline" style={{ flex: 0.4 }} />
        <ZIMAButton label={t ? 'Continue →' : 'Continuar →'} onPress={onNext} style={{ flex: 1 }} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1 },
  title: { fontSize: 20, fontWeight: '800', color: COLORS.white, marginBottom: 20 },
  card: { backgroundColor: COLORS.darkGray, borderRadius: RADIUS.lg, padding: 28, minHeight: 200, alignItems: 'center', justifyContent: 'center', marginBottom: 20 },
  icon: { fontSize: 48, marginBottom: 12 },
  slideTitle: { fontSize: 18, fontWeight: '800', color: COLORS.eliteBlue, textAlign: 'center', marginBottom: 10 },
  slideBody: { fontSize: 13, color: COLORS.gray, lineHeight: 20, textAlign: 'center' },
  navRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 },
  navBtn: { backgroundColor: COLORS.eliteBlue, borderRadius: RADIUS.sm, paddingVertical: 12, paddingHorizontal: 20 },
  navBtnDisabled: { backgroundColor: COLORS.darkGray },
  navArrow: { color: COLORS.white, fontSize: 18, fontWeight: '700' },
  dots: { flexDirection: 'row', gap: 6 },
  dot: { width: 8, height: 8, borderRadius: 4, backgroundColor: '#333' },
  dotActive: { width: 20, backgroundColor: COLORS.eliteBlue },
  counter: { textAlign: 'center', color: COLORS.gray, fontSize: 11, marginBottom: 20 },
  buttons: { flexDirection: 'row', gap: 10 },
});
