// © Carlos Espina Property — Paso 2: Interruptor ZIMA Faith (Función 2)
import React from 'react';
import { View, Text, Switch, TouchableOpacity, StyleSheet } from 'react-native';
import { COLORS, SPACING, RADIUS } from '../../constants/theme';
import { useZIMAStore } from '../../store/useZIMAStore';
import { ZIMAButton } from '../../components/ui/ZIMAButton';
import { SectionLabel } from '../../components/ui/SectionLabel';

interface Props { onNext: () => void; onBack: () => void; }

export const Step2Faith: React.FC<Props> = ({ onNext, onBack }) => {
  const { faith, setFaith, idioma } = useZIMAStore();
  const t = idioma === 'EN';
  return (
    <View style={styles.container}>
      <SectionLabel>ZIMA Faith</SectionLabel>
      <Text style={styles.title}>{t ? 'Spiritual Module' : 'Módulo Espiritual'}</Text>
      <Text style={styles.desc}>
        {t ? 'ZIMA integrates the Word of God as a mental health pillar. Activate to receive a daily Psalm on your dashboard (Reina Valera 1960).'
           : 'ZIMA integra la Palabra de Dios como pilar de salud mental. Activa para recibir un Salmo diario en tu dashboard (Reina Valera 1960).'}
      </Text>
      <View style={[styles.preview, faith && styles.previewActive]}>
        <Text style={styles.cross}>✝️</Text>
        <Text style={styles.verse}>{t ? '"The LORD is my shepherd; I shall not want."' : '"El Señor es mi pastor; nada me faltará."'}</Text>
        <Text style={[styles.ref, { color: faith ? COLORS.gold : COLORS.gray }]}>— Salmo 23:1 (RV1960)</Text>
      </View>
      <View style={styles.toggle}>
        <View>
          <Text style={styles.toggleLabel}>ZIMA Faith</Text>
          <Text style={styles.toggleSub}>{faith ? (t ? 'Active ✝' : 'Activo ✝') : (t ? 'Disabled' : 'Desactivado')}</Text>
        </View>
        <Switch value={faith} onValueChange={setFaith} trackColor={{ false: '#444', true: COLORS.gold }} thumbColor={COLORS.white} />
      </View>
      <View style={styles.buttons}>
        <ZIMAButton label={t ? '← Back' : '← Atrás'} onPress={onBack} variant="outline" style={{ flex: 0.4 }} />
        <ZIMAButton label={t ? 'Continue →' : 'Continuar →'} onPress={onNext} style={{ flex: 1 }} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1 },
  title: { fontSize: 24, fontWeight: '800', color: COLORS.white, marginBottom: 8 },
  desc: { fontSize: 13, color: COLORS.gray, lineHeight: 20, marginBottom: 24 },
  preview: { padding: 20, borderRadius: RADIUS.lg, borderWidth: 1, borderColor: '#333', backgroundColor: COLORS.darkGray, marginBottom: 20, alignItems: 'center' },
  previewActive: { borderColor: 'rgba(255,215,0,0.4)', backgroundColor: 'rgba(255,215,0,0.06)' },
  cross: { fontSize: 36, marginBottom: 8 },
  verse: { fontSize: 13, fontStyle: 'italic', color: COLORS.white, textAlign: 'center', lineHeight: 20, marginBottom: 6 },
  ref: { fontSize: 11, fontWeight: '700' },
  toggle: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 18, backgroundColor: COLORS.darkGray, borderRadius: RADIUS.md, marginBottom: 24 },
  toggleLabel: { fontSize: 15, fontWeight: '700', color: COLORS.white },
  toggleSub: { fontSize: 12, color: COLORS.gray, marginTop: 2 },
  buttons: { flexDirection: 'row', gap: 10 },
});
