// © Carlos Espina Property — Paso 3: Algoritmo Biotipo SIM (Función 3)
import React from 'react';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet } from 'react-native';
import { COLORS, RADIUS } from '../../constants/theme';
import { useZIMAStore, Biotipo } from '../../store/useZIMAStore';
import { ZIMAButton } from '../../components/ui/ZIMAButton';
import { SectionLabel } from '../../components/ui/SectionLabel';
import { getBiotipoConfig } from '../../utils/sim';

interface Props { onNext: () => void; onBack: () => void; }

const TIPOS: { id: Biotipo; icon: string; en: string; es: string }[] = [
  { id: 'Ectomorfo', icon: '🦴', en: 'Ectomorph', es: 'Ectomorfo' },
  { id: 'Mesomorfo', icon: '💪', en: 'Mesomorph', es: 'Mesomorfo' },
  { id: 'Endomorfo', icon: '🔥', en: 'Endomorph', es: 'Endomorfo' },
];

export const Step3Biotipo: React.FC<Props> = ({ onNext, onBack }) => {
  const { biotipo, setBiotipo, idioma } = useZIMAStore();
  const t = idioma === 'EN';
  return (
    <View style={styles.container}>
      <SectionLabel>{t ? 'SIM Biotype Algorithm' : 'Algoritmo de Biotipo SIM'}</SectionLabel>
      <Text style={styles.title}>{t ? 'Your Genetic Profile' : 'Tu Perfil Genético'}</Text>
      {TIPOS.map(tipo => {
        const cfg = getBiotipoConfig(tipo.id)!;
        return (
          <TouchableOpacity key={tipo.id} onPress={() => setBiotipo(tipo.id)}
            style={[styles.card, biotipo === tipo.id && styles.cardSelected]}>
            <View style={styles.row}>
              <Text style={styles.icon}>{tipo.icon}</Text>
              <View style={{ flex: 1 }}>
                <Text style={styles.label}>{t ? tipo.en : tipo.es}</Text>
                <Text style={styles.desc}>{cfg.description}</Text>
                <Text style={styles.keto}>{t ? 'Ketosis in:' : 'Cetosis en:'} {cfg.ketoAdaptTime}</Text>
              </View>
              {biotipo === tipo.id && <View style={styles.check}><Text style={{ color: COLORS.white, fontSize: 10 }}>✓</Text></View>}
            </View>
          </TouchableOpacity>
        );
      })}
      <View style={styles.buttons}>
        <ZIMAButton label={t ? '← Back' : '← Atrás'} onPress={onBack} variant="outline" style={{ flex: 0.4 }} />
        <ZIMAButton label={t ? 'Continue →' : 'Continuar →'} onPress={onNext} disabled={!biotipo} style={{ flex: 1 }} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1 },
  title: { fontSize: 22, fontWeight: '800', color: COLORS.white, marginBottom: 20 },
  card: { backgroundColor: COLORS.darkGray, borderRadius: RADIUS.md, padding: 16, marginBottom: 10, borderWidth: 1, borderColor: '#333' },
  cardSelected: { borderColor: COLORS.eliteBlue, backgroundColor: 'rgba(0,112,255,0.12)' },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  icon: { fontSize: 28 },
  label: { fontSize: 16, fontWeight: '700', color: COLORS.white },
  desc: { fontSize: 12, color: COLORS.gray, marginTop: 2, lineHeight: 18 },
  keto: { fontSize: 11, color: COLORS.eliteBlue, fontWeight: '700', marginTop: 4 },
  check: { width: 22, height: 22, borderRadius: 11, backgroundColor: COLORS.eliteBlue, alignItems: 'center', justifyContent: 'center' },
  buttons: { flexDirection: 'row', gap: 10, marginTop: 20 },
});
