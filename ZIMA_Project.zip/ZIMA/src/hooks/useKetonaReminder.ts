// © Carlos Espina Property — Función 32: Check-up Semanal de Cetonas
import { useEffect } from 'react';
import * as Notifications from 'expo-notifications';
import { useZIMAStore } from '../store/useZIMAStore';

export const useKetonaReminder = () => {
  const { idioma } = useZIMAStore();
  useEffect(() => {
    const schedule = async () => {
      const msg = idioma === 'EN'
        ? 'Weekly ketone check! Register your mmol/L level in ZIMA.'
        : 'Control semanal de cetonas. Registra tu nivel mmol/L en ZIMA.';
      await Notifications.scheduleNotificationAsync({
        content: { title: 'ZIMA 🔥 Check Cetónico', body: msg },
        trigger: { seconds: 7 * 24 * 60 * 60, repeats: true } as any,
      });
    };
    schedule();
  }, []);
};
