// © Carlos Espina Property — Función 42: Sincronización Circadiana
import { useEffect } from 'react';
import { useZIMAStore } from '../store/useZIMAStore';

export const useCircadianMode = () => {
  const setModoCircadiano = useZIMAStore(s => s.setModoCircadiano);
  useEffect(() => {
    const check = () => {
      const h = new Date().getHours();
      setModoCircadiano(h >= 20 || h < 6);
    };
    check();
    const interval = setInterval(check, 60000);
    return () => clearInterval(interval);
  }, []);
};
