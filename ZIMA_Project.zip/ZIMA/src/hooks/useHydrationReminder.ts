// © Carlos Espina Property — Función 31: Recordatorio de Hidratación 4H
import { useEffect } from 'react';
import * as Notifications from 'expo-notifications';
import { useZIMAStore } from '../store/useZIMAStore';
import { calcHidratacion } from '../utils/sim';

export const useHydrationReminder = () => {
  const { medidas, idioma } = useZIMAStore();
  useEffect(() => {
    const schedule = async () => {
      await Notifications.cancelAllScheduledNotificationsAsync();
      const peso = (medidas.peso as number) || 70;
      const litros = calcHidratacion(peso, 22);
      const msg = idioma === 'EN'
        ? 'Time to hydrate! Drink water + electrolytes.'
        : '¡Hora de hidratarte! Agua + electrolitos ahora.';
      await Notifications.scheduleNotificationAsync({
        content: { title: 'ZIMA 💧', body: msg + ' (' + litros + 'L objetivo diario)' },
        trigger: { seconds: 4 * 60 * 60, repeats: true } as any,
      });
    };
    schedule();
  }, [medidas.peso]);
};
