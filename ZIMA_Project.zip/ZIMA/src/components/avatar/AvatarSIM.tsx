// © Carlos Espina Property — Motor de Renderizado SIM (Funciones 5, 6, 41)
import React, { useEffect, useRef } from 'react';
import { View, Animated } from 'react-native';
import Svg, { Ellipse, Rect, Path, Line, Text as SvgText } from 'react-native-svg';
import { COLORS } from '../../constants/theme';
import { getBiotipoConfig } from '../../utils/sim';
import { Biotipo } from '../../store/useZIMAStore';

interface Props {
  biotipo: Biotipo;
  muscleLevel?: number;   // 0-5 — Función 6
  faith?: boolean;
  xray?: boolean;         // Función 41
  size?: number;
}

export const AvatarSIM: React.FC<Props> = ({
  biotipo, muscleLevel = 0, faith = false, xray = false, size = 1
}) => {
  const pulse = useRef(new Animated.Value(0)).current;
  const cfg = getBiotipoConfig(biotipo)!;
  const glowColor = faith ? COLORS.gold : COLORS.eliteBlue;
  const muscleOpacity = 0.15 + muscleLevel * 0.1;

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, { toValue: 1, duration: 2000, useNativeDriver: true }),
        Animated.timing(pulse, { toValue: 0, duration: 2000, useNativeDriver: true }),
      ])
    ).start();
  }, []);

  const w = 160 * size;
  const h = 310 * size;

  return (
    <View>
      <Svg width={w} height={h} viewBox="0 0 160 310">
        {/* Head */}
        <Ellipse cx="80" cy="34" rx="22" ry="26" fill={COLORS.darkGray} stroke={glowColor} strokeWidth="1.5" />
        {xray && <Ellipse cx="80" cy="34" rx="14" ry="18" fill="none" stroke="rgba(0,255,150,0.3)" strokeWidth="0.5" />}
        {/* Neck */}
        <Rect x="72" y="58" width="16" height="14" rx="4" fill={COLORS.darkGray} />
        {/* Torso */}
        <Path d={`M ${80 - cfg.shoulderW / 2} 72 L ${80 + cfg.shoulderW / 2} 72 L ${80 + cfg.waistW / 2} 160 L ${80 - cfg.waistW / 2} 160 Z`}
          fill={COLORS.medGray} stroke={glowColor} strokeWidth="1.2" />
        {/* Muscle lines */}
        <Path d={`M ${80 - cfg.shoulderW / 2 + 8} 80 L 76 130`} stroke={glowColor} strokeWidth={1 + muscleLevel * 0.5} opacity={muscleOpacity} />
        <Path d={`M ${80 + cfg.shoulderW / 2 - 8} 80 L 84 130`} stroke={glowColor} strokeWidth={1 + muscleLevel * 0.5} opacity={muscleOpacity} />
        <Path d="M 62 95 Q 80 105 98 95" stroke={glowColor} strokeWidth="1" opacity={muscleOpacity + 0.1} fill="none" />
        {/* Abs */}
        {[110, 122, 134].map((y, i) => (
          <React.Fragment key={i}>
            <Rect x="70" y={y} width="8" height="6" rx="2" fill={glowColor} opacity={muscleOpacity} />
            <Rect x="82" y={y} width="8" height="6" rx="2" fill={glowColor} opacity={muscleOpacity} />
          </React.Fragment>
        ))}
        {/* Arms */}
        <Rect x={80 - cfg.shoulderW / 2 - 14} y="74" width="14" height="60" rx="7" fill={COLORS.medGray} stroke={glowColor} strokeWidth="1" />
        <Rect x={80 + cfg.shoulderW / 2} y="74" width="14" height="60" rx="7" fill={COLORS.medGray} stroke={glowColor} strokeWidth="1" />
        <Rect x={80 - cfg.shoulderW / 2 - 12} y="134" width="10" height="44" rx="5" fill={COLORS.darkGray} stroke={glowColor} strokeWidth="0.8" />
        <Rect x={80 + cfg.shoulderW / 2 + 2} y="134" width="10" height="44" rx="5" fill={COLORS.darkGray} stroke={glowColor} strokeWidth="0.8" />
        {/* Hips */}
        <Path d={`M ${80 - cfg.waistW / 2} 158 L ${80 + cfg.waistW / 2} 158 L ${80 + cfg.hipW / 2} 188 L ${80 - cfg.hipW / 2} 188 Z`}
          fill={COLORS.medGray} stroke={glowColor} strokeWidth="1" />
        {/* X-Ray organs (Función 41) */}
        {xray && (
          <>
            <Ellipse cx="70" cy="130" rx="14" ry="10" fill="rgba(0,112,255,0.35)" stroke={COLORS.eliteBlue} strokeWidth="0.8" />
            <Ellipse cx="90" cy="140" rx="10" ry="6" fill="rgba(255,0,80,0.25)" stroke={COLORS.red} strokeWidth="0.8" />
            <SvgText x="56" y="128" fill={COLORS.eliteBlue} fontSize="6" fontWeight="700">HÍGADO</SvgText>
            <SvgText x="82" y="138" fill={COLORS.red} fontSize="5" fontWeight="700">PÁNCREAS</SvgText>
          </>
        )}
        {/* Legs */}
        <Rect x={80 - cfg.hipW / 2 + 4} y="186" width={cfg.hipW / 2 - cfg.legGap} height="80" rx="10" fill={COLORS.medGray} stroke={glowColor} strokeWidth="1" />
        <Rect x={80 + cfg.legGap} y="186" width={cfg.hipW / 2 - cfg.legGap} height="80" rx="10" fill={COLORS.medGray} stroke={glowColor} strokeWidth="1" />
        <Rect x={80 - cfg.hipW / 2 + 6} y="268" width={cfg.hipW / 2 - cfg.legGap - 4} height="36" rx="8" fill={COLORS.darkGray} stroke={glowColor} strokeWidth="0.8" />
        <Rect x={80 + cfg.legGap + 2} y="268" width={cfg.hipW / 2 - cfg.legGap - 4} height="36" rx="8" fill={COLORS.darkGray} stroke={glowColor} strokeWidth="0.8" />
        {/* Signature */}
        <Line x1="40" y1="305" x2="120" y2="305" stroke={glowColor} strokeWidth="0.5" opacity="0.4" />
        <SvgText x="80" y="303" textAnchor="middle" fill={glowColor} fontSize="6" opacity="0.5" fontWeight="600">SIM ENGINE v1 © Carlos Espina</SvgText>
      </Svg>
    </View>
  );
};
