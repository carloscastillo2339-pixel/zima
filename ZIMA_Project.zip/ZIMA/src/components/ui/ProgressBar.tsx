// © Carlos Espina Property
import React from 'react';
import { View } from 'react-native';
import { COLORS } from '../../constants/theme';

interface Props { step: number; total: number; }
export const ProgressBar: React.FC<Props> = ({ step, total }) => (
  <View style={{ flexDirection: 'row', gap: 4, marginBottom: 8 }}>
    {Array.from({ length: total }).map((_, i) => (
      <View key={i} style={{ flex: 1, height: 3, borderRadius: 2, backgroundColor: i < step ? COLORS.eliteBlue : COLORS.darkGray }} />
    ))}
  </View>
);
