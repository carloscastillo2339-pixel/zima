// © Carlos Espina Property
import React from 'react';
import { Text, StyleSheet } from 'react-native';
import { COLORS } from '../../constants/theme';

export const SectionLabel: React.FC<{ children: string }> = ({ children }) => (
  <Text style={{ fontSize: 11, fontWeight: '700', letterSpacing: 3, color: COLORS.eliteBlue, textTransform: 'uppercase', marginBottom: 8 }}>
    {children}
  </Text>
);
