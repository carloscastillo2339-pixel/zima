// © Carlos Espina Property — Función 40: Sello de Propiedad IP
import React from 'react';
import { View, Text } from 'react-native';
import { COLORS, RADIUS, SPACING } from '../../constants/theme';
import { SIGNATURE, ALGO_VERSION } from '../../constants/theme';

export const IPSignature: React.FC = () => (
  <View style={{ backgroundColor: COLORS.darkGray, borderRadius: RADIUS.md, borderWidth: 1, borderColor: 'rgba(0,112,255,0.15)', padding: SPACING.md, alignItems: 'center', marginTop: SPACING.md }}>
    <Text style={{ fontSize: 10, color: COLORS.eliteBlue, fontWeight: '700', letterSpacing: 2 }}>
      {SIGNATURE.toUpperCase()}
    </Text>
    <Text style={{ fontSize: 9, color: '#444', marginTop: 3 }}>{ALGO_VERSION}</Text>
  </View>
);
