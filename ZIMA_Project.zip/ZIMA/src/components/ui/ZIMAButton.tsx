// © Carlos Espina Property
import React, { useState } from 'react';
import { TouchableOpacity, Text, StyleSheet, ViewStyle } from 'react-native';
import { COLORS, RADIUS } from '../../constants/theme';

interface Props {
  label: string;
  onPress: () => void;
  variant?: 'primary' | 'outline' | 'danger';
  disabled?: boolean;
  style?: ViewStyle;
}

export const ZIMAButton: React.FC<Props> = ({ label, onPress, variant = 'primary', disabled, style }) => {
  const bg = variant === 'primary' ? COLORS.eliteBlue : variant === 'danger' ? COLORS.red : 'transparent';
  const border = variant === 'outline' ? COLORS.eliteBlue : variant === 'danger' ? COLORS.red : 'transparent';
  return (
    <TouchableOpacity
      onPress={onPress} disabled={disabled}
      style={[{ backgroundColor: disabled ? COLORS.medGray : bg, borderWidth: 1, borderColor: disabled ? COLORS.medGray : border, borderRadius: RADIUS.md, paddingVertical: 14, paddingHorizontal: 20, alignItems: 'center' }, style]}
    >
      <Text style={{ color: disabled ? COLORS.gray : COLORS.white, fontWeight: '700', fontSize: 15, letterSpacing: 0.5 }}>
        {label}
      </Text>
    </TouchableOpacity>
  );
};
