// © Carlos Espina Property — Smart Pantry Item (Funciones 9, 10, 11)
import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { COLORS, SPACING, RADIUS } from '../../constants/theme';
import { PantryItem as PantryItemType, useZIMAStore } from '../../store/useZIMAStore';

interface Props { item: PantryItemType; }

export const PantryItemCard: React.FC<Props> = ({ item }) => {
  const { removePantryItem, idioma } = useZIMAStore();
  const pct = Math.min(100, (item.stockGramos / 500) * 100);
  const isCritical = pct <= 15;

  const TIPO_ICONS: Record<string, string> = {
    'Proteína Animal': '🥩', 'Proteína Vegetal': '🥦', 'Grasa': '🥑', 'Líquido': '💧',
  };

  return (
    <View style={[styles.card, isCritical && styles.critical]}>
      <View style={styles.row}>
        <Text style={styles.icon}>{TIPO_ICONS[item.tipo] || '🍽'}</Text>
        <View style={styles.info}>
          <Text style={styles.name}>{item.nombre}</Text>
          <Text style={styles.tipo}>{item.tipo}</Text>
        </View>
        <View style={styles.right}>
          <Text style={[styles.stock, isCritical && { color: COLORS.red }]}>
            {item.stockGramos}g
          </Text>
          {isCritical && <Text style={styles.alert}>⚠ CRÍTICO</Text>}
        </View>
      </View>
      <View style={styles.barBg}>
        <View style={[styles.bar, { width: pct + '%', backgroundColor: isCritical ? COLORS.red : COLORS.eliteBlue }]} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  card: { backgroundColor: COLORS.darkGray, borderRadius: RADIUS.md, padding: SPACING.md, marginBottom: SPACING.sm, borderWidth: 1, borderColor: '#333' },
  critical: { borderColor: COLORS.red },
  row: { flexDirection: 'row', alignItems: 'center', marginBottom: 8 },
  icon: { fontSize: 24, marginRight: 12 },
  info: { flex: 1 },
  name: { color: COLORS.white, fontWeight: '700', fontSize: 14 },
  tipo: { color: COLORS.gray, fontSize: 11, marginTop: 2 },
  right: { alignItems: 'flex-end' },
  stock: { color: COLORS.eliteBlue, fontWeight: '900', fontSize: 16 },
  alert: { color: COLORS.red, fontSize: 9, fontWeight: '700', marginTop: 2 },
  barBg: { height: 4, backgroundColor: COLORS.medGray, borderRadius: 2 },
  bar: { height: 4, borderRadius: 2 },
});
