// © Carlos Espina Property — ZIMA Faith (Funciones 2, 15, 16)
import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { COLORS, SPACING, RADIUS, SIGNATURE } from '../../constants/theme';
import { getTodayPsalm } from '../../constants/psalms';
import { useZIMAStore } from '../../store/useZIMAStore';

interface Props {
  showVault?: boolean;
}

export const FaithWidget: React.FC<Props> = ({ showVault = false }) => {
  const { faith, psalmFavoritos, addFavoritoPsalm, removeFavoritoPsalm, idioma } = useZIMAStore();
  const psalm = getTodayPsalm();
  const isFav = psalmFavoritos.some(p => p.idSalmo === psalm.id);

  if (!faith) return null;

  const toggleFav = () => {
    if (isFav) removeFavoritoPsalm(psalm.id);
    else addFavoritoPsalm({ idSalmo: psalm.id, ref: psalm.ref, text: psalm.text });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.label}>✝ ZIMA FAITH — RV1960</Text>
      <Text style={styles.verse}>"{psalm.text}"</Text>
      <View style={styles.row}>
        <Text style={styles.ref}>— {psalm.ref}</Text>
        <TouchableOpacity onPress={toggleFav}>
          <Text style={styles.fav}>{isFav ? '★' : '☆'}</Text>
        </TouchableOpacity>
      </View>
      <Text style={styles.sig}>{SIGNATURE}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'rgba(255,215,0,0.06)',
    borderColor: 'rgba(255,215,0,0.25)',
    borderWidth: 1,
    borderRadius: RADIUS.md,
    padding: SPACING.md,
    marginBottom: SPACING.md,
  },
  label: { fontSize: 10, fontWeight: '700', letterSpacing: 2, color: COLORS.gold, marginBottom: 6 },
  verse: { fontSize: 13, fontStyle: 'italic', color: COLORS.white, lineHeight: 20, marginBottom: 6 },
  row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  ref: { fontSize: 11, color: COLORS.gold, fontWeight: '700' },
  fav: { fontSize: 18, color: COLORS.gold },
  sig: { fontSize: 8, color: 'rgba(255,215,0,0.3)', marginTop: 6, textAlign: 'right' },
});
