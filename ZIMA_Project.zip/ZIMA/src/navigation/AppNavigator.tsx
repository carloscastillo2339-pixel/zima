// © Carlos Espina Property — ZIMA Navigation
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Text } from 'react-native';
import { COLORS } from '../constants/theme';
import { useZIMAStore } from '../store/useZIMAStore';
import { OnboardingNavigator } from '../screens/onboarding/OnboardingNavigator';
import { DashboardScreen } from '../screens/dashboard/DashboardScreen';
import { TrainingScreen } from '../screens/training/TrainingScreen';
import { NutritionScreen } from '../screens/nutrition/NutritionScreen';
import { MonitoringScreen } from '../screens/monitoring/MonitoringScreen';
import { EliteScreen } from '../screens/elite/EliteScreen';
import { useCircadianMode } from '../hooks/useCircadianMode';

const Tab = createBottomTabNavigator();

export const AppNavigator: React.FC = () => {
  const { onboardingComplete, modoCircadiano } = useZIMAStore();
  useCircadianMode();

  if (!onboardingComplete) return <OnboardingNavigator />;

  const tabBarBg = modoCircadiano ? '#0D0000' : COLORS.bg;

  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={{
          headerShown: false,
          tabBarStyle: {
            backgroundColor: tabBarBg,
            borderTopColor: '#1A1A1A',
            borderTopWidth: 1,
            paddingBottom: 8,
            paddingTop: 8,
            height: 65,
          },
          tabBarActiveTintColor: COLORS.eliteBlue,
          tabBarInactiveTintColor: COLORS.gray,
          tabBarLabelStyle: { fontSize: 10, fontWeight: '700', letterSpacing: 0.5 },
        }}
      >
        <Tab.Screen name="Dashboard" component={DashboardScreen}
          options={{ tabBarIcon: ({ color }) => <Text style={{ fontSize: 20, color }}>⚡</Text>, tabBarLabel: 'Dashboard' }} />
        <Tab.Screen name="Entrenamiento" component={TrainingScreen}
          options={{ tabBarIcon: ({ color }) => <Text style={{ fontSize: 20, color }}>💪</Text>, tabBarLabel: 'Training' }} />
        <Tab.Screen name="Nutricion" component={NutritionScreen}
          options={{ tabBarIcon: ({ color }) => <Text style={{ fontSize: 20, color }}>🥑</Text>, tabBarLabel: 'Nutrition' }} />
        <Tab.Screen name="Monitoreo" component={MonitoringScreen}
          options={{ tabBarIcon: ({ color }) => <Text style={{ fontSize: 20, color }}>🔬</Text>, tabBarLabel: 'Monitor' }} />
        <Tab.Screen name="Elite" component={EliteScreen}
          options={{ tabBarIcon: ({ color }) => <Text style={{ fontSize: 20, color }}>🌟</Text>, tabBarLabel: 'Elite' }} />
      </Tab.Navigator>
    </NavigationContainer>
  );
};
