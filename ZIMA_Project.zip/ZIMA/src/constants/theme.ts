// © Carlos Espina Property — ZIMA Theme
export const COLORS = {
  bg: '#000000',
  eliteBlue: '#0070FF',
  eliteBlueGlow: 'rgba(0,112,255,0.25)',
  eliteBlueDim: 'rgba(0,112,255,0.12)',
  eliteBlueDeep: '#0055CC',
  white: '#FFFFFF',
  gray: '#A0A0A0',
  darkGray: '#1A1A1A',
  medGray: '#2A2A2A',
  red: '#FF2D55',
  redGlow: 'rgba(255,45,85,0.25)',
  gold: '#FFD700',
  goldGlow: 'rgba(255,215,0,0.2)',
  green: '#00FF94',
  greenGlow: 'rgba(0,255,148,0.2)',
  circadian: '#8B0000',
};
export const SPACING = { xs: 4, sm: 8, md: 16, lg: 24, xl: 32, xxl: 48 };
export const RADIUS = { sm: 8, md: 12, lg: 16, xl: 24, full: 999 };
export const SIGNATURE = '© Carlos Espina Property';
export const ALGO_VERSION = 'ZIMA Algoritmo SIM v1.0 — 2026';
