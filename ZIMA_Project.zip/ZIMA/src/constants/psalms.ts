// © Carlos Espina Property — ZIMA Faith / Reina Valera 1960
export const PSALMS_RV1960 = [
  { id: 1,  ref: 'Salmo 23:1',   text: 'El Señor es mi pastor; nada me faltará.' },
  { id: 2,  ref: 'Salmo 91:1',   text: 'El que habita al abrigo del Altísimo morará bajo la sombra del Omnipotente.' },
  { id: 3,  ref: 'Salmo 46:10',  text: 'Estad quietos, y conoced que yo soy Dios.' },
  { id: 4,  ref: 'Salmo 37:4',   text: 'Deléitate asimismo en el Señor, y él te concederá las peticiones de tu corazón.' },
  { id: 5,  ref: 'Salmo 27:1',   text: 'El Señor es mi luz y mi salvación; ¿a quién temeré?' },
  { id: 6,  ref: 'Salmo 121:2',  text: 'Mi socorro viene del Señor, que hizo los cielos y la tierra.' },
  { id: 7,  ref: 'Salmo 139:14', text: 'Te alabaré; porque formidables, maravillosas son tus obras.' },
  { id: 8,  ref: 'Salmo 34:18',  text: 'Cercano está el Señor a los quebrantados de corazón.' },
  { id: 9,  ref: 'Salmo 19:14',  text: 'Sean gratos los dichos de mi boca y la meditación de mi corazón delante de ti.' },
  { id: 10, ref: 'Salmo 31:24',  text: 'Esforzaos todos vosotros los que esperáis en el Señor, y tome aliento vuestro corazón.' },
  { id: 11, ref: 'Salmo 18:2',   text: 'El Señor es mi roca y mi fortaleza y mi libertador.' },
  { id: 12, ref: 'Salmo 55:22',  text: 'Echa sobre el Señor tu carga, y él te sustentará.' },
];
export const getTodayPsalm = () => {
  const dayOfYear = Math.floor((Date.now() - new Date(new Date().getFullYear(), 0, 0).getTime()) / 86400000);
  return PSALMS_RV1960[dayOfYear % PSALMS_RV1960.length];
};
