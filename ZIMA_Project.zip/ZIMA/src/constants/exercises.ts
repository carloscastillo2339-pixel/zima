// © Carlos Espina Property — 8 Ejercicios Fundamentales SIM
export type Entorno = 'Casa' | 'Barra' | 'Gimnasio';

export interface Exercise {
  id: string;
  nombre: string;
  musculosPrincipales: string[];
  entornos: Entorno[];
  duracionSeg: number;
  descripcion: string;
}

export const EXERCISES: Exercise[] = [
  { id: 'e01', nombre: 'Sentadilla', musculosPrincipales: ['Cuádriceps','Glúteos'], entornos: ['Casa','Barra','Gimnasio'], duracionSeg: 45, descripcion: 'Pies al ancho de hombros, rodillas sobre puntas de pies, espalda neutra.' },
  { id: 'e02', nombre: 'Flexión de Pecho', musculosPrincipales: ['Pectoral','Tríceps'], entornos: ['Casa','Barra'], duracionSeg: 40, descripcion: 'Cuerpo recto como tabla, bajar hasta 2cm del suelo, codos a 45°.' },
  { id: 'e03', nombre: 'Dominada', musculosPrincipales: ['Dorsal','Bíceps'], entornos: ['Barra','Gimnasio'], duracionSeg: 45, descripcion: 'Agarre supino o prono, jalar hasta el mentón sobre la barra.' },
  { id: 'e04', nombre: 'Hip Thrust', musculosPrincipales: ['Glúteos','Isquiotibiales'], entornos: ['Casa','Gimnasio'], duracionSeg: 45, descripcion: 'Espalda apoyada en banco, empujar caderas hacia arriba contrayendo glúteos.' },
  { id: 'e05', nombre: 'Plancha Isométrica', musculosPrincipales: ['Core','Abdomen'], entornos: ['Casa','Barra','Gimnasio'], duracionSeg: 60, descripcion: 'Cuerpo recto sobre antebrazos, contraer abdomen y glúteos durante el tiempo.' },
  { id: 'e06', nombre: 'Press Militar', musculosPrincipales: ['Deltoides','Tríceps'], entornos: ['Gimnasio'], duracionSeg: 40, descripcion: 'Barra a nivel de hombros, empujar hacia arriba extendiendo codos completamente.' },
  { id: 'e07', nombre: 'Remo Invertido', musculosPrincipales: ['Dorsal','Romboides'], entornos: ['Barra','Gimnasio'], duracionSeg: 40, descripcion: 'Cuerpo inclinado bajo la barra, jalar el pecho hacia ella manteniendo cuerpo recto.' },
  { id: 'e08', nombre: 'Burpee Cetogénico', musculosPrincipales: ['Cuerpo Completo'], entornos: ['Casa','Barra','Gimnasio'], duracionSeg: 50, descripcion: 'Flexión + salto explosivo. Mayor activación mitocondrial en estado cetogénico.' },
  { id: 'e09', nombre: 'Zancada', musculosPrincipales: ['Cuádriceps','Glúteos'], entornos: ['Casa','Gimnasio'], duracionSeg: 45, descripcion: 'Alterna piernas, rodilla trasera cerca del suelo, torso erguido.' },
  { id: 'e10', nombre: 'Elevación de Talones', musculosPrincipales: ['Gemelos'], entornos: ['Casa','Gimnasio'], duracionSeg: 40, descripcion: 'Parado en filo de escalón, bajar talón completamente y elevar en punta.' },
  { id: 'e11', nombre: 'Curl de Bíceps', musculosPrincipales: ['Bíceps'], entornos: ['Gimnasio'], duracionSeg: 40, descripcion: 'Codos fijos a los costados, supinar la muñeca al subir.' },
  { id: 'e12', nombre: 'Fondos en Paralelas', musculosPrincipales: ['Tríceps','Pectoral'], entornos: ['Barra','Gimnasio'], duracionSeg: 40, descripcion: 'Bajar hasta 90° en codos, mantener torso ligeramente inclinado.' },
];

export const getExercisesForEntorno = (entorno: Entorno, count = 8): Exercise[] => {
  const filtered = EXERCISES.filter(e => e.entornos.includes(entorno));
  return filtered.slice(0, count);
};

export const getSwapExercise = (currentId: string, entorno: Entorno): Exercise | null => {
  const available = EXERCISES.filter(e => e.id !== currentId && e.entornos.includes(entorno));
  if (!available.length) return null;
  return available[Math.floor(Math.random() * available.length)];
};
