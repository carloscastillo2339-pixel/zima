// © Carlos Espina Property — Algoritmo SIM Core
import { Biotipo } from '../store/useZIMAStore';

export const getBiotipoConfig = (biotipo: Biotipo) => ({
  Ectomorfo: { shoulderW: 52, waistW: 36, hipW: 42, legGap: 12, ketoAdaptTime: '24h', description: 'Metabolismo rápido. Cetosis profunda en 24h.' },
  Mesomorfo: { shoulderW: 68, waistW: 42, hipW: 52, legGap: 10, ketoAdaptTime: '36h', description: 'Respuesta óptima al entrenamiento cetogénico.' },
  Endomorfo: { shoulderW: 62, waistW: 58, hipW: 65, legGap: 6,  ketoAdaptTime: '48h', description: 'Alta eficiencia en oxidación de grasas.' },
}[biotipo]);

export const calcCarbosNetos = (carbsTotales: number, fibra: number) => Math.max(0, carbsTotales - fibra);

export const calcEdadMetabolica = (edad: number, cetonas: number, volumen: number, bmi: number) => {
  let ajuste = 0;
  if (cetonas >= 1.5) ajuste -= 5; else if (cetonas >= 0.5) ajuste -= 2;
  if (volumen > 5000) ajuste -= 4; else if (volumen > 2000) ajuste -= 2;
  if (bmi >= 18.5 && bmi <= 24.9) ajuste -= 3; else if (bmi > 30) ajuste += 5;
  return Math.max(18, edad + ajuste);
};

export const calcPuntoEbullicion = (maxHistorico: number, diasDescanso: number, cetonas: number) => {
  let factor = diasDescanso >= 3 ? 1.0 : diasDescanso >= 2 ? 0.95 : 0.85;
  if (cetonas >= 1.5) factor += 0.05;
  return Math.round(maxHistorico * factor);
};

export const calcExposicionUV = (lat: number, hora: number, mes: number) => {
  const base = Math.abs(lat) < 30 ? 10 : 20;
  const esVerano = mes >= 10 || mes <= 2;
  const esMediodia = hora >= 10 && hora <= 14;
  return Math.max(5, base - (esVerano ? 5 : 0) - (esMediodia ? 5 : 0));
};

export const calcLongevidad = (sesiones: number, diasCetosis: number, cetonas: number, lecturas: number) => {
  let años = Math.min(sesiones * 0.02, 3) + Math.min(diasCetosis * 0.01, 5) + Math.min(lecturas * 0.005, 1);
  if (cetonas >= 1.5) años += 2;
  return Math.round(años * 10) / 10;
};

export const calcImpactoRuptura = (carbos: number, biotipo: Biotipo) => {
  const f = { Ectomorfo: 0.6, Mesomorfo: 0.8, Endomorfo: 1.0 }[biotipo];
  return {
    perdidaDefinicion: Math.min(100, carbos * f * 0.5),
    tiempoRecuperacion: Math.ceil(carbos * f / 20),
    impactoEnergia: Math.min(100, carbos * f * 0.3),
  };
};

export const calcBMI = (peso: number, estatura: number) => {
  const m = estatura / 100;
  return Math.round((peso / (m * m)) * 10) / 10;
};

export const isKetogenic = (carbosNetos: number, grasas: number, proteinas: number) => {
  const total = carbosNetos * 4 + grasas * 9 + proteinas * 4;
  return total > 0 && (carbosNetos * 4) / total < 0.1 && carbosNetos <= 20;
};

export const detectAceite = (ing: string): 'elite' | 'toxic' | 'neutral' => {
  const l = ing.toLowerCase();
  if (['maravilla','soya','soja','canola','maíz','maiz','vegetal'].some(t => l.includes(t))) return 'toxic';
  if (['oliva','coco','palta','aguacate','ghee','mantequilla'].some(e => l.includes(e))) return 'elite';
  return 'neutral';
};

export const calcHidratacion = (peso: number, temp: number) =>
  Math.round((peso * 0.035 + (temp > 25 ? (temp - 25) * 0.1 : 0)) * 10) / 10;

export const generateIPSignature = () => '© Carlos Espina Property — ZIMA Algoritmo SIM v1.0 — 2026';
