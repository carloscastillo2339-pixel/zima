// © Carlos Espina Property — ZIMA Global State (Zustand)
import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';

export type Biotipo = 'Ectomorfo' | 'Mesomorfo' | 'Endomorfo';
export type Idioma = 'ES' | 'EN';
export type Entorno = 'Casa' | 'Barra' | 'Gimnasio';

export interface Medidas {
  peso: number; estatura: number; cuello: number;
  cintura: number; brazo: number; pierna: number;
}
export interface PantryItem {
  id: string; nombre: string;
  tipo: 'Proteína Animal' | 'Proteína Vegetal' | 'Grasa' | 'Líquido';
  stockGramos: number; fechaVencimiento?: string;
}
export interface Suplemento {
  slotId: number; nombre: string;
  certificadoCetogenico: boolean; propiedadBio: string;
}
export interface WorkoutSession {
  id: string; fecha: string; entorno: Entorno;
  duracionSerie: number; volumenCargaTotal: number; ejercicios: string[];
}
export interface ScanHistory {
  id: string; fecha: string; codigoBarras: string;
  carbosNetos: number; aptoCetogenico: boolean; nombre: string;
}
export interface BioMonitor {
  id: string; tipo: 'Cetonas' | 'Sueño';
  valor: number; horaInicio: string; horaFin?: string;
}
export interface FavoritoPsalm {
  idSalmo: number; ref: string; text: string; exegesisSIM?: string;
}

interface ZIMAState {
  onboardingComplete: boolean;
  idioma: Idioma; faith: boolean; biotipo: Biotipo;
  medidas: Partial<Medidas>; volumenCargaSemanal: number;
  pantry: PantryItem[]; suplementos: Suplemento[];
  workoutLog: WorkoutSession[]; entornoActivo: Entorno;
  scanHistory: ScanHistory[]; bioMonitor: BioMonitor[];
  modoSueno: boolean; psalmFavoritos: FavoritoPsalm[];
  modoCircadiano: boolean; zimaFocusActive: boolean;
  edadCronologica: number;

  setIdioma: (v: Idioma) => void;
  setFaith: (v: boolean) => void;
  setBiotipo: (v: Biotipo) => void;
  setMedidas: (v: Partial<Medidas>) => void;
  setEdadCronologica: (v: number) => void;
  completeOnboarding: () => void;
  addPantryItem: (item: PantryItem) => void;
  removePantryItem: (id: string) => void;
  descontarStock: (itemId: string, gramos: number) => void;
  addSuplemento: (s: Suplemento) => boolean;
  removeSuplemento: (slotId: number) => void;
  replaceSuplemento: (slotId: number, s: Suplemento) => void;
  logWorkout: (session: WorkoutSession) => void;
  setEntorno: (e: Entorno) => void;
  addScan: (scan: ScanHistory) => void;
  addBioMonitor: (entry: BioMonitor) => void;
  setModoSueno: (v: boolean) => void;
  addFavoritoPsalm: (p: FavoritoPsalm) => void;
  removeFavoritoPsalm: (id: number) => void;
  setModoCircadiano: (v: boolean) => void;
  setZIMAFocus: (v: boolean) => void;
  resetAll: () => void;
}

const initial = {
  onboardingComplete: false, idioma: 'ES' as Idioma, faith: false,
  biotipo: 'Mesomorfo' as Biotipo, medidas: {}, volumenCargaSemanal: 0,
  pantry: [], suplementos: [], workoutLog: [], entornoActivo: 'Casa' as Entorno,
  scanHistory: [], bioMonitor: [], modoSueno: false, psalmFavoritos: [],
  modoCircadiano: false, zimaFocusActive: false, edadCronologica: 30,
};

export const useZIMAStore = create<ZIMAState>()(
  persist(
    (set, get) => ({
      ...initial,
      setIdioma: (v) => set({ idioma: v }),
      setFaith: (v) => set({ faith: v }),
      setBiotipo: (v) => set({ biotipo: v }),
      setMedidas: (v) => set({ medidas: v }),
      setEdadCronologica: (v) => set({ edadCronologica: v }),
      completeOnboarding: () => set({ onboardingComplete: true }),
      addPantryItem: (item) => set((s) => ({ pantry: [...s.pantry, item] })),
      removePantryItem: (id) => set((s) => ({ pantry: s.pantry.filter((i) => i.id !== id) })),
      descontarStock: (itemId, gramos) => set((s) => ({
        pantry: s.pantry.map((i) => i.id === itemId ? { ...i, stockGramos: Math.max(0, i.stockGramos - gramos) } : i),
      })),
      addSuplemento: (suplemento) => {
        if (get().suplementos.length >= 10) return false;
        set((s) => ({ suplementos: [...s.suplementos, suplemento] }));
        return true;
      },
      removeSuplemento: (slotId) => set((s) => ({ suplementos: s.suplementos.filter((x) => x.slotId !== slotId) })),
      replaceSuplemento: (slotId, s) => set((st) => ({
        suplementos: st.suplementos.map((x) => x.slotId === slotId ? s : x),
      })),
      logWorkout: (session) => set((s) => ({
        workoutLog: [...s.workoutLog, session],
        volumenCargaSemanal: s.volumenCargaSemanal + session.volumenCargaTotal,
      })),
      setEntorno: (e) => set({ entornoActivo: e }),
      addScan: (scan) => set((s) => ({ scanHistory: [scan, ...s.scanHistory].slice(0, 100) })),
      addBioMonitor: (entry) => set((s) => ({ bioMonitor: [...s.bioMonitor, entry] })),
      setModoSueno: (v) => set({ modoSueno: v }),
      addFavoritoPsalm: (p) => set((s) => ({ psalmFavoritos: [...s.psalmFavoritos, p] })),
      removeFavoritoPsalm: (id) => set((s) => ({ psalmFavoritos: s.psalmFavoritos.filter((p) => p.idSalmo !== id) })),
      setModoCircadiano: (v) => set({ modoCircadiano: v }),
      setZIMAFocus: (v) => set({ zimaFocusActive: v }),
      resetAll: () => set(initial),
    }),
    { name: 'zima-storage', storage: createJSONStorage(() => AsyncStorage) }
  )
);
