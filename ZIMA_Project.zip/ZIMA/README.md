# ZIMA — Bio-Optimization Ecosystem
### © Carlos Espina Property | Algoritmo SIM v1.0 | 2026

**ZIMA** es un ecosistema de bio-optimización cetogénica de última generación.  
Diseñado por Carlos Espina. Estética Elite Stealth: `#000000` + `#0070FF`.

---

## 📋 Stack Técnico
- **Framework:** React Native + Expo SDK 51
- **Estado Global:** Zustand + AsyncStorage
- **Navegación:** React Navigation (Bottom Tabs)
- **Gráficos:** React Native SVG (Avatar SIM)
- **Base de datos local:** Expo SQLite
- **Sensores:** Expo AV, Camera, Location, Sensors

---

## 🚀 Instalación

```bash
# 1. Clonar repositorio
git clone https://github.com/TU_USUARIO/zima-app.git
cd zima-app

# 2. Instalar dependencias
npm install

# 3. Iniciar en modo desarrollo
npx expo start

# 4. Abrir en iOS Simulator
npx expo run:ios

# 5. Abrir en Android
npx expo run:android
```

---

## 📁 Estructura del Proyecto

```
ZIMA/
├── App.tsx                          # Entry point
├── app.json                         # Expo config
├── src/
│   ├── constants/
│   │   ├── theme.ts                 # Colores, spacing, tipografía
│   │   ├── psalms.ts                # Salmos RV1960 (Función 15)
│   │   └── exercises.ts             # 8 Ejercicios Fundamentales (Función 19)
│   ├── store/
│   │   └── useZIMAStore.ts          # Estado global Zustand (todas las fases)
│   ├── utils/
│   │   └── sim.ts                   # Algoritmo SIM — Lógica central
│   ├── hooks/
│   │   ├── useCircadianMode.ts      # Función 42
│   │   ├── useHydrationReminder.ts  # Función 31
│   │   └── useKetonaReminder.ts     # Función 32
│   ├── components/
│   │   ├── avatar/AvatarSIM.tsx     # Motor Renderizado SIM (Función 5, 6, 41)
│   │   ├── faith/FaithWidget.tsx    # ZIMA Faith (Función 2, 15, 16)
│   │   ├── pantry/PantryItem.tsx    # Smart Pantry Item
│   │   └── ui/                      # Botones, labels, firma IP
│   ├── navigation/
│   │   └── AppNavigator.tsx         # Bottom Tab Navigator
│   └── screens/
│       ├── onboarding/              # PASO 1: 7 pasos completos (Funciones 1-8)
│       ├── dashboard/               # Dashboard principal (Funciones 2, 5, 6, 39, 41, 42)
│       ├── training/                # La Tríada (Funciones 17-24)
│       ├── nutrition/               # Nutrición (Funciones 9-16, 25-32)
│       ├── monitoring/              # Monitoreo (Funciones 33-40)
│       └── elite/                   # Élite (Funciones 41-54)
```

---

## 🧬 Las 54 Funciones — Cobertura

| Fase | Funciones | Estado |
|------|-----------|--------|
| Fase 1 — Biometría & Avatar | 1–8 | ✅ Implementado |
| Fase 2 — Recursos & Espiritualidad | 9–16 | ✅ Implementado |
| Fase 3 — Ingeniería del Movimiento | 17–24 | ✅ Implementado |
| Fase 4 — Inteligencia Nutricional | 25–32 | ✅ Implementado |
| Fase 5 — Monitoreo Avanzado | 33–40 | ✅ Implementado |
| Fase 6 — Funciones Élite | 41–54 | ✅ Implementado |

---

## 🔒 Privacidad
- **Analizador de Ronquidos (F34):** Edge computing — audio procesado 100% en dispositivo, eliminado tras reporte.
- **GPS ZIMA-Run (F36):** Solo activo durante sesión de trote, no persiste.
- **Voice Stress (F45):** Procesamiento local, sin envío a servidores.

---

## © Carlos Espina Property
**Algoritmo SIM** — Propiedad Intelectual Registrada  
Todo reporte y exportación incluye firma digital `Carlos Espina Property`.
